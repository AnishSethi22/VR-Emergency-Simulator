using UnityEngine;
#if UNITY_6000_5_OR_NEWER
using Unity.Scripting.LifecycleManagement;
#endif

namespace UnityEngine.XR.Interaction.Toolkit.Utilities
{
#if UNITY_6000_5_OR_NEWER
    [NoAutoStaticsCleanup]
#endif
    static class DisplayUtility
    {
        const float k_DefaultScreenDpi = 100f;

        static float s_ScreenDpi = k_DefaultScreenDpi;
        static float s_OneOverScreenDpi = 1f / k_DefaultScreenDpi;
        static bool s_ScreenDpiChecked;

        /// <summary>
        /// This wrapper property checks whether the Screen.dpi value has been set by the
        /// underlying platform. If it has not, it defaults to a 100 dpi default value to
        /// use for dpi-based calculations.
        /// </summary>
        public static float screenDpi
        {
            get
            {
                CacheScreenDpi();
                return s_ScreenDpi;
            }
        }

        /// <summary>
        /// Convenience property to get the value of (1 / <see cref="screenDpi"/>) that
        /// gets cached when the screenDpi is checked.
        /// </summary>
        public static float screenDpiRatio
        {
            get
            {
                CacheScreenDpi();
                return s_OneOverScreenDpi;
            }
        }

        static void CacheScreenDpi()
        {
            if (!s_ScreenDpiChecked)
            {
                if (Screen.dpi > 0)
                    s_ScreenDpi = Screen.dpi;
                else
                    Debug.LogWarning("Platform has reported a screen DPI of 0. Using default value of 100.");

                s_OneOverScreenDpi = 1f / s_ScreenDpi;
                s_ScreenDpiChecked = true;
            }
        }

        /// <summary>
        /// Converts Pixels to Inches.
        /// </summary>
        /// <param name="pixels">The amount to convert in pixels.</param>
        /// <returns>The converted amount in inches.</returns>
        public static float PixelsToInches(float pixels) => pixels * screenDpiRatio;

        /// <summary>
        /// Converts Inches to Pixels.
        /// </summary>
        /// <param name="inches">The amount to convert in inches.</param>
        /// <returns>The converted amount in pixels.</returns>
        public static float InchesToPixels(float inches) => inches * screenDpi;

        [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.SubsystemRegistration)]
        static void ResetStaticsOnLoad()
        {
            s_ScreenDpi = k_DefaultScreenDpi;
            s_OneOverScreenDpi = 1f / k_DefaultScreenDpi;
            s_ScreenDpiChecked = false;
        }
    }
}
