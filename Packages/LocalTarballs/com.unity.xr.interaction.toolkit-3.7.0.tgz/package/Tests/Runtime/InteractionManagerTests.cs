using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text.RegularExpressions;
using NUnit.Framework;
using UnityEngine.TestTools;
using UnityEngine.XR.Interaction.Toolkit.Filtering;
using UnityEngine.XR.Interaction.Toolkit.Inputs.Readers;
using UnityEngine.XR.Interaction.Toolkit.Interactables;
using UnityEngine.XR.Interaction.Toolkit.Interactors;
using UnityEngine.XR.Interaction.Toolkit.Utilities;

namespace UnityEngine.XR.Interaction.Toolkit.Tests
{
    [TestFixture]
    class InteractionManagerTests
    {
        [TearDown]
        public void TearDown()
        {
            TestUtilities.ResetXRIRuntimeSettings();
            TestUtilities.DestroyAllSceneObjects();
        }

        [Test]
        public void InteractionGroupRegisteredOnEnable()
        {
            var manager = TestUtilities.CreateInteractionManager();
            IXRInteractionGroup registeredInteractionGroup = null;
            manager.interactionGroupRegistered += args => registeredInteractionGroup = args.interactionGroupObject;
            var interactionGroup = TestUtilities.CreateInteractionGroup();

            var interactionGroups = new List<IXRInteractionGroup>();
            manager.GetRegisteredInteractionGroups(interactionGroups);
            Assert.That(interactionGroups, Is.EqualTo(new[] { interactionGroup }));
            Assert.That(registeredInteractionGroup, Is.SameAs(interactionGroup));
            Assert.That(manager.IsRegistered(interactionGroup), Is.True);
        }

        [Test]
        public void InteractionGroupUnregisteredOnDisable()
        {
            var manager = TestUtilities.CreateInteractionManager();
            IXRInteractionGroup unregisteredInteractionGroup = null;
            manager.interactionGroupUnregistered += args => unregisteredInteractionGroup = args.interactionGroupObject;
            var interactionGroup = TestUtilities.CreateInteractionGroup();
            Assert.That(manager.IsRegistered(interactionGroup), Is.True);
            interactionGroup.enabled = false;

            var interactionGroups = new List<IXRInteractionGroup>();
            manager.GetRegisteredInteractionGroups(interactionGroups);
            Assert.That(interactionGroups, Is.Empty);
            Assert.That(unregisteredInteractionGroup, Is.SameAs(interactionGroup));
            Assert.That(manager.IsRegistered(interactionGroup), Is.False);
        }

        [Test]
        public void InteractionGroupRegistrationEventsInvoked()
        {
            var manager = TestUtilities.CreateInteractionManager();
            var interactionGroup = TestUtilities.CreateInteractionGroup();
            IXRInteractionGroup registeredInteractionGroup = null;
            IXRInteractionGroup unregisteredInteractionGroup = null;
            interactionGroup.registered += args => registeredInteractionGroup = args.interactionGroupObject;
            interactionGroup.unregistered += args => unregisteredInteractionGroup = args.interactionGroupObject;
            interactionGroup.enabled = false;

            var interactionGroups = new List<IXRInteractionGroup>();
            manager.GetRegisteredInteractionGroups(interactionGroups);
            Assert.That(interactionGroups, Is.Empty);
            Assert.That(unregisteredInteractionGroup, Is.SameAs(interactionGroup));

            interactionGroup.enabled = true;

            manager.GetRegisteredInteractionGroups(interactionGroups);
            Assert.That(interactionGroups, Is.EqualTo(new[] { interactionGroup }));
            Assert.That(registeredInteractionGroup, Is.SameAs(interactionGroup));
        }

        [Test]
        public void InteractorRegisteredOnEnable()
        {
            var manager = TestUtilities.CreateInteractionManager();
            IXRInteractor registeredInteractor = null;
            manager.interactorRegistered += args => registeredInteractor = args.interactorObject;
            var interactor = TestUtilities.CreateDirectInteractor();

            var interactors = new List<IXRInteractor>();
            manager.GetRegisteredInteractors(interactors);
            Assert.That(interactors, Is.EqualTo(new[] { interactor }));
            Assert.That(registeredInteractor, Is.SameAs(interactor));
            Assert.That(manager.IsRegistered((IXRInteractor)interactor), Is.True);
        }

        [Test]
        public void InteractorUnregisteredOnDisable()
        {
            var manager = TestUtilities.CreateInteractionManager();
            IXRInteractor unregisteredInteractor = null;
            manager.interactorUnregistered += args => unregisteredInteractor = args.interactorObject;
            var interactor = TestUtilities.CreateDirectInteractor();
            Assert.That(manager.IsRegistered((IXRInteractor)interactor), Is.True);
            interactor.enabled = false;

            var interactors = new List<IXRInteractor>();
            manager.GetRegisteredInteractors(interactors);
            Assert.That(interactors, Is.Empty);
            Assert.That(unregisteredInteractor, Is.SameAs(interactor));
            Assert.That(manager.IsRegistered((IXRInteractor)interactor), Is.False);
        }

        [Test]
        public void InteractorRegistrationEventsInvoked()
        {
            var manager = TestUtilities.CreateInteractionManager();
            var interactor = TestUtilities.CreateDirectInteractor();
            IXRInteractor registeredInteractor = null;
            IXRInteractor unregisteredInteractor = null;
            interactor.registered += args => registeredInteractor = args.interactorObject;
            interactor.unregistered += args => unregisteredInteractor = args.interactorObject;
            interactor.enabled = false;

            var interactors = new List<IXRInteractor>();
            manager.GetRegisteredInteractors(interactors);
            Assert.That(interactors, Is.Empty);
            Assert.That(unregisteredInteractor, Is.SameAs(interactor));

            interactor.enabled = true;

            manager.GetRegisteredInteractors(interactors);
            Assert.That(interactors, Is.EqualTo(new[] { interactor }));
            Assert.That(registeredInteractor, Is.SameAs(interactor));
        }

        [Test]
        public void InteractableRegisteredOnEnable()
        {
            var manager = TestUtilities.CreateInteractionManager();
            IXRInteractable registeredInteractable = null;
            manager.interactableRegistered += args => registeredInteractable = args.interactableObject;
            var interactable = TestUtilities.CreateGrabInteractable();

            var interactables = new List<IXRInteractable>();
            manager.GetRegisteredInteractables(interactables);
            Assert.That(interactables, Is.EqualTo(new[] { interactable }));
            Assert.That(registeredInteractable, Is.SameAs(interactable));
            Assert.That(manager.IsRegistered((IXRInteractable)interactable), Is.True);
        }

        [Test]
        public void InteractableUnregisteredOnDisable()
        {
            var manager = TestUtilities.CreateInteractionManager();
            IXRInteractable unregisteredInteractable = null;
            manager.interactableUnregistered += args => unregisteredInteractable = args.interactableObject;
            var interactable = TestUtilities.CreateGrabInteractable();
            Assert.That(manager.IsRegistered((IXRInteractable)interactable), Is.True);
            interactable.enabled = false;

            var interactables = new List<IXRInteractable>();
            manager.GetRegisteredInteractables(interactables);
            Assert.That(interactables, Is.Empty);
            Assert.That(unregisteredInteractable, Is.SameAs(interactable));
            Assert.That(manager.IsRegistered((IXRInteractable)interactable), Is.False);
        }

        [Test]
        public void InteractableRegistrationEventsInvoked()
        {
            var manager = TestUtilities.CreateInteractionManager();
            var interactable = TestUtilities.CreateGrabInteractable();
            IXRInteractable registeredInteractable = null;
            IXRInteractable unregisteredInteractable = null;
            interactable.registered += args => registeredInteractable = args.interactableObject;
            interactable.unregistered += args => unregisteredInteractable = args.interactableObject;
            interactable.enabled = false;

            var interactables = new List<IXRInteractable>();
            manager.GetRegisteredInteractables(interactables);
            Assert.That(interactables, Is.Empty);
            Assert.That(unregisteredInteractable, Is.SameAs(interactable));

            interactable.enabled = true;

            manager.GetRegisteredInteractables(interactables);
            Assert.That(interactables, Is.EqualTo(new[] { interactable }));
            Assert.That(registeredInteractable, Is.SameAs(interactable));
        }

        [UnityTest]
        public IEnumerator InteractionGroupUnregisteredOnManagerDestroyed()
        {
            var manager = TestUtilities.CreateInteractionManager();
            IXRInteractionGroup unregisteredInteractionGroup = null;
            manager.interactionGroupUnregistered += args => unregisteredInteractionGroup = args.interactionGroupObject;
            var interactionGroup = TestUtilities.CreateInteractionGroup();
            Assert.That(manager.IsRegistered(interactionGroup), Is.True);
            Object.Destroy(manager);

            yield return null;

            Assert.That(manager == null, Is.True);

            var interactionGroups = new List<IXRInteractionGroup>();
            manager.GetRegisteredInteractionGroups(interactionGroups);
            Assert.That(interactionGroups, Is.Empty);
            Assert.That(unregisteredInteractionGroup, Is.SameAs(interactionGroup));
            Assert.That(manager.IsRegistered(interactionGroup), Is.False);
        }

        [UnityTest]
        public IEnumerator InteractorUnregisteredOnManagerDestroyed()
        {
            var manager = TestUtilities.CreateInteractionManager();
            IXRInteractor unregisteredInteractor = null;
            manager.interactorUnregistered += args => unregisteredInteractor = args.interactorObject;
            var interactor = TestUtilities.CreateDirectInteractor();
            Assert.That(manager.IsRegistered((IXRInteractor)interactor), Is.True);
            Object.Destroy(manager);

            yield return null;

            Assert.That(manager == null, Is.True);

            var interactors = new List<IXRInteractor>();
            manager.GetRegisteredInteractors(interactors);
            Assert.That(interactors, Is.Empty);
            Assert.That(unregisteredInteractor, Is.SameAs(interactor));
            Assert.That(manager.IsRegistered((IXRInteractor)interactor), Is.False);
        }

        [UnityTest]
        public IEnumerator InteractableUnregisteredOnManagerDestroyed()
        {
            var manager = TestUtilities.CreateInteractionManager();
            IXRInteractable unregisteredInteractable = null;
            manager.interactableUnregistered += args => unregisteredInteractable = args.interactableObject;
            var interactable = TestUtilities.CreateGrabInteractable();
            Assert.That(manager.IsRegistered((IXRInteractable)interactable), Is.True);
            Object.Destroy(manager);

            yield return null;

            Assert.That(manager == null, Is.True);

            var interactables = new List<IXRInteractable>();
            manager.GetRegisteredInteractables(interactables);
            Assert.That(interactables, Is.Empty);
            Assert.That(unregisteredInteractable, Is.SameAs(interactable));
            Assert.That(manager.IsRegistered((IXRInteractable)interactable), Is.False);
        }

        [UnityTest]
        public IEnumerator InteractorInInteractionGroupUnregisteredOnManagerDestroyed()
        {
            var manager = TestUtilities.CreateInteractionManager();

            IXRInteractor unregisteredInteractor = null;
            manager.interactorUnregistered += args => unregisteredInteractor = args.interactorObject;

            IXRInteractionGroup unregisteredInteractionGroup = null;
            manager.interactionGroupUnregistered += args => unregisteredInteractionGroup = args.interactionGroupObject;

            var interactionGroup = TestUtilities.CreateInteractionGroup();
            Assert.That(manager.IsRegistered(interactionGroup), Is.True);

            var interactor = TestUtilities.CreateDirectInteractor();
            Assert.That(manager.IsRegistered((IXRInteractor)interactor), Is.True);

            interactionGroup.AddGroupMember(interactor);

            Assert.That(manager.IsRegistered((IXRInteractor)interactor), Is.True);
            Assert.That(manager.IsRegistered(interactionGroup), Is.True);

            Object.Destroy(manager);

            yield return null;

            Assert.That(manager == null, Is.True);

            var interactors = new List<IXRInteractor>();
            manager.GetRegisteredInteractors(interactors);
            Assert.That(interactors, Is.Empty);

            var interactionGroups = new List<IXRInteractionGroup>();
            manager.GetRegisteredInteractionGroups(interactionGroups);
            Assert.That(interactionGroups, Is.Empty);

            Assert.That(unregisteredInteractor, Is.SameAs(interactor));
            Assert.That(unregisteredInteractionGroup, Is.SameAs(interactionGroup));
            Assert.That(manager.IsRegistered((IXRInteractor)interactor), Is.False);
            Assert.That(manager.IsRegistered(interactionGroup), Is.False);
        }

        [TestCase(XRInteractionRuntimeSettings.ManagerRegistrationMode.FindAutomatically)]
        [TestCase(XRInteractionRuntimeSettings.ManagerRegistrationMode.Manual)]
        public void CustomInteractorRegisteredFromWaitlist(XRInteractionRuntimeSettings.ManagerRegistrationMode registrationMode)
        {
            // Unlike the test below, this test does not rely on the interactor itself registering with the
            // interaction manager during its own OnEnable. This test verifies that an interactor manually
            // added to the waitlist through API is actually registered with a new manager.

            Assume.That(XRInteractionRuntimeSettings.InstanceInternal != null, Is.True);
            Assume.That(XRInteractionManager.activeInteractionManagers, Is.Empty);
            Assume.That(ComponentLocatorUtility<XRInteractionManager>.componentCache, Is.Null);

            XRInteractionRuntimeSettings.InstanceInternal.managerCreationMode = XRInteractionRuntimeSettings.ManagerCreationMode.Manual;
            XRInteractionRuntimeSettings.InstanceInternal.interactionManagerRegistrationMode = registrationMode;

            var interactor = TestUtilities.CreateMockClassInteractor();

            // The manager should not be automatically created from the mock plain C# class-based interactor
            Assert.That(XRInteractionManager.activeInteractionManagers, Is.Empty);
            Assert.That(interactor.isRegistered, Is.False);
            Assert.That(interactor.registeredInteractionManager, Is.Null);

            // Use API to add the custom interactor to the waitlist
            XRInteractionManager.RegisterWithWaitlist(interactor);

            var interactors = new List<IXRInteractor>();
            var manager = TestUtilities.CreateInteractionManager();

            if (registrationMode == XRInteractionRuntimeSettings.ManagerRegistrationMode.Manual)
            {
                // The manager should not automatically register waitlist items when set to Manual
                manager.GetRegisteredInteractors(interactors);

                Assert.That(interactors, Is.Empty);
                Assert.That(manager.IsRegistered(interactor), Is.False);
                Assert.That(interactor.isRegistered, Is.False);
                Assert.That(interactor.registeredInteractionManager, Is.Null);

                // Explicitly register waitlist items
                manager.RegisterWaitlistItems();
            }

            manager.GetRegisteredInteractors(interactors);

            Assert.That(interactors, Is.EqualTo(new[] { interactor }));
            Assert.That(manager.IsRegistered(interactor), Is.True);
            Assert.That(interactor.isRegistered, Is.True);
            Assert.That(interactor.registeredInteractionManager, Is.SameAs(manager));
        }

        [TestCase(XRInteractionRuntimeSettings.ManagerRegistrationMode.FindAutomatically)]
        [TestCase(XRInteractionRuntimeSettings.ManagerRegistrationMode.Manual)]
        public void InteractorRegisteredFromWaitlist(XRInteractionRuntimeSettings.ManagerRegistrationMode registrationMode)
        {
            Assume.That(XRInteractionRuntimeSettings.InstanceInternal != null, Is.True);
            Assume.That(XRInteractionManager.activeInteractionManagers, Is.Empty);
            Assume.That(ComponentLocatorUtility<XRInteractionManager>.componentCache, Is.Null);

            XRInteractionRuntimeSettings.InstanceInternal.managerCreationMode = XRInteractionRuntimeSettings.ManagerCreationMode.Manual;
            XRInteractionRuntimeSettings.InstanceInternal.interactionManagerRegistrationMode = registrationMode;

            var interactor = TestUtilities.CreateMockInteractor();

            // The manager should not be automatically created when set to Manual
            Assert.That(XRInteractionManager.activeInteractionManagers, Is.Empty);
            Assert.That(interactor.interactionManager, Is.Null);

            var interactors = new List<IXRInteractor>();
            var manager = TestUtilities.CreateInteractionManager();

            if (registrationMode == XRInteractionRuntimeSettings.ManagerRegistrationMode.Manual)
            {
                // The manager should not automatically register waitlist items when set to Manual
                manager.GetRegisteredInteractors(interactors);

                Assert.That(interactors, Is.Empty);
                Assert.That(manager.IsRegistered((IXRInteractor)interactor), Is.False);

                // Explicitly register waitlist items
                manager.RegisterWaitlistItems();
            }

            manager.GetRegisteredInteractors(interactors);

            Assert.That(interactors, Is.EqualTo(new[] { interactor }));
            Assert.That(manager.IsRegistered((IXRInteractor)interactor), Is.True);
        }

        [TestCase(XRInteractionRuntimeSettings.ManagerRegistrationMode.FindAutomatically)]
        [TestCase(XRInteractionRuntimeSettings.ManagerRegistrationMode.Manual)]
        public void InteractableRegisteredFromWaitlist(XRInteractionRuntimeSettings.ManagerRegistrationMode registrationMode)
        {
            Assume.That(XRInteractionRuntimeSettings.InstanceInternal != null, Is.True);
            Assume.That(XRInteractionManager.activeInteractionManagers, Is.Empty);
            Assume.That(ComponentLocatorUtility<XRInteractionManager>.componentCache, Is.Null);

            XRInteractionRuntimeSettings.InstanceInternal.managerCreationMode = XRInteractionRuntimeSettings.ManagerCreationMode.Manual;
            XRInteractionRuntimeSettings.InstanceInternal.interactionManagerRegistrationMode = registrationMode;

            var interactable = TestUtilities.CreateSimpleInteractable();

            // The manager should not be automatically created when set to Manual
            Assert.That(XRInteractionManager.activeInteractionManagers, Is.Empty);
            Assert.That(interactable.interactionManager, Is.Null);

            var interactables = new List<IXRInteractable>();
            var manager = TestUtilities.CreateInteractionManager();

            if (registrationMode == XRInteractionRuntimeSettings.ManagerRegistrationMode.Manual)
            {
                // The manager should not automatically register waitlist items when set to Manual
                manager.GetRegisteredInteractables(interactables);

                Assert.That(interactables, Is.Empty);
                Assert.That(manager.IsRegistered((IXRInteractable)interactable), Is.False);

                // Explicitly register waitlist items
                manager.RegisterWaitlistItems();
            }

            manager.GetRegisteredInteractables(interactables);

            Assert.That(interactables, Is.EqualTo(new[] { interactable }));
            Assert.That(manager.IsRegistered((IXRInteractable)interactable), Is.True);
        }

        [TestCase(XRInteractionRuntimeSettings.ManagerRegistrationMode.FindAutomatically)]
        [TestCase(XRInteractionRuntimeSettings.ManagerRegistrationMode.Manual)]
        public void SnapVolumeRegisteredFromWaitlist(XRInteractionRuntimeSettings.ManagerRegistrationMode registrationMode)
        {
            Assume.That(XRInteractionRuntimeSettings.InstanceInternal != null, Is.True);
            Assume.That(XRInteractionManager.activeInteractionManagers, Is.Empty);
            Assume.That(ComponentLocatorUtility<XRInteractionManager>.componentCache, Is.Null);

            XRInteractionRuntimeSettings.InstanceInternal.managerCreationMode = XRInteractionRuntimeSettings.ManagerCreationMode.Manual;
            XRInteractionRuntimeSettings.InstanceInternal.interactionManagerRegistrationMode = registrationMode;

            var interactable = TestUtilities.CreateSimpleInteractable();
            var snapVolume = TestUtilities.CreateSnapVolume();
            snapVolume.interactable = interactable;

            // The manager should not be automatically created when set to Manual
            Assert.That(XRInteractionManager.activeInteractionManagers, Is.Empty);
            Assert.That(interactable.interactionManager, Is.Null);

            var snapVolumes = new List<XRInteractableSnapVolume>();
            var manager = TestUtilities.CreateInteractionManager();

            if (registrationMode == XRInteractionRuntimeSettings.ManagerRegistrationMode.Manual)
            {
                // The manager should not automatically register waitlist items when set to Manual
                manager.GetRegisteredSnapVolumes(snapVolumes);

                Assert.That(snapVolumes, Is.Empty);
                Assert.That(manager.IsRegistered(snapVolume), Is.False);

                // Explicitly register waitlist items
                manager.RegisterWaitlistItems();
            }

            manager.GetRegisteredSnapVolumes(snapVolumes);

            Assert.That(snapVolumes, Is.EqualTo(new[] { snapVolume }));
            Assert.That(manager.IsRegistered(snapVolume), Is.True);
        }

        [TestCase(XRInteractionRuntimeSettings.ManagerRegistrationMode.FindAutomatically)]
        [TestCase(XRInteractionRuntimeSettings.ManagerRegistrationMode.Manual)]
        public void InteractionGroupRegisteredFromWaitlist(XRInteractionRuntimeSettings.ManagerRegistrationMode registrationMode)
        {
            Assume.That(XRInteractionRuntimeSettings.InstanceInternal != null, Is.True);
            Assume.That(XRInteractionManager.activeInteractionManagers, Is.Empty);
            Assume.That(ComponentLocatorUtility<XRInteractionManager>.componentCache, Is.Null);

            XRInteractionRuntimeSettings.InstanceInternal.managerCreationMode = XRInteractionRuntimeSettings.ManagerCreationMode.Manual;
            XRInteractionRuntimeSettings.InstanceInternal.interactionManagerRegistrationMode = registrationMode;

            var group = TestUtilities.CreateInteractionGroup();
            var interactor = TestUtilities.CreateMockInteractor();
            group.AddGroupMember(interactor);

            // The manager should not be automatically created when set to Manual
            Assert.That(XRInteractionManager.activeInteractionManagers, Is.Empty);
            Assert.That(interactor.interactionManager, Is.Null);

            var groups = new List<IXRInteractionGroup>();
            var manager = TestUtilities.CreateInteractionManager();

            if (registrationMode == XRInteractionRuntimeSettings.ManagerRegistrationMode.Manual)
            {
                // The manager should not automatically register waitlist items when set to Manual
                manager.GetRegisteredInteractionGroups(groups);

                Assert.That(groups, Is.Empty);
                Assert.That(manager.IsRegistered(group), Is.False);

                // Explicitly register waitlist items
                manager.RegisterWaitlistItems();
            }

            manager.GetRegisteredInteractionGroups(groups);

            Assert.That(groups, Is.EqualTo(new[] { group }));
            Assert.That(manager.IsRegistered(group), Is.True);
        }

        [UnityTest]
        public IEnumerator InteractionsCanceledOnManagerDestroyed()
        {
            var manager = TestUtilities.CreateInteractionManager();

            IXRInteractor unregisteredInteractor = null;
            manager.interactorUnregistered += args => unregisteredInteractor = args.interactorObject;

            IXRInteractable unregisteredInteractable = null;
            manager.interactableUnregistered += args => unregisteredInteractable = args.interactableObject;

            var interactor = TestUtilities.CreateMockInteractor();
            var interactable = TestUtilities.CreateSimpleInteractable();
            Assert.That(manager.IsRegistered((IXRInteractor)interactor), Is.True);
            Assert.That(manager.IsRegistered((IXRInteractable)interactable), Is.True);

            var interactorEventInvoked = false;
            IXRInteractor interactorEventInteractor = null;
            IXRInteractable interactorEventInteractable = null;
            var interactorEventIsCanceled = false;
            interactor.selectExited.AddListener(args =>
            {
                interactorEventInvoked = true;
                interactorEventInteractor = args.interactorObject;
                interactorEventInteractable = args.interactableObject;
                interactorEventIsCanceled = args.isCanceled;
            });

            var interactableEventInvoked = false;
            IXRInteractor interactableEventInteractor = null;
            IXRInteractable interactableEventInteractable = null;
            var interactableEventIsCanceled = false;
            interactable.selectExited.AddListener(args =>
            {
                interactableEventInvoked = true;
                interactableEventInteractor = args.interactorObject;
                interactableEventInteractable = args.interactableObject;
                interactableEventIsCanceled = args.isCanceled;
            });

            interactor.keepSelectedTargetValid = true;
            interactor.validTargets.Add(interactable);

            yield return null;

            Assert.That(interactor.hasSelection, Is.True);
            Assert.That(interactable.isSelected, Is.True);
            Assert.That(interactor.IsSelecting(interactable), Is.True);
            Assert.That(interactable.IsSelected(interactor), Is.True);

            Object.Destroy(manager);

            yield return null;

            Assert.That(manager == null, Is.True);

            var interactors = new List<IXRInteractor>();
            manager.GetRegisteredInteractors(interactors);
            Assert.That(interactors, Is.Empty);

            var interactables = new List<IXRInteractable>();
            manager.GetRegisteredInteractables(interactables);
            Assert.That(interactables, Is.Empty);

            Assert.That(unregisteredInteractor, Is.SameAs(interactor));
            Assert.That(unregisteredInteractable, Is.SameAs(interactable));

            Assert.That(interactorEventInvoked, Is.True);
            Assert.That(interactorEventInteractor, Is.SameAs(interactor));
            Assert.That(interactorEventInteractable, Is.SameAs(interactable));
            Assert.That(interactorEventIsCanceled, Is.True);

            Assert.That(interactableEventInvoked, Is.True);
            Assert.That(interactableEventInteractor, Is.SameAs(interactor));
            Assert.That(interactableEventInteractable, Is.SameAs(interactable));
            Assert.That(interactableEventIsCanceled, Is.True);

            Assert.That(manager.IsRegistered((IXRInteractor)interactor), Is.False);
            Assert.That(manager.IsRegistered((IXRInteractable)interactable), Is.False);
        }

        [Test]
        public void InteractableRegisteredOnEnableWithColliders()
        {
            var manager = TestUtilities.CreateInteractionManager();
            var interactable = TestUtilities.CreateGrabInteractable();

            var interactables = new List<IXRInteractable>();
            manager.GetRegisteredInteractables(interactables);
            Assert.That(interactables, Is.EqualTo(new[] { interactable }));
            Assert.That(interactable.colliders, Has.Count.EqualTo(1));
            Assert.That(manager.TryGetInteractableForCollider(interactable.colliders.First(), out var associatedInteractable), Is.True);
            Assert.That(associatedInteractable, Is.SameAs(interactable));
        }

        [Test]
        public void InteractableUnregistersAssociatedColliders()
        {
            var manager = TestUtilities.CreateInteractionManager();
            var firstInteractable = TestUtilities.CreateGrabInteractable();
            var secondInteractable = TestUtilities.CreateGrabInteractable();

            manager.UnregisterInteractable((IXRInteractable)firstInteractable);
            manager.UnregisterInteractable((IXRInteractable)secondInteractable);

            // Setup so the first Interactable has both colliders, and the second Interactable has a conflicting reference
            secondInteractable.transform.SetParent(firstInteractable.transform);
            firstInteractable.colliders.Clear();
            firstInteractable.colliders.AddRange(firstInteractable.GetComponentsInChildren<Collider>());
            secondInteractable.colliders.Clear();
            secondInteractable.colliders.AddRange(secondInteractable.GetComponentsInChildren<Collider>());

            Assert.That(firstInteractable.colliders, Has.Count.EqualTo(2));
            Assert.That(secondInteractable.colliders, Has.Count.EqualTo(1));

            Assert.That(manager.TryGetInteractableForCollider(firstInteractable.colliders[0], out var associatedInteractable), Is.False);
            Assert.That(associatedInteractable, Is.Null);
            Assert.That(manager.TryGetInteractableForCollider(firstInteractable.colliders[1], out associatedInteractable), Is.False);
            Assert.That(associatedInteractable, Is.Null);

            manager.RegisterInteractable((IXRInteractable)firstInteractable);

            Assert.That(manager.TryGetInteractableForCollider(firstInteractable.colliders[0], out associatedInteractable), Is.True);
            Assert.That(associatedInteractable, Is.SameAs(firstInteractable));
            Assert.That(manager.TryGetInteractableForCollider(firstInteractable.colliders[1], out associatedInteractable), Is.True);
            Assert.That(associatedInteractable, Is.SameAs(firstInteractable));

            LogAssert.Expect(LogType.Warning, new Regex("A collider used by an Interactable object is already registered with another Interactable object*"));
            manager.RegisterInteractable((IXRInteractable)secondInteractable);

            // Interactables registered afterward do not replace the existing Collider association
            Assert.That(manager.TryGetInteractableForCollider(firstInteractable.colliders[0], out associatedInteractable), Is.True);
            Assert.That(associatedInteractable, Is.SameAs(firstInteractable));
            Assert.That(manager.TryGetInteractableForCollider(firstInteractable.colliders[1], out associatedInteractable), Is.True);
            Assert.That(associatedInteractable, Is.SameAs(firstInteractable));

            manager.UnregisterInteractable((IXRInteractable)secondInteractable);

            // Interactables registered afterward should not cause the registered Collider association to be removed
            Assert.That(manager.TryGetInteractableForCollider(firstInteractable.colliders[0], out associatedInteractable), Is.True);
            Assert.That(associatedInteractable, Is.SameAs(firstInteractable));
            Assert.That(manager.TryGetInteractableForCollider(firstInteractable.colliders[1], out associatedInteractable), Is.True);
            Assert.That(associatedInteractable, Is.SameAs(firstInteractable));

            manager.UnregisterInteractable((IXRInteractable)firstInteractable);

            Assert.That(manager.TryGetInteractableForCollider(firstInteractable.colliders[0], out associatedInteractable), Is.False);
            Assert.That(associatedInteractable, Is.Null);
            Assert.That(manager.TryGetInteractableForCollider(firstInteractable.colliders[1], out associatedInteractable), Is.False);
            Assert.That(associatedInteractable, Is.Null);
        }

        [Test]
        public void InteractableSnapColliderRedirectsAssociatedInteractable()
        {
            var manager = TestUtilities.CreateInteractionManager();
            var interactable = TestUtilities.CreateSimpleInteractable();
            var snapVolume = TestUtilities.CreateSnapVolume();
            snapVolume.interactable = interactable;

            Assert.That(snapVolume.snapCollider, Is.Not.Null);

            Assert.That(manager.TryGetInteractableForCollider(interactable.colliders.First(), out var associatedInteractable), Is.True);
            Assert.That(associatedInteractable, Is.SameAs(interactable));

            Assert.That(manager.TryGetInteractableForCollider(interactable.colliders.First(), out associatedInteractable, out var associatedSnapVolume), Is.True);
            Assert.That(associatedInteractable, Is.SameAs(interactable));
            Assert.That(associatedSnapVolume, Is.Null);

            Assert.That(manager.TryGetInteractableForCollider(snapVolume.snapCollider, out associatedInteractable, out associatedSnapVolume), Is.True);
            Assert.That(associatedInteractable, Is.SameAs(interactable));
            Assert.That(associatedSnapVolume, Is.SameAs(snapVolume));
        }

        // Tests that Interactors and Interactables can register or unregister
        // while the Interaction Manager is iterating over the list of Interactors to process events in Update.
        [UnityTest]
        public IEnumerator ObjectsCanRegisterDuringEvents()
        {
            var manager = TestUtilities.CreateInteractionManager();
            var interactor = TestUtilities.CreateRayInteractor();
            var interactable = TestUtilities.CreateSimpleInteractable();
            interactable.transform.position = interactor.transform.position + interactor.transform.forward * 5f;

            var otherInteractor = TestUtilities.CreateDirectInteractor();
            var otherInteractable = TestUtilities.CreateSimpleInteractable();
            otherInteractor.enabled = false;
            otherInteractable.enabled = false;
            // Don't let them get in the way, both are only used to test registration
            otherInteractor.interactionLayers = 0;
            otherInteractable.interactionLayers = 0;

            // Set the input mode so it can be manually driven
            interactor.selectInput.inputSourceMode = XRInputButtonReader.InputSourceMode.ManualValue;

            // Upon Select, enable the other Interactor to have it register with the Interaction Manager during the update loop.
            // Upon Deselect, disable the other Interactor to have it unregister from the Interaction Manager during the update loop.
            interactor.selectEntered.AddListener(args =>
            {
                otherInteractor.enabled = true;
                otherInteractable.enabled = true;
            });
            interactor.selectExited.AddListener(args =>
            {
                otherInteractor.enabled = false;
                otherInteractable.enabled = false;
            });

            var interactors = new List<IXRInteractor>();
            var interactables = new List<IXRInteractable>();
            manager.GetRegisteredInteractors(interactors);
            manager.GetRegisteredInteractables(interactables);
            Assert.That(interactors, Is.EqualTo(new[] { interactor }));
            Assert.That(interactables, Is.EqualTo(new[] { interactable }));

            // Wait for Physics update to ensure the Interactable can be detected by the Interactor
            yield return new WaitForFixedUpdate();
            yield return null;

            Assert.That(interactable.isHovered, Is.True);
            Assert.That(interactable.isSelected, Is.False);

            // Press Grip
            interactor.selectInput.QueueManualState(true, 1f);

            yield return null;

            Assert.That(interactable.isHovered, Is.True);
            Assert.That(interactable.isSelected, Is.True);

            manager.GetRegisteredInteractors(interactors);
            manager.GetRegisteredInteractables(interactables);
            Assert.That(interactors, Is.EqualTo(new IXRInteractor[] { interactor, otherInteractor }));
            Assert.That(interactables, Is.EqualTo(new IXRInteractable[] { interactable, otherInteractable }));

            // Release Grip
            interactor.selectInput.QueueManualState(false, 0f);

            yield return null;

            Assert.That(interactable.isHovered, Is.True);
            Assert.That(interactable.isSelected, Is.False);

            manager.GetRegisteredInteractors(interactors);
            manager.GetRegisteredInteractables(interactables);
            Assert.That(interactors, Is.EqualTo(new[] { interactor }));
            Assert.That(interactables, Is.EqualTo(new[] { interactable }));
        }

        // Tests that Interactors and Interactables can register or unregister
        // while the Interaction Manager is iterating over the list of Interactors to process in ProcessInteractors.
        [UnityTest]
        public IEnumerator ObjectsCanRegisterDuringProcessInteractors()
        {
            var manager = TestUtilities.CreateInteractionManager();
            var interactor = EnablerInteractor.CreateInteractor();

            var otherInteractor = TestUtilities.CreateDirectInteractor();
            var otherInteractable = TestUtilities.CreateSimpleInteractable();
            otherInteractor.enabled = false;
            otherInteractable.enabled = false;
            // Don't let them get in the way, both are only used to test registration
            otherInteractor.interactionLayers = 0;
            otherInteractable.interactionLayers = 0;

            interactor.interactor = otherInteractor;
            interactor.interactable = otherInteractable;

            yield return null;

            var interactors = new List<IXRInteractor>();
            var interactables = new List<IXRInteractable>();
            manager.GetRegisteredInteractors(interactors);
            manager.GetRegisteredInteractables(interactables);
            Assert.That(interactors, Is.EqualTo(new[] { interactor }));
            Assert.That(interactables, Is.Empty);

            interactor.enableBehaviors = true;

            yield return null;

            manager.GetRegisteredInteractors(interactors);
            manager.GetRegisteredInteractables(interactables);
            Assert.That(interactors, Is.EqualTo(new IXRInteractor[] { interactor, otherInteractor }));
            Assert.That(interactables, Is.EqualTo(new IXRInteractable[] { otherInteractable }));

            interactor.enableBehaviors = false;

            yield return null;

            manager.GetRegisteredInteractors(interactors);
            manager.GetRegisteredInteractables(interactables);
            Assert.That(interactors, Is.EqualTo(new[] { interactor }));
            Assert.That(interactables, Is.Empty);
        }

        // Tests that Interactors and Interactables can register or unregister
        // while the Interaction Manager is iterating over the list of Interactables to process in ProcessInteractables.
        [UnityTest]
        public IEnumerator ObjectsCanRegisterDuringProcessInteractables()
        {
            var manager = TestUtilities.CreateInteractionManager();
            var interactable = EnablerInteractable.CreateInteractable();

            var otherInteractor = TestUtilities.CreateDirectInteractor();
            var otherInteractable = TestUtilities.CreateSimpleInteractable();
            otherInteractor.enabled = false;
            otherInteractable.enabled = false;
            // Don't let them get in the way, both are only used to test registration
            otherInteractor.interactionLayers = 0;
            otherInteractable.interactionLayers = 0;

            interactable.interactor = otherInteractor;
            interactable.interactable = otherInteractable;

            yield return null;

            var interactors = new List<IXRInteractor>();
            var interactables = new List<IXRInteractable>();
            manager.GetRegisteredInteractors(interactors);
            manager.GetRegisteredInteractables(interactables);
            Assert.That(interactors, Is.Empty);
            Assert.That(interactables, Is.EqualTo(new[] { interactable }));

            interactable.enableBehaviors = true;

            yield return null;

            manager.GetRegisteredInteractors(interactors);
            manager.GetRegisteredInteractables(interactables);
            Assert.That(interactors, Is.EqualTo(new IXRInteractor[] { otherInteractor }));
            Assert.That(interactables, Is.EqualTo(new IXRInteractable[] { interactable, otherInteractable }));

            interactable.enableBehaviors = false;

            yield return null;

            manager.GetRegisteredInteractors(interactors);
            manager.GetRegisteredInteractables(interactables);
            Assert.That(interactors, Is.Empty);
            Assert.That(interactables, Is.EqualTo(new[] { interactable }));
        }

        [UnityTest]
        public IEnumerator InteractionGroupRegistrationEventsOccurSameFrame()
        {
            TestUtilities.CreateInteractionManager();
            var interactionGroup = TestUtilities.CreateInteractionGroup();
            interactionGroup.enabled = false;

            var numRegistered = 0;
            var numUnregistered = 0;

            interactionGroup.registered += args =>
            {
                ++numRegistered;
            };
            interactionGroup.unregistered += args =>
            {
                ++numUnregistered;
            };

            interactionGroup.enabled = true;

            Assert.That(numRegistered, Is.EqualTo(1));
            Assert.That(numUnregistered, Is.EqualTo(0));

            interactionGroup.enabled = false;

            Assert.That(numRegistered, Is.EqualTo(1));
            Assert.That(numUnregistered, Is.EqualTo(1));

            interactionGroup.enabled = true;

            Assert.That(numRegistered, Is.EqualTo(2));
            Assert.That(numUnregistered, Is.EqualTo(1));

            yield return null;

            Assert.That(numRegistered, Is.EqualTo(2));
            Assert.That(numUnregistered, Is.EqualTo(1));
        }

        [UnityTest]
        public IEnumerator InteractorRegistrationEventsOccurSameFrame()
        {
            TestUtilities.CreateInteractionManager();
            var interactor = TestUtilities.CreateDirectInteractor();
            interactor.enabled = false;

            var numRegistered = 0;
            var numUnregistered = 0;

            interactor.registered += args =>
            {
                ++numRegistered;
            };
            interactor.unregistered += args =>
            {
                ++numUnregistered;
            };

            interactor.enabled = true;

            Assert.That(numRegistered, Is.EqualTo(1));
            Assert.That(numUnregistered, Is.EqualTo(0));

            interactor.enabled = false;

            Assert.That(numRegistered, Is.EqualTo(1));
            Assert.That(numUnregistered, Is.EqualTo(1));

            interactor.enabled = true;

            Assert.That(numRegistered, Is.EqualTo(2));
            Assert.That(numUnregistered, Is.EqualTo(1));

            yield return null;

            Assert.That(numRegistered, Is.EqualTo(2));
            Assert.That(numUnregistered, Is.EqualTo(1));
        }

        [UnityTest]
        public IEnumerator InteractableRegistrationEventsOccurSameFrame()
        {
            TestUtilities.CreateInteractionManager();
            var interactable = TestUtilities.CreateSimpleInteractable();
            interactable.enabled = false;

            var numRegistered = 0;
            var numUnregistered = 0;

            interactable.registered += args =>
            {
                ++numRegistered;
            };
            interactable.unregistered += args =>
            {
                ++numUnregistered;
            };

            interactable.enabled = true;

            Assert.That(numRegistered, Is.EqualTo(1));
            Assert.That(numUnregistered, Is.EqualTo(0));

            interactable.enabled = false;

            Assert.That(numRegistered, Is.EqualTo(1));
            Assert.That(numUnregistered, Is.EqualTo(1));

            interactable.enabled = true;

            Assert.That(numRegistered, Is.EqualTo(2));
            Assert.That(numUnregistered, Is.EqualTo(1));

            yield return null;

            Assert.That(numRegistered, Is.EqualTo(2));
            Assert.That(numUnregistered, Is.EqualTo(1));
        }

        [UnityTest]
        public IEnumerator InteractionGroupCanDestroy()
        {
            var manager = TestUtilities.CreateInteractionManager();
            var interactionGroup = TestUtilities.CreateInteractionGroup();

            Object.Destroy(interactionGroup);

            yield return null;

            var interactionGroups = new List<IXRInteractionGroup>();
            manager.GetRegisteredInteractionGroups(interactionGroups);
            Assert.That(interactionGroups, Is.Empty);
            Assert.That(manager.IsRegistered(interactionGroup), Is.False);
        }

        [UnityTest]
        public IEnumerator InteractorCanDestroy()
        {
            var manager = TestUtilities.CreateInteractionManager();
            var interactor = TestUtilities.CreateDirectInteractor();

            Object.Destroy(interactor);

            yield return null;

            var interactors = new List<IXRInteractor>();
            manager.GetRegisteredInteractors(interactors);
            Assert.That(interactors, Is.Empty);
            Assert.That(manager.IsRegistered((IXRInteractor)interactor), Is.False);
        }

        [UnityTest]
        public IEnumerator InteractableCanDestroy()
        {
            var manager = TestUtilities.CreateInteractionManager();
            var interactable = TestUtilities.CreateGrabInteractable();

            Object.Destroy(interactable);

            yield return null;

            Assert.That(interactable == null, Is.True);

            var interactables = new List<IXRInteractable>();
            manager.GetRegisteredInteractables(interactables);
            Assert.That(interactables, Is.Empty);
            Assert.That(manager.IsRegistered((IXRInteractable)interactable), Is.False);
        }

        [UnityTest]
        public IEnumerator InteractionManagersInteractWithCorrectObjects()
        {
            var managerA = TestUtilities.CreateInteractionManager();
            var interactorA = TestUtilities.CreateDirectInteractor();
            interactorA.interactionManager = managerA;
            var interactableA = TestUtilities.CreateGrabInteractable();
            interactableA.interactionManager = managerA;

            var managerB = TestUtilities.CreateInteractionManager();
            var interactorB = TestUtilities.CreateDirectInteractor();
            interactorB.interactionManager = managerB;
            var interactableB = TestUtilities.CreateGrabInteractable();
            interactableB.interactionManager = managerB;

            yield return new WaitForFixedUpdate();
            yield return null;

            var validTargets = new List<IXRInteractable>();
            managerA.GetValidTargets(interactorA, validTargets);
            Assert.That(validTargets, Has.Exactly(1).EqualTo(interactableA));
            managerB.GetValidTargets(interactorA, validTargets);
            Assert.That(validTargets, Is.Empty);

            Assert.That(interactorA.interactablesHovered, Has.Exactly(1).EqualTo(interactableA));
            Assert.That(interactorB.interactablesHovered, Has.Exactly(1).EqualTo(interactableB));
        }

        [Test]
        public void NestedSelectEnterEventHasCorrectEventArgs()
        {
            var manager = TestUtilities.CreateInteractionManager();
            var firstInteractor = TestUtilities.CreateRayInteractor();
            var secondInteractor = TestUtilities.CreateDirectInteractor();
            var firstInteractable = TestUtilities.CreateSimpleInteractable();
            var secondInteractable = TestUtilities.CreateGrabInteractable();

            var interactors = new IXRSelectInteractor[4];
            var interactables = new IXRSelectInteractable[4];

            // The sequence of notifying the interactor and interactable occurs like:
            // IXRSelectInteractor.OnSelectEntering
            // IXRSelectInteractable.OnSelectEntering
            // IXRSelectInteractor.OnSelectEntered <-- During this call is when another select is triggered
            // IXRSelectInteractable.OnSelectEntered
            // This test will trigger another select event during this sequence.
            // Verify that the references to the interactor and interactable in the event args
            // does not get polluted by the second nested event that executes immediately
            // during the first event.
            firstInteractor.selectEntered.AddListener(args =>
            {
                interactors[0] = args.interactorObject;
                interactables[0] = args.interactableObject;

                // Trigger the nested event
                manager.SelectEnter((IXRSelectInteractor)secondInteractor, secondInteractable);
            });

            firstInteractable.selectEntered.AddListener(args =>
            {
                interactors[1] = args.interactorObject;
                interactables[1] = args.interactableObject;
            });

            secondInteractor.selectEntered.AddListener(args =>
            {
                interactors[2] = args.interactorObject;
                interactables[2] = args.interactableObject;
            });

            secondInteractable.selectEntered.AddListener(args =>
            {
                interactors[3] = args.interactorObject;
                interactables[3] = args.interactableObject;
            });

            // Trigger the first event
            manager.SelectEnter((IXRSelectInteractor)firstInteractor, firstInteractable);

            Assert.That(interactors[0], Is.SameAs(firstInteractor));
            Assert.That(interactables[0], Is.SameAs(firstInteractable));
            Assert.That(interactors[1], Is.SameAs(firstInteractor));
            Assert.That(interactables[1], Is.SameAs(firstInteractable));
            Assert.That(interactors[2], Is.SameAs(secondInteractor));
            Assert.That(interactables[2], Is.SameAs(secondInteractable));
            Assert.That(interactors[3], Is.SameAs(secondInteractor));
            Assert.That(interactables[3], Is.SameAs(secondInteractable));
        }

        [Test]
        public void NestedSelectExitEventHasCorrectEventArgs()
        {
            var manager = TestUtilities.CreateInteractionManager();
            var firstInteractor = TestUtilities.CreateRayInteractor();
            var secondInteractor = TestUtilities.CreateDirectInteractor();
            var firstInteractable = TestUtilities.CreateSimpleInteractable();
            var secondInteractable = TestUtilities.CreateGrabInteractable();

            // Start selected
            manager.SelectEnter((IXRSelectInteractor)firstInteractor, firstInteractable);
            manager.SelectEnter((IXRSelectInteractor)secondInteractor, secondInteractable);

            var interactors = new IXRSelectInteractor[4];
            var interactables = new IXRSelectInteractable[4];

            // The sequence of notifying the interactor and interactable occurs like:
            // IXRSelectInteractor.OnSelectExiting
            // IXRSelectInteractable.OnSelectExiting
            // IXRSelectInteractor.OnSelectExited <-- During this call is when another select exit is triggered
            // IXRSelectInteractable.OnSelectExited
            // This test will trigger another select event during this sequence.
            // Verify that the references to the interactor and interactable in the event args
            // does not get polluted by the second nested event that executes immediately
            // during the first event.
            firstInteractor.selectExited.AddListener(args =>
            {
                interactors[0] = args.interactorObject;
                interactables[0] = args.interactableObject;

                // Trigger the nested event
                manager.SelectExit((IXRSelectInteractor)secondInteractor, secondInteractable);
            });

            firstInteractable.selectExited.AddListener(args =>
            {
                interactors[1] = args.interactorObject;
                interactables[1] = args.interactableObject;
            });

            secondInteractor.selectExited.AddListener(args =>
            {
                interactors[2] = args.interactorObject;
                interactables[2] = args.interactableObject;
            });

            secondInteractable.selectExited.AddListener(args =>
            {
                interactors[3] = args.interactorObject;
                interactables[3] = args.interactableObject;
            });

            // Trigger the first event
            manager.SelectExit((IXRSelectInteractor)firstInteractor, firstInteractable);

            Assert.That(interactors[0], Is.SameAs(firstInteractor));
            Assert.That(interactables[0], Is.SameAs(firstInteractable));
            Assert.That(interactors[1], Is.SameAs(firstInteractor));
            Assert.That(interactables[1], Is.SameAs(firstInteractable));
            Assert.That(interactors[2], Is.SameAs(secondInteractor));
            Assert.That(interactables[2], Is.SameAs(secondInteractable));
            Assert.That(interactors[3], Is.SameAs(secondInteractor));
            Assert.That(interactables[3], Is.SameAs(secondInteractable));
        }

        [Test]
        public void NestedHoverEnterEventHasCorrectEventArgs()
        {
            var manager = TestUtilities.CreateInteractionManager();
            var firstInteractor = TestUtilities.CreateRayInteractor();
            var secondInteractor = TestUtilities.CreateDirectInteractor();
            var firstInteractable = TestUtilities.CreateSimpleInteractable();
            var secondInteractable = TestUtilities.CreateGrabInteractable();

            var interactors = new IXRHoverInteractor[4];
            var interactables = new IXRHoverInteractable[4];

            // The sequence of notifying the interactor and interactable occurs like:
            // IXRHoverInteractor.OnHoverEntering
            // IXRHoverInteractable.OnHoverEntering
            // IXRHoverInteractor.OnHoverEntered <-- During this call is when another hover is triggered
            // IXRHoverInteractable.OnHoverEntered
            // This test will trigger another hover event during this sequence.
            // Verify that the references to the interactor and interactable in the event args
            // does not get polluted by the second nested event that executes immediately
            // during the first event.
            firstInteractor.hoverEntered.AddListener(args =>
            {
                interactors[0] = args.interactorObject;
                interactables[0] = args.interactableObject;

                // Trigger the nested event
                manager.HoverEnter((IXRHoverInteractor)secondInteractor, secondInteractable);
            });

            firstInteractable.hoverEntered.AddListener(args =>
            {
                interactors[1] = args.interactorObject;
                interactables[1] = args.interactableObject;
            });

            secondInteractor.hoverEntered.AddListener(args =>
            {
                interactors[2] = args.interactorObject;
                interactables[2] = args.interactableObject;
            });

            secondInteractable.hoverEntered.AddListener(args =>
            {
                interactors[3] = args.interactorObject;
                interactables[3] = args.interactableObject;
            });

            // Trigger the first event
            manager.HoverEnter((IXRHoverInteractor)firstInteractor, firstInteractable);

            Assert.That(interactors[0], Is.SameAs(firstInteractor));
            Assert.That(interactables[0], Is.SameAs(firstInteractable));
            Assert.That(interactors[1], Is.SameAs(firstInteractor));
            Assert.That(interactables[1], Is.SameAs(firstInteractable));
            Assert.That(interactors[2], Is.SameAs(secondInteractor));
            Assert.That(interactables[2], Is.SameAs(secondInteractable));
            Assert.That(interactors[3], Is.SameAs(secondInteractor));
            Assert.That(interactables[3], Is.SameAs(secondInteractable));
        }

        [Test]
        public void NestedHoverExitEventHasCorrectEventArgs()
        {
            var manager = TestUtilities.CreateInteractionManager();
            var firstInteractor = TestUtilities.CreateRayInteractor();
            var secondInteractor = TestUtilities.CreateDirectInteractor();
            var firstInteractable = TestUtilities.CreateSimpleInteractable();
            var secondInteractable = TestUtilities.CreateGrabInteractable();

            // Start hovered
            manager.HoverEnter((IXRHoverInteractor)firstInteractor, firstInteractable);
            manager.HoverEnter((IXRHoverInteractor)secondInteractor, secondInteractable);

            var interactors = new IXRHoverInteractor[4];
            var interactables = new IXRHoverInteractable[4];

            // The sequence of notifying the interactor and interactable occurs like:
            // IXRHoverInteractor.OnHoverExiting
            // IXRHoverInteractable.OnHoverExiting
            // IXRHoverInteractor.OnHoverExited <-- During this call is when another hover is triggered
            // IXRHoverInteractable.OnHoverExited
            // This test will trigger another hover event during this sequence.
            // Verify that the references to the interactor and interactable in the event args
            // does not get polluted by the second nested event that executes immediately
            // during the first event.
            firstInteractor.hoverExited.AddListener(args =>
            {
                interactors[0] = args.interactorObject;
                interactables[0] = args.interactableObject;

                // Trigger the nested event
                manager.HoverExit((IXRHoverInteractor)secondInteractor, secondInteractable);
            });

            firstInteractable.hoverExited.AddListener(args =>
            {
                interactors[1] = args.interactorObject;
                interactables[1] = args.interactableObject;
            });

            secondInteractor.hoverExited.AddListener(args =>
            {
                interactors[2] = args.interactorObject;
                interactables[2] = args.interactableObject;
            });

            secondInteractable.hoverExited.AddListener(args =>
            {
                interactors[3] = args.interactorObject;
                interactables[3] = args.interactableObject;
            });

            // Trigger the first event
            manager.HoverExit((IXRHoverInteractor)firstInteractor, firstInteractable);

            Assert.That(interactors[0], Is.SameAs(firstInteractor));
            Assert.That(interactables[0], Is.SameAs(firstInteractable));
            Assert.That(interactors[1], Is.SameAs(firstInteractor));
            Assert.That(interactables[1], Is.SameAs(firstInteractable));
            Assert.That(interactors[2], Is.SameAs(secondInteractor));
            Assert.That(interactables[2], Is.SameAs(secondInteractable));
            Assert.That(interactors[3], Is.SameAs(secondInteractor));
            Assert.That(interactables[3], Is.SameAs(secondInteractable));
        }

        [UnityTest]
        public IEnumerator ManagerCanProcessHoverFilters()
        {
            var manager = TestUtilities.CreateInteractionManager();
            var interactor = TestUtilities.CreateMockInteractor();
            var interactable = TestUtilities.CreateSimpleInteractable();
            interactor.validTargets.Add(interactable);

            var filter1WasProcessed = false;
            var filter1 = new XRHoverFilterDelegate((x, y) =>
            {
                filter1WasProcessed = true;
                return true;
            });
            manager.hoverFilters.Add(filter1);

            var filter2WasProcessed = false;
            var filter2 = new XRHoverFilterDelegate((x, y) =>
            {
                filter2WasProcessed = true;
                return true;
            });
            manager.hoverFilters.Add(filter2);

            yield return null;

            Assert.That(filter1WasProcessed, Is.True);
            Assert.That(filter2WasProcessed, Is.True);
            Assert.That(interactable.interactorsHovering, Is.EquivalentTo(new[] { interactor }));

            // Add filter that returns false
            var filter3WasProcessed = false;
            var filter3 = new XRHoverFilterDelegate((x, y) =>
            {
                filter3WasProcessed = true;
                return false;
            });
            manager.hoverFilters.Add(filter3);

            yield return null;

            Assert.That(filter3WasProcessed, Is.True);
            Assert.That(interactable.interactorsHovering, Is.Empty);
        }

        [UnityTest]
        public IEnumerator ManagerCanProcessSelectFilters()
        {
            var manager = TestUtilities.CreateInteractionManager();
            var interactor = TestUtilities.CreateMockInteractor();
            var interactable = TestUtilities.CreateSimpleInteractable();
            interactor.validTargets.Add(interactable);

            var filter1WasProcessed = false;
            var filter1 = new XRSelectFilterDelegate((x, y) =>
            {
                filter1WasProcessed = true;
                return true;
            });
            manager.selectFilters.Add(filter1);

            var filter2WasProcessed = false;
            var filter2 = new XRSelectFilterDelegate((x, y) =>
            {
                filter2WasProcessed = true;
                return true;
            });
            manager.selectFilters.Add(filter2);

            yield return null;

            Assert.That(filter1WasProcessed, Is.True);
            Assert.That(filter2WasProcessed, Is.True);
            Assert.That(interactable.interactorsSelecting, Is.EquivalentTo(new[] { interactor }));

            // Add filter that returns false
            var filter3WasProcessed = false;
            var filter3 = new XRSelectFilterDelegate((x, y) =>
            {
                filter3WasProcessed = true;
                return false;
            });
            manager.selectFilters.Add(filter3);

            yield return null;

            Assert.That(filter3WasProcessed, Is.True);
            Assert.That(interactable.interactorsSelecting, Is.Empty);
        }

        [UnityTest]
        public IEnumerator RegisterParentInteractableTriggersRegisteredSnapshotReorder()
        {
            // Registering parent interactables of interactables even when those interactables are already
            // registered should trigger a sort of the registered list.

            var manager = TestUtilities.CreateInteractionManager();
            var interactable1 = TestUtilities.CreateSimpleInteractable();
            var interactable2 = TestUtilities.CreateSimpleInteractable();
            var interactable3 = TestUtilities.CreateSimpleInteractable();

            var interactablesReordered = 0;
            manager.interactablesReordered += () => interactablesReordered++;

            yield return null;

            var registeredSnapshot = new List<IXRInteractable>();
            manager.GetRegisteredInteractables(registeredSnapshot);
            Assert.That(registeredSnapshot,
                Is.EqualTo(new[] { interactable1, interactable2, interactable3, }));
            Assert.That(interactablesReordered, Is.EqualTo(0));

            // Make 2 a parent (explicit) of 1, keep 3 independent.
            // At this point, a dirty flag should trigger a sort, but it only occurs at the next update loop phase,
            // so wait until next frame to check registered snapshot.
            Assert.That(manager.RegisterParentRelationship(interactable1, interactable2), Is.True);
            yield return null;

            // 2 has to come before 1.
            // Order should be: 2, 1, 3.
            manager.GetRegisteredInteractables(registeredSnapshot);
            Assert.That(registeredSnapshot,
                Is.EqualTo(new[] { interactable2, interactable1, interactable3, }));
            Assert.That(interactablesReordered, Is.EqualTo(1));

            // Make 3 a parent of 2
            // 3
            // |--2
            //    |--1
            // Order should be: 3, 2, 1
            Assert.That(manager.RegisterParentRelationship(interactable2, interactable3), Is.True);
            yield return null;

            manager.GetRegisteredInteractables(registeredSnapshot);
            Assert.That(registeredSnapshot,
                Is.EqualTo(new[] { interactable3, interactable2, interactable1, }));
            Assert.That(interactablesReordered, Is.EqualTo(2));
        }

        [Test]
        public void InteractorCanRegisterExplicitParentInteractable()
        {
            // Setting a reference to a parent interactable should allow the manager to automatically
            // register that reference as a parent interactable when the component itself is registered.

            var manager = TestUtilities.CreateInteractionManager();
            var interactable = TestUtilities.CreateSimpleInteractable();

            var interactor = TestUtilities.CreateMockInteractor();
            interactor.autoFindParentInteractableInHierarchy = false;
            interactor.parentInteractable = interactable;

            var explicitParents = new List<IXRInteractable>();

            // Parent interactable is only registered when the interactor is registered
            manager.GetParentRelationships(interactor, explicitParents);
            Assert.That(explicitParents, Is.Empty);
            manager.UnregisterInteractor((IXRInteractor)interactor);
            manager.RegisterInteractor((IXRInteractor)interactor);
            manager.GetParentRelationships(interactor, explicitParents);
            Assert.That(explicitParents, Is.EqualTo(new[] { interactable, }));
            Assert.That(interactor.parentInteractable, Is.SameAs(interactable));
            Assert.That(interactor.autoFindParentInteractableInHierarchy, Is.False);
        }

        [Test]
        public void InteractableCanRegisterExplicitParentInteractable()
        {
            // Setting a reference to a parent interactable should allow the manager to automatically
            // register that reference as a parent interactable when the component itself is registered.

            var manager = TestUtilities.CreateInteractionManager();
            var interactableParent = TestUtilities.CreateSimpleInteractable();

            var interactable = TestUtilities.CreateSimpleInteractable();
            interactable.autoFindParentInteractableInHierarchy = false;
            interactable.parentInteractable = interactableParent;

            var explicitParents = new List<IXRInteractable>();
            var inheritedParents = new List<IXRInteractable>();

            // Parent interactable is only registered when the interactable is registered
            manager.GetParentRelationships(interactable, explicitParents, inheritedParents);
            Assert.That(explicitParents, Is.Empty);
            Assert.That(inheritedParents, Is.Empty);
            manager.UnregisterInteractable((IXRInteractable)interactable);
            manager.RegisterInteractable((IXRInteractable)interactable);
            manager.GetParentRelationships(interactable, explicitParents, inheritedParents);
            Assert.That(explicitParents, Is.EqualTo(new[] { interactableParent, }));
            Assert.That(inheritedParents, Is.Empty);
            Assert.That(interactable.parentInteractable, Is.SameAs(interactableParent));
            Assert.That(interactable.autoFindParentInteractableInHierarchy, Is.False);
        }

        [Test]
        public void InteractorCanAutoFindParentInteractable()
        {
            // Enabling auto find should allow a parent GameObject interactable to be found
            // and registered as the parent interactable.

            var manager = TestUtilities.CreateInteractionManager();
            var interactable = TestUtilities.CreateSimpleInteractable();

            var interactor = TestUtilities.CreateMockInteractor();
            interactor.autoFindParentInteractableInHierarchy = true;
            interactor.parentInteractable = null;
            interactor.transform.SetParent(interactable.transform);

            var explicitParents = new List<IXRInteractable>();

            // Parent interactable is only registered when the interactor is registered
            manager.GetParentRelationships(interactor, explicitParents);
            Assert.That(explicitParents, Is.Empty);
            manager.UnregisterInteractor((IXRInteractor)interactor);
            manager.RegisterInteractor((IXRInteractor)interactor);
            manager.GetParentRelationships(interactor, explicitParents);
            Assert.That(explicitParents, Is.EqualTo(new[] { interactable, }));
            Assert.That(interactor.parentInteractable, Is.SameAs(interactable));
            Assert.That(interactor.autoFindParentInteractableInHierarchy, Is.False);
        }

        [Test]
        public void InteractableCanAutoFindParentInteractable()
        {
            // Enabling auto find should allow a parent GameObject interactable to be found
            // and registered as the parent interactable.

            var manager = TestUtilities.CreateInteractionManager();
            var interactableParent = TestUtilities.CreateSimpleInteractable();

            var interactable = TestUtilities.CreateSimpleInteractable();
            interactable.autoFindParentInteractableInHierarchy = true;
            interactable.parentInteractable = null;
            interactable.transform.SetParent(interactableParent.transform);

            var explicitParents = new List<IXRInteractable>();
            var inheritedParents = new List<IXRInteractable>();

            // Parent interactable is only registered when the interactable is registered
            manager.GetParentRelationships(interactable, explicitParents, inheritedParents);
            Assert.That(explicitParents, Is.Empty);
            Assert.That(inheritedParents, Is.Empty);
            manager.UnregisterInteractable((IXRInteractable)interactable);
            manager.RegisterInteractable((IXRInteractable)interactable);
            manager.GetParentRelationships(interactable, explicitParents);
            Assert.That(explicitParents, Is.EqualTo(new[] { interactableParent, }));
            Assert.That(inheritedParents, Is.Empty);
            Assert.That(interactable.parentInteractable, Is.SameAs(interactableParent));
            Assert.That(interactable.autoFindParentInteractableInHierarchy, Is.False);
        }

        [Test]
        public void InteractorCanDisableAutoFindParentInteractable()
        {
            // Disabling auto find should prevent the manager from auto registering a parent GameObject interactable.

            var manager = TestUtilities.CreateInteractionManager();
            var interactable = TestUtilities.CreateSimpleInteractable();

            var interactor = TestUtilities.CreateMockInteractor();
            interactor.autoFindParentInteractableInHierarchy = false;
            interactor.parentInteractable = null;
            interactor.transform.SetParent(interactable.transform);

            var explicitParents = new List<IXRInteractable>();

            // Parent interactable is only potentially registered when the interactor is registered
            manager.GetParentRelationships(interactor, explicitParents);
            Assert.That(explicitParents, Is.Empty);
            manager.UnregisterInteractor((IXRInteractor)interactor);
            manager.RegisterInteractor((IXRInteractor)interactor);
            manager.GetParentRelationships(interactor, explicitParents);
            Assert.That(explicitParents, Is.Empty);
            Assert.That(interactor.parentInteractable, Is.Null);
            Assert.That(interactor.autoFindParentInteractableInHierarchy, Is.False);
        }

        [Test]
        public void InteractableCanDisableAutoFindParentInteractable()
        {
            // Disabling auto find should prevent the manager from auto registering a parent GameObject interactable.

            var manager = TestUtilities.CreateInteractionManager();
            var interactableParent = TestUtilities.CreateSimpleInteractable();

            var interactable = TestUtilities.CreateSimpleInteractable();
            interactable.autoFindParentInteractableInHierarchy = false;
            interactable.parentInteractable = null;
            interactable.transform.SetParent(interactableParent.transform);

            var explicitParents = new List<IXRInteractable>();
            var inheritedParents = new List<IXRInteractable>();

            // Parent interactable is only potentially registered when the interactable is registered
            manager.GetParentRelationships(interactable, explicitParents, inheritedParents);
            Assert.That(explicitParents, Is.Empty);
            Assert.That(inheritedParents, Is.Empty);
            manager.UnregisterInteractable((IXRInteractable)interactable);
            manager.RegisterInteractable((IXRInteractable)interactable);
            manager.GetParentRelationships(interactable, explicitParents, inheritedParents);
            Assert.That(explicitParents, Is.Empty);
            Assert.That(inheritedParents, Is.Empty);
            Assert.That(interactable.parentInteractable, Is.Null);
            Assert.That(interactable.autoFindParentInteractableInHierarchy, Is.False);
        }

        [UnityTest]
        public IEnumerator InteractableInheritsInteractorParentInteractable()
        {
            // An interactor that has a parent interactable should automatically cause an interactable being
            // selected to inherit the parent interactable of the interactor.

            var manager = TestUtilities.CreateInteractionManager();
            var interactable1 = TestUtilities.CreateSimpleInteractable();
            var interactable2 = TestUtilities.CreateSimpleInteractable();

            var interactor = TestUtilities.CreateMockInteractor();
            interactor.keepSelectedTargetValid = false;
            interactor.autoFindParentInteractableInHierarchy = false;
            interactor.parentInteractable = interactable2;

            var explicitParents = new List<IXRInteractable>();
            var inheritedParents = new List<IXRInteractable>();

            // Parent interactable is only registered when the interactor is registered
            manager.GetParentRelationships(interactor, explicitParents);
            Assert.That(explicitParents, Is.Empty);
            manager.UnregisterInteractor((IXRInteractor)interactor);
            manager.RegisterInteractor((IXRInteractor)interactor);
            manager.GetParentRelationships(interactor, explicitParents);
            Assert.That(explicitParents, Is.EqualTo(new[] { interactable2, }));

            yield return null;

            var registeredSnapshot = new List<IXRInteractable>();
            manager.GetRegisteredInteractables(registeredSnapshot);
            Assert.That(registeredSnapshot, Is.EqualTo(new[] { interactable1, interactable2 }));

            // Make the interactor select interactable1, which should make interactor1 inherit the parent relationship to interactable2
            interactor.validTargets.Add(interactable1);
            yield return null;

            Assert.That(interactor.interactablesSelected, Is.EqualTo(new[] { interactable1 }));

            manager.GetParentRelationships(interactable1, explicitParents, inheritedParents);
            Assert.That(explicitParents, Is.Empty);
            Assert.That(inheritedParents, Is.EqualTo(new[] { interactable2, }));

            // Order should be: 2, 1
            manager.GetRegisteredInteractables(registeredSnapshot);
            Assert.That(registeredSnapshot, Is.EqualTo(new[] { interactable2, interactable1, }));

            // Inherited parents should automatically be removed once deselected
            interactor.validTargets.Clear();
            yield return null;

            Assert.That(interactor.interactablesSelected, Is.Empty);

            manager.GetParentRelationships(interactable1, explicitParents, inheritedParents);
            Assert.That(explicitParents, Is.Empty);
            Assert.That(inheritedParents, Is.Empty);
        }

        [UnityTest]
        public IEnumerator InteractableInheritsInteractorParentInteractableWhileSelected()
        {
            // An interactor that registers a parent interactable while selecting should automatically
            // cause the interactable being selected to inherit the parent interactable of the interactor.

            var manager = TestUtilities.CreateInteractionManager();
            var interactable = TestUtilities.CreateSimpleInteractable();
            var interactableParent = TestUtilities.CreateSimpleInteractable();

            var interactor = TestUtilities.CreateMockInteractor();
            interactor.keepSelectedTargetValid = false;

            var explicitParents = new List<IXRInteractable>();
            var inheritedParents = new List<IXRInteractable>();

            manager.GetParentRelationships(interactor, explicitParents);
            Assert.That(explicitParents, Is.Empty);

            yield return null;

            var registeredSnapshot = new List<IXRInteractable>();
            manager.GetRegisteredInteractables(registeredSnapshot);
            Assert.That(registeredSnapshot, Is.EqualTo(new[] { interactable, interactableParent }));

            // Make the interactor select interactable
            interactor.validTargets.Add(interactable);
            yield return null;

            Assert.That(interactor.interactablesSelected, Is.EqualTo(new[] { interactable }));

            manager.GetParentRelationships(interactable, explicitParents, inheritedParents);
            Assert.That(explicitParents, Is.Empty);
            Assert.That(inheritedParents, Is.Empty);

            // Register parent relationship to interactor, which should make interactable inherit the parent relationship to interactableParent
            Assert.That(manager.RegisterParentRelationship(interactor, interactableParent), Is.True);

            manager.GetParentRelationships(interactable, explicitParents, inheritedParents);
            Assert.That(explicitParents, Is.Empty);
            Assert.That(inheritedParents, Is.EqualTo(new[] { interactableParent, }));

            yield return null;

            // Order should now be updated after a sort
            manager.GetRegisteredInteractables(registeredSnapshot);
            Assert.That(registeredSnapshot, Is.EqualTo(new[] { interactableParent, interactable, }));

            // Inherited parents should automatically be removed once deselected
            interactor.validTargets.Clear();
            yield return null;

            Assert.That(interactor.interactablesSelected, Is.Empty);

            manager.GetParentRelationships(interactable, explicitParents, inheritedParents);
            Assert.That(explicitParents, Is.Empty);
            Assert.That(inheritedParents, Is.Empty);
        }

        [UnityTest]
        public IEnumerator UnregisteredParentInteractableExcludedFromRegisteredSnapshot()
        {
            // An unregistered interactable that is the parent interactable of another registered interactable
            // should not be included in the registered snapshot. This tests that unregistered interactables
            // are excluded when walking the parent interactable graph.

            var manager = TestUtilities.CreateInteractionManager();
            var interactable1 = TestUtilities.CreateSimpleInteractable();
            var interactable2 = TestUtilities.CreateSimpleInteractable();
            var interactable3 = TestUtilities.CreateSimpleInteractable();

            // Order should be: 3, 2, 1
            Assert.That(manager.RegisterParentRelationship(interactable2, interactable3), Is.True);
            Assert.That(manager.RegisterParentRelationship(interactable1, interactable2), Is.True);

            // Disable 2 to unregister it from the manager
            interactable2.enabled = false;

            yield return null;

            var registeredSnapshot = new List<IXRInteractable>();
            manager.GetRegisteredInteractables(registeredSnapshot);
            Assert.That(registeredSnapshot, Is.EqualTo(new[] { interactable3, interactable1, }));

            // Enable 2 to register it to the manager
            interactable2.enabled = true;

            yield return null;

            manager.GetRegisteredInteractables(registeredSnapshot);
            Assert.That(registeredSnapshot, Is.EqualTo(new[] { interactable3, interactable2, interactable1, }));
        }

        [UnityTest]
        public IEnumerator InteractableCanBePriorityForSelection()
        {
            var interactionManager = TestUtilities.CreateInteractionManager();
            var interactor1 = TestUtilities.CreateMockInteractor();
            var interactor2 = TestUtilities.CreateMockInteractor();
            var interactor3 = TestUtilities.CreateMockInteractor();
            var interactable1 = TestUtilities.CreateSimpleInteractable();
            var interactable2 = TestUtilities.CreateSimpleInteractable();

            interactor1.targetPriorityMode = TargetPriorityMode.HighestPriorityOnly;
            interactor1.targetsForSelection = new List<IXRSelectInteractable>();
            interactor2.targetPriorityMode = TargetPriorityMode.All;
            interactor2.targetsForSelection = new List<IXRSelectInteractable>();
            interactor3.targetPriorityMode = TargetPriorityMode.None;

            interactor1.validTargets.Add(interactable1);
            interactor1.validTargets.Add(interactable2);

            // interactable2 is the highest priority target for the interactor2
            interactor2.validTargets.Add(interactable2);
            interactor2.validTargets.Add(interactable1);

            interactor3.validTargets.Add(interactable1);
            interactor3.validTargets.Add(interactable2);

            yield return null;

            var interactorList = new List<IXRTargetPriorityInteractor>();
            var isInteractablePriorityForSelection = interactionManager.IsHighestPriorityTarget(interactable1, interactorList);
            Assert.That(isInteractablePriorityForSelection, Is.True);
            Assert.That(interactorList, Is.EquivalentTo(new[] { interactor1 }));

            isInteractablePriorityForSelection = interactionManager.IsHighestPriorityTarget(interactable2, interactorList);
            Assert.That(isInteractablePriorityForSelection, Is.True);
            Assert.That(interactorList, Is.EquivalentTo(new[] { interactor2 }));

            Assert.That(interactor1.targetsForSelection, Is.EquivalentTo(new[] { interactable1 }));
            Assert.That(interactor2.targetsForSelection, Is.EquivalentTo(new[] { interactable2, interactable1 }));
        }

        [UnityTest]
        public IEnumerator InteractableCanBeSelectedFromScript()
        {
            var manager = TestUtilities.CreateInteractionManager();
            var interactor = TestUtilities.CreateMockInteractor();
            var interactable = TestUtilities.CreateSimpleInteractable();

            Assert.That(interactor.interactablesSelected, Is.Empty);
            Assert.That(interactor.hasSelection, Is.False);
            Assert.That(interactable.interactorsSelecting, Is.Empty);
            Assert.That(interactable.isSelected, Is.False);

            manager.SelectEnter((IXRSelectInteractor)interactor, (IXRSelectInteractable)interactable);

            Assert.That(interactor.interactablesSelected, Is.EqualTo(new[] { interactable }));
            Assert.That(interactor.hasSelection, Is.True);
            Assert.That(interactable.interactorsSelecting, Is.EqualTo(new[] { interactor }));
            Assert.That(interactable.isSelected, Is.True);

            interactor.keepSelectedTargetValid = true;

            yield return null;

            Assert.That(interactor.interactablesSelected, Is.EqualTo(new[] { interactable }));
            Assert.That(interactor.hasSelection, Is.True);
            Assert.That(interactable.interactorsSelecting, Is.EqualTo(new[] { interactor }));
            Assert.That(interactable.isSelected, Is.True);

            manager.SelectExit((IXRSelectInteractor)interactor, (IXRSelectInteractable)interactable);

            Assert.That(interactor.interactablesSelected, Is.Empty);
            Assert.That(interactor.hasSelection, Is.False);
            Assert.That(interactable.interactorsSelecting, Is.Empty);
            Assert.That(interactable.isSelected, Is.False);
        }

        [UnityTest]
        public IEnumerator InteractableCanBeHoveredFromScript()
        {
            var manager = TestUtilities.CreateInteractionManager();
            var interactor = TestUtilities.CreateMockInteractor();
            var interactable = TestUtilities.CreateSimpleInteractable();

            Assert.That(interactor.interactablesHovered, Is.Empty);
            Assert.That(interactor.hasHover, Is.False);
            Assert.That(interactable.interactorsHovering, Is.Empty);
            Assert.That(interactable.isHovered, Is.False);

            manager.HoverEnter((IXRHoverInteractor)interactor, (IXRHoverInteractable)interactable);

            Assert.That(interactor.interactablesHovered, Is.EqualTo(new[] { interactable }));
            Assert.That(interactor.hasHover, Is.True);
            Assert.That(interactable.interactorsHovering, Is.EqualTo(new[] { interactor }));
            Assert.That(interactable.isHovered, Is.True);

            interactor.validTargets.Add(interactable);

            yield return null;

            Assert.That(interactor.interactablesHovered, Is.EqualTo(new[] { interactable }));
            Assert.That(interactor.hasHover, Is.True);
            Assert.That(interactable.interactorsHovering, Is.EqualTo(new[] { interactor }));
            Assert.That(interactable.isHovered, Is.True);

            manager.HoverExit((IXRHoverInteractor)interactor, (IXRHoverInteractable)interactable);

            Assert.That(interactor.interactablesHovered, Is.Empty);
            Assert.That(interactor.hasHover, Is.False);
            Assert.That(interactable.interactorsHovering, Is.Empty);
            Assert.That(interactable.isHovered, Is.False);
        }

        [UnityTest]
        public IEnumerator InteractableCanBeFocusedFromScript()
        {
            var manager = TestUtilities.CreateInteractionManager();
            var group = TestUtilities.CreateInteractionGroup();
            var interactor = TestUtilities.CreateMockInputInteractor();
            var interactable = TestUtilities.CreateSimpleInteractable();

            group.AddGroupMember(interactor);

            Assert.That(interactable.interactionGroupsFocusing, Is.Empty);
            Assert.That(group.focusInteractor, Is.Null);
            Assert.That(group.focusInteractable, Is.Null);

            manager.FocusEnter(interactor, interactable);

            Assert.That(interactable.interactionGroupsFocusing, Is.EqualTo(new[] { group }));
            Assert.That(group.focusInteractor, Is.EqualTo(interactor));
            Assert.That(group.focusInteractable, Is.EqualTo(interactable));

            // Focus should not automatically clear the next frame since there will not be a "select attempt" input
            // due to the interactor being a MockInputInteractor rather than a simple MockInteractor.
            Assert.That(interactor.isSelectActive, Is.False);

            yield return null;

            Assert.That(interactable.interactionGroupsFocusing, Is.EqualTo(new[] { group }));
            Assert.That(group.focusInteractor, Is.EqualTo(interactor));
            Assert.That(group.focusInteractable, Is.EqualTo(interactable));

            manager.FocusExit(group, interactable);

            Assert.That(interactable.interactionGroupsFocusing, Is.Empty);
            Assert.That(group.focusInteractor, Is.Null);
            Assert.That(group.focusInteractable, Is.Null);
        }

        [TestCase(false)]
        [TestCase(true)]
        public void InteractableCanBePreventedFromBeingSelectedFromScript(bool logInteractionPreventedWarnings)
        {
            var manager = TestUtilities.CreateInteractionManager();
            var interactor = TestUtilities.CreateMockInteractor();
            var interactable = TestUtilities.CreateSimpleInteractable();

            Assert.That(interactor.interactablesSelected, Is.Empty);
            Assert.That(interactor.hasSelection, Is.False);
            Assert.That(interactable.interactorsSelecting, Is.Empty);
            Assert.That(interactable.isSelected, Is.False);

            interactor.interactionLayers = 1;
            interactable.interactionLayers = 2;

            manager.logInteractionPreventedWarnings = logInteractionPreventedWarnings;
            if (logInteractionPreventedWarnings)
                LogAssert.Expect(LogType.Warning, new Regex("Interaction layer mask between interactor and interactable does not overlap."));

            manager.SelectEnter((IXRSelectInteractor)interactor, (IXRSelectInteractable)interactable);

            Assert.That(interactor.interactablesSelected, Is.Empty);
            Assert.That(interactor.hasSelection, Is.False);
            Assert.That(interactable.interactorsSelecting, Is.Empty);
            Assert.That(interactable.isSelected, Is.False);

            LogAssert.NoUnexpectedReceived();
        }

        [TestCase(false)]
        [TestCase(true)]
        public void InteractableCanBePreventedFromBeingHoveredFromScript(bool logInteractionPreventedWarnings)
        {
            var manager = TestUtilities.CreateInteractionManager();
            var interactor = TestUtilities.CreateMockInteractor();
            var interactable = TestUtilities.CreateSimpleInteractable();

            Assert.That(interactor.interactablesHovered, Is.Empty);
            Assert.That(interactor.hasHover, Is.False);
            Assert.That(interactable.interactorsHovering, Is.Empty);
            Assert.That(interactable.isHovered, Is.False);

            interactor.interactionLayers = 1;
            interactable.interactionLayers = 2;

            manager.logInteractionPreventedWarnings = logInteractionPreventedWarnings;
            if (logInteractionPreventedWarnings)
                LogAssert.Expect(LogType.Warning, new Regex("Interaction layer mask between interactor and interactable does not overlap."));

            manager.HoverEnter((IXRHoverInteractor)interactor, (IXRHoverInteractable)interactable);

            Assert.That(interactor.interactablesHovered, Is.Empty);
            Assert.That(interactor.hasHover, Is.False);
            Assert.That(interactable.interactorsHovering, Is.Empty);
            Assert.That(interactable.isHovered, Is.False);

            LogAssert.NoUnexpectedReceived();
        }

        [TestCase(false)]
        [TestCase(true)]
        public void InteractableCanBePreventedFromBeingFocusedFromScript(bool logInteractionPreventedWarnings)
        {
            var manager = TestUtilities.CreateInteractionManager();
            var group = TestUtilities.CreateInteractionGroup();
            var interactor = TestUtilities.CreateMockInteractor();
            var interactable = TestUtilities.CreateSimpleInteractable();

            group.AddGroupMember(interactor);

            Assert.That(interactable.interactionGroupsFocusing, Is.Empty);
            Assert.That(group.focusInteractor, Is.Null);
            Assert.That(group.focusInteractable, Is.Null);

            interactor.interactionLayers = 1;
            interactable.interactionLayers = 2;

            manager.logInteractionPreventedWarnings = logInteractionPreventedWarnings;
            if (logInteractionPreventedWarnings)
                LogAssert.Expect(LogType.Warning, new Regex("Interaction layer mask between interactor and interactable does not overlap."));

            manager.FocusEnter(interactor, interactable);

            Assert.That(interactable.interactionGroupsFocusing, Is.Empty);
            Assert.That(group.focusInteractor, Is.Null);
            Assert.That(group.focusInteractable, Is.Null);

            LogAssert.NoUnexpectedReceived();
        }

        [UnityTest]
        public IEnumerator OtherManagersDestroyedAfterFirst()
        {
            Assume.That(XRInteractionRuntimeSettings.InstanceInternal != null, Is.True);
            Assume.That(XRInteractionManager.activeInteractionManagers, Is.Empty);
            Assume.That(ComponentLocatorUtility<XRInteractionManager>.componentCache, Is.Null);

            XRInteractionRuntimeSettings.InstanceInternal.interactionManagerSingletonMode = XRInteractionRuntimeSettings.ManagerSingletonMode.EnforceSingle;

            var phases = new List<(XRInteractionManager, ComponentLifecyclePhase)>();
            XRInteractionManager.activeInteractionManagersChanged += OnActiveInteractionManagersChanged;

            var manager1 = TestUtilities.CreateInteractionManager();

            Assert.That(ComponentLocatorUtility<XRInteractionManager>.componentCache, Is.EqualTo(manager1));
            Assert.That(XRInteractionManager.activeInteractionManagers, Is.EqualTo(new[] { manager1 }));
            Assert.That(phases, Is.EqualTo(new List<(XRInteractionManager, ComponentLifecyclePhase)>()
            {
                (manager1, ComponentLifecyclePhase.Awake),
                (manager1, ComponentLifecyclePhase.Enable),
            }));
            phases.Clear();

            var manager2 = TestUtilities.CreateInteractionManager();

            Assert.That(ComponentLocatorUtility<XRInteractionManager>.componentCache, Is.EqualTo(manager1));
            Assert.That(XRInteractionManager.activeInteractionManagers, Is.EqualTo(new[] { manager1, manager2 }));
            Assert.That(phases, Is.EqualTo(new List<(XRInteractionManager, ComponentLifecyclePhase)>()
            {
                (manager2, ComponentLifecyclePhase.Awake),
                (manager2, ComponentLifecyclePhase.Enable),
                (manager2, ComponentLifecyclePhase.Disable),
            }));
            phases.Clear();

            yield return null;

            Assert.That(ComponentLocatorUtility<XRInteractionManager>.componentCache, Is.EqualTo(manager1));
            Assert.That(XRInteractionManager.activeInteractionManagers, Is.EqualTo(new[] { manager1 }));
            Assert.That(phases, Is.EqualTo(new List<(XRInteractionManager, ComponentLifecyclePhase)>()
            {
                (manager2, ComponentLifecyclePhase.Destroy),
            }));

            XRInteractionManager.activeInteractionManagersChanged -= OnActiveInteractionManagersChanged;

            void OnActiveInteractionManagersChanged(XRInteractionManager manager, ComponentLifecyclePhase phase)
            {
                phases.Add((manager, phase));
            }
        }

        [UnityTest]
        public IEnumerator OtherManagersDestroyedAfterFirstManuallyDestroyed()
        {
            Assume.That(XRInteractionRuntimeSettings.InstanceInternal != null, Is.True);
            Assume.That(XRInteractionManager.activeInteractionManagers, Is.Empty);
            Assume.That(ComponentLocatorUtility<XRInteractionManager>.componentCache, Is.Null);

            XRInteractionRuntimeSettings.InstanceInternal.interactionManagerSingletonMode = XRInteractionRuntimeSettings.ManagerSingletonMode.EnforceSingle;

            var phases = new List<(XRInteractionManager, ComponentLifecyclePhase)>();
            XRInteractionManager.activeInteractionManagersChanged += OnActiveInteractionManagersChanged;

            var manager1 = TestUtilities.CreateInteractionManager();

            Assert.That(ComponentLocatorUtility<XRInteractionManager>.componentCache, Is.EqualTo(manager1));
            Assert.That(XRInteractionManager.activeInteractionManagers, Is.EqualTo(new[] { manager1 }));
            Assert.That(phases, Is.EqualTo(new List<(XRInteractionManager, ComponentLifecyclePhase)>()
            {
                (manager1, ComponentLifecyclePhase.Awake),
                (manager1, ComponentLifecyclePhase.Enable),
            }));
            phases.Clear();

            var manager2 = TestUtilities.CreateInteractionManager();

            Assert.That(ComponentLocatorUtility<XRInteractionManager>.componentCache, Is.EqualTo(manager1));
            Assert.That(XRInteractionManager.activeInteractionManagers, Is.EqualTo(new[] { manager1, manager2 }));
            Assert.That(phases, Is.EqualTo(new List<(XRInteractionManager, ComponentLifecyclePhase)>()
            {
                (manager2, ComponentLifecyclePhase.Awake),
                (manager2, ComponentLifecyclePhase.Enable),
                (manager2, ComponentLifecyclePhase.Disable),
            }));
            phases.Clear();

            Object.Destroy(manager1);

            Assert.That(XRInteractionManager.activeInteractionManagers, Is.EqualTo(new[] { manager1, manager2 }));
            Assert.That(phases, Is.EqualTo(new List<(XRInteractionManager, ComponentLifecyclePhase)>()
            {
                (manager1, ComponentLifecyclePhase.Disable),
            }));
            phases.Clear();

            yield return null;

            // Destroying the default manager (manager1) should not select a manager marked for destruction as the new default.
            Assert.That(ComponentLocatorUtility<XRInteractionManager>.componentCache, Is.EqualTo(null));
            Assert.That(XRInteractionManager.activeInteractionManagers, Is.Empty);
            Assert.That(phases, Is.EqualTo(new List<(XRInteractionManager, ComponentLifecyclePhase)>()
            {
                (manager1, ComponentLifecyclePhase.Destroy),
                (manager2, ComponentLifecyclePhase.Destroy),
            }).Or.EqualTo(new List<(XRInteractionManager, ComponentLifecyclePhase)>()
            {
                (manager2, ComponentLifecyclePhase.Destroy),
                (manager1, ComponentLifecyclePhase.Destroy),
            }));

            XRInteractionManager.activeInteractionManagersChanged -= OnActiveInteractionManagersChanged;

            void OnActiveInteractionManagersChanged(XRInteractionManager manager, ComponentLifecyclePhase phase)
            {
                phases.Add((manager, phase));
            }
        }

        /// <summary>
        /// Interactor that enables another Interactor and Interactable during <see cref="ProcessInteractor"/>.
        /// </summary>
        class EnablerInteractor : XRBaseInteractor
        {
            public XRBaseInteractor interactor { get; set; }

            public XRBaseInteractable interactable { get; set; }

            public bool enableBehaviors { get; set; }

            /// <inheritdoc />
            public override void ProcessInteractor(XRInteractionUpdateOrder.UpdatePhase updatePhase)
            {
                base.ProcessInteractor(updatePhase);

                if (updatePhase == XRInteractionUpdateOrder.UpdatePhase.Dynamic)
                {
                    if (interactor != null)
                        interactor.enabled = enableBehaviors;

                    if (interactable != null)
                        interactable.enabled = enableBehaviors;
                }
            }

            /// <inheritdoc />
            public override void GetValidTargets(List<IXRInteractable> targets)
            {
                targets.Clear();
            }

            public static EnablerInteractor CreateInteractor()
            {
                var interactorGO = new GameObject { name = "Enabler Interactor" };
                var interactor = interactorGO.AddComponent<EnablerInteractor>();
                return interactor;
            }
        }

        /// <summary>
        /// Interactable that enables another Interactor and Interactable during <see cref="ProcessInteractable"/>.
        /// </summary>
        class EnablerInteractable : XRBaseInteractable
        {
            public XRBaseInteractor interactor { get; set; }

            public XRBaseInteractable interactable { get; set; }

            public bool enableBehaviors { get; set; }

            /// <inheritdoc />
            public override void ProcessInteractable(XRInteractionUpdateOrder.UpdatePhase updatePhase)
            {
                base.ProcessInteractable(updatePhase);

                if (updatePhase == XRInteractionUpdateOrder.UpdatePhase.Dynamic)
                {
                    if (interactor != null)
                        interactor.enabled = enableBehaviors;

                    if (interactable != null)
                        interactable.enabled = enableBehaviors;
                }
            }

            public static EnablerInteractable CreateInteractable()
            {
                var interactableGO = new GameObject { name = "Enabler Interactable" };
                var interactable = interactableGO.AddComponent<EnablerInteractable>();
                return interactable;
            }
        }

        [Test]
        public void RegisterColliderMappingAddsColliderToMap()
        {
            var manager = TestUtilities.CreateInteractionManager();
            var interactable = TestUtilities.CreateSimpleInteractable();
            var newCollider = interactable.gameObject.AddComponent<BoxCollider>();

            // New collider is not in the map since it was added after registration
            Assert.That(manager.TryGetInteractableForCollider(newCollider, out _), Is.False);

            manager.RegisterColliderMapping(newCollider, (IXRInteractable)interactable);

            Assert.That(manager.TryGetInteractableForCollider(newCollider, out var associatedInteractable), Is.True);
            Assert.That(associatedInteractable, Is.SameAs(interactable));
        }

        [Test]
        public void UnregisterColliderMappingRemovesColliderFromMap()
        {
            var manager = TestUtilities.CreateInteractionManager();
            var interactable = TestUtilities.CreateSimpleInteractable();
            var collider = interactable.colliders.First();

            Assert.That(manager.TryGetInteractableForCollider(collider, out _), Is.True);

            manager.UnregisterColliderMapping(collider, (IXRInteractable)interactable);

            Assert.That(manager.TryGetInteractableForCollider(collider, out _), Is.False);
        }

        [Test]
        public void UnregisterColliderMappingDoesNotRemoveOtherInteractableMapping()
        {
            var manager = TestUtilities.CreateInteractionManager();
            var firstInteractable = TestUtilities.CreateSimpleInteractable();
            var secondInteractable = TestUtilities.CreateSimpleInteractable();
            var collider = firstInteractable.colliders.First();

            Assert.That(manager.TryGetInteractableForCollider(collider, out var associatedInteractable), Is.True);
            Assert.That(associatedInteractable, Is.SameAs(firstInteractable));

            // Attempting to unregister the mapping with a different interactable should not remove it
            manager.UnregisterColliderMapping(collider, (IXRInteractable)secondInteractable);

            Assert.That(manager.TryGetInteractableForCollider(collider, out associatedInteractable), Is.True);
            Assert.That(associatedInteractable, Is.SameAs(firstInteractable));
        }

        [Test]
        public void RegisterColliderMappingWarnsOnDuplicateCollider()
        {
            var manager = TestUtilities.CreateInteractionManager();
            var firstInteractable = TestUtilities.CreateSimpleInteractable();
            var secondInteractable = TestUtilities.CreateSimpleInteractable();
            var collider = firstInteractable.colliders.First();

            LogAssert.Expect(LogType.Warning, new Regex("A collider used by an Interactable object is already registered with another Interactable object*"));
            manager.RegisterColliderMapping(collider, (IXRInteractable)secondInteractable);

            // Original mapping should be preserved
            Assert.That(manager.TryGetInteractableForCollider(collider, out var associatedInteractable), Is.True);
            Assert.That(associatedInteractable, Is.SameAs(firstInteractable));
        }

        [Test]
        public void UpdateInteractableColliderMappingsDiffsPreviousAndCurrent()
        {
            var manager = TestUtilities.CreateInteractionManager();
            var interactable = TestUtilities.CreateSimpleInteractable();
            var originalCollider = interactable.colliders.First();
            var newCollider = interactable.gameObject.AddComponent<BoxCollider>();

            // Snapshot previous, then swap colliders
            var previousColliders = new List<Collider>(interactable.colliders);
            interactable.colliders.Clear();
            interactable.colliders.Add(newCollider);

            manager.UpdateInteractableColliderMappings((IXRInteractable)interactable, previousColliders);

            // Old collider removed, new collider added
            Assert.That(manager.TryGetInteractableForCollider(originalCollider, out _), Is.False);
            Assert.That(manager.TryGetInteractableForCollider(newCollider, out var associatedInteractable), Is.True);
            Assert.That(associatedInteractable, Is.SameAs(interactable));
        }

        [Test]
        public void InteractableRegisterColliderAddsToMapAndList()
        {
            var manager = TestUtilities.CreateInteractionManager();
            var interactable = TestUtilities.CreateSimpleInteractable();
            var newCollider = interactable.gameObject.AddComponent<BoxCollider>();

            Assert.That(interactable.colliders, Has.Count.EqualTo(1));
            Assert.That(manager.TryGetInteractableForCollider(newCollider, out _), Is.False);

            var result = interactable.RegisterCollider(newCollider);

            Assert.That(result, Is.True);
            Assert.That(interactable.colliders, Has.Count.EqualTo(2));
            Assert.That(interactable.colliders, Contains.Item(newCollider));
            Assert.That(manager.TryGetInteractableForCollider(newCollider, out var associatedInteractable), Is.True);
            Assert.That(associatedInteractable, Is.SameAs(interactable));
        }

        [Test]
        public void InteractableRegisterColliderReturnsFalseForDuplicate()
        {
            var manager = TestUtilities.CreateInteractionManager();
            var interactable = TestUtilities.CreateSimpleInteractable();
            var existingCollider = interactable.colliders.First();

            var result = interactable.RegisterCollider(existingCollider);

            Assert.That(result, Is.False);
            Assert.That(interactable.colliders, Has.Count.EqualTo(1));
        }

        [Test]
        public void InteractableRegisterColliderReturnsFalseForNull()
        {
            var manager = TestUtilities.CreateInteractionManager();
            var interactable = TestUtilities.CreateSimpleInteractable();

            var result = interactable.RegisterCollider(null);

            Assert.That(result, Is.False);
        }

        [Test]
        public void InteractableRegisterColliderAllowsTriggerColliders()
        {
            var manager = TestUtilities.CreateInteractionManager();
            var interactable = TestUtilities.CreateSimpleInteractable();
            var triggerCollider = interactable.gameObject.AddComponent<BoxCollider>();
            triggerCollider.isTrigger = true;

            var result = interactable.RegisterCollider(triggerCollider);

            Assert.That(result, Is.True);
            Assert.That(interactable.colliders, Contains.Item(triggerCollider));
            Assert.That(manager.TryGetInteractableForCollider(triggerCollider, out var associatedInteractable), Is.True);
            Assert.That(associatedInteractable, Is.SameAs(interactable));
        }

        [Test]
        public void InteractableUnregisterColliderRemovesFromMapAndList()
        {
            var manager = TestUtilities.CreateInteractionManager();
            var interactable = TestUtilities.CreateSimpleInteractable();
            var collider = interactable.colliders.First();

            Assert.That(manager.TryGetInteractableForCollider(collider, out _), Is.True);

            var result = interactable.UnregisterCollider(collider);

            Assert.That(result, Is.True);
            Assert.That(interactable.colliders, Has.Count.EqualTo(0));
            Assert.That(manager.TryGetInteractableForCollider(collider, out _), Is.False);
        }

        [Test]
        public void InteractableUnregisterColliderReturnsFalseForUnknownCollider()
        {
            var manager = TestUtilities.CreateInteractionManager();
            var interactable = TestUtilities.CreateSimpleInteractable();
            var otherGO = new GameObject("Other");
            var otherCollider = otherGO.AddComponent<BoxCollider>();

            var result = interactable.UnregisterCollider(otherCollider);

            Assert.That(result, Is.False);
        }

        [Test]
        public void InteractableCollidersChangedEventFiresOnRegisterCollider()
        {
            var manager = TestUtilities.CreateInteractionManager();
            var interactable = TestUtilities.CreateSimpleInteractable();
            var newCollider = interactable.gameObject.AddComponent<BoxCollider>();
            CollidersChangedEventArgs receivedArgs = null;
            interactable.collidersChanged += (args) => receivedArgs = args;

            interactable.RegisterCollider(newCollider);

            Assert.That(receivedArgs, Is.Not.Null);
            Assert.That(receivedArgs.interactable, Is.EqualTo(interactable));
            Assert.That(receivedArgs.updateType, Is.EqualTo(ColliderUpdateType.Added));
            Assert.That(receivedArgs.collider, Is.EqualTo(newCollider));
        }

        [Test]
        public void InteractableCollidersChangedEventFiresOnUnregisterCollider()
        {
            var manager = TestUtilities.CreateInteractionManager();
            var interactable = TestUtilities.CreateSimpleInteractable();
            var existingCollider = interactable.colliders.First();
            CollidersChangedEventArgs receivedArgs = null;
            interactable.collidersChanged += (args) => receivedArgs = args;

            interactable.UnregisterCollider(existingCollider);

            Assert.That(receivedArgs, Is.Not.Null);
            Assert.That(receivedArgs.interactable, Is.EqualTo(interactable));
            Assert.That(receivedArgs.updateType, Is.EqualTo(ColliderUpdateType.Removed));
            Assert.That(receivedArgs.collider, Is.EqualTo(existingCollider));
        }

        [Test]
        public void InteractableRefreshCollidersUpdatesMap()
        {
            var manager = TestUtilities.CreateInteractionManager();
            var interactable = TestUtilities.CreateSimpleInteractable();
            var originalCollider = interactable.colliders.First();

            // Add a new collider to the hierarchy (not yet in the interactable's list)
            var newCollider = interactable.gameObject.AddComponent<BoxCollider>();
            Assert.That(manager.TryGetInteractableForCollider(newCollider, out _), Is.False);

            interactable.RefreshColliders();

            // Both colliders should now be in the map
            Assert.That(interactable.colliders, Has.Count.EqualTo(2));
            Assert.That(manager.TryGetInteractableForCollider(originalCollider, out _), Is.True);
            Assert.That(manager.TryGetInteractableForCollider(newCollider, out var associatedInteractable), Is.True);
            Assert.That(associatedInteractable, Is.SameAs(interactable));
        }

        [Test]
        public void InteractableRefreshCollidersExcludesTriggersByDefault()
        {
            var manager = TestUtilities.CreateInteractionManager();
            var interactable = TestUtilities.CreateSimpleInteractable();
            var triggerCollider = interactable.gameObject.AddComponent<BoxCollider>();
            triggerCollider.isTrigger = true;

            interactable.RefreshColliders();

            Assert.That(interactable.colliders, Has.No.Member(triggerCollider));
        }

        [Test]
        public void InteractableRefreshCollidersIncludesTriggersWhenFlagged()
        {
            var manager = TestUtilities.CreateInteractionManager();
            var interactable = TestUtilities.CreateSimpleInteractable();
            var triggerCollider = interactable.gameObject.AddComponent<BoxCollider>();
            triggerCollider.isTrigger = true;

            interactable.RefreshColliders(includeTriggerColliders: true);

            Assert.That(interactable.colliders, Contains.Item(triggerCollider));
        }

        [UnityTest]
        public IEnumerator PokeFilterRecoversWhenCollidersRefreshed()
        {
            var manager = TestUtilities.CreateInteractionManager();

            // Create interactable without a collider so XRPokeFilter disables itself at Start
            var go = new GameObject("Poke Interactable");
            var interactable = go.AddComponent<XRSimpleInteractable>();
            var filter = go.AddComponent<XRPokeFilter>();

            yield return null; // Let Start() run

            // Filter should be disabled since no collider was found
            Assert.That(filter.enabled, Is.False);

            // Add a collider and refresh
            go.AddComponent<BoxCollider>();
            interactable.RefreshColliders();

            Assert.That(filter.enabled, Is.True);
            Assert.That(filter.pokeCollider, Is.Not.Null);
        }

        [Test]
        public void InteractableRefreshCollidersDoesNotFireEventWhenUnchanged()
        {
            var manager = TestUtilities.CreateInteractionManager();
            var interactable = TestUtilities.CreateSimpleInteractable();
            CollidersChangedEventArgs receivedArgs = null;
            interactable.collidersChanged += (args) => receivedArgs = args;

            // Refresh without any changes — event should not fire
            interactable.RefreshColliders();

            Assert.That(receivedArgs, Is.Null);
        }

        [Test]
        public void InteractableRefreshCollidersSkipsCollidersRegisteredWithOtherInteractable()
        {
            var manager = TestUtilities.CreateInteractionManager();

            // Create a parent interactable with no serialized colliders so Awake auto-discovers children.
            var parentGO = new GameObject("Parent Interactable");
            parentGO.AddComponent<Rigidbody>().isKinematic = true;
            var parentInteractable = parentGO.AddComponent<XRSimpleInteractable>();

            // Create a child with its own interactable and collider.
            var childGO = new GameObject("Child Interactable");
            childGO.transform.SetParent(parentGO.transform);
            childGO.AddComponent<Rigidbody>().isKinematic = true;
            var childCollider = childGO.AddComponent<SphereCollider>();
            var childInteractable = childGO.AddComponent<XRSimpleInteractable>();

            // Child collider is registered with the child interactable.
            Assert.That(manager.TryGetInteractableForCollider(childCollider, out var associatedInteractable), Is.True);
            Assert.That(associatedInteractable, Is.SameAs(childInteractable));

            // RefreshColliders on the parent should skip the child's collider
            // since it is already registered with the child interactable.
            parentInteractable.RefreshColliders();

            Assert.That(parentInteractable.colliders, Has.No.Member(childCollider));
            Assert.That(manager.TryGetInteractableForCollider(childCollider, out associatedInteractable), Is.True);
            Assert.That(associatedInteractable, Is.SameAs(childInteractable));
        }

        [UnityTest]
        public IEnumerator InteractableDisableEnablePreservesDynamicColliders()
        {
            var manager = TestUtilities.CreateInteractionManager();
            var interactable = TestUtilities.CreateSimpleInteractable();
            var newCollider = interactable.gameObject.AddComponent<BoxCollider>();

            interactable.RegisterCollider(newCollider);
            Assert.That(interactable.colliders, Has.Count.EqualTo(2));
            Assert.That(manager.TryGetInteractableForCollider(newCollider, out _), Is.True);

            // Disable — unregisters from manager
            interactable.enabled = false;

            yield return null;

            Assert.That(manager.TryGetInteractableForCollider(newCollider, out _), Is.False);
            // Collider should still be in the interactable's list
            Assert.That(interactable.colliders, Has.Count.EqualTo(2));
            Assert.That(interactable.colliders, Contains.Item(newCollider));

            // Re-enable — re-registers with manager, including the dynamically added collider
            interactable.enabled = true;

            yield return null;

            Assert.That(manager.TryGetInteractableForCollider(newCollider, out var associatedInteractable), Is.True);
            Assert.That(associatedInteractable, Is.SameAs(interactable));
        }

        [UnityTest]
        public IEnumerator InteractableRegisterColliderBeforeManagerRegistration()
        {
            var manager = TestUtilities.CreateInteractionManager();

            // Create interactable but disable it before it registers
            var go = new GameObject("Unregistered Interactable");
            go.SetActive(false);
            go.AddComponent<Rigidbody>().isKinematic = true;
            var interactable = go.AddComponent<XRSimpleInteractable>();
            var collider = go.AddComponent<BoxCollider>();

            // RegisterCollider before the interactable is registered with the manager
            interactable.RegisterCollider(collider);

            Assert.That(interactable.colliders, Contains.Item(collider));
            // Not in the map yet since the interactable isn't registered
            Assert.That(manager.TryGetInteractableForCollider(collider, out _), Is.False);

            // Enable — triggers registration with the manager
            go.SetActive(true);

            yield return null;

            // Now the collider should be in the map via normal RegisterInteractable
            Assert.That(manager.TryGetInteractableForCollider(collider, out var associatedInteractable), Is.True);
            Assert.That(associatedInteractable, Is.SameAs(interactable));
        }

        [UnityTest]
        public IEnumerator InteractableCollidersCleanedUpAfterColliderDestroyed()
        {
            // Simulates the UIDocument disable/re-enable case where the collider is
            // destroyed on disable and a new one is created on re-enable.
            // Verifies that stale destroyed collider references are cleaned up and
            // the new collider is properly registered.
            var manager = TestUtilities.CreateInteractionManager();
            var go = new GameObject("UITK Interactable");
            go.AddComponent<Rigidbody>().isKinematic = true;
            var interactable = go.AddComponent<XRSimpleInteractable>();

            // Simulate UIDocument creating a collider dynamically
            var collider = go.AddComponent<BoxCollider>();
            interactable.RegisterCollider(collider);

            Assert.That(interactable.colliders, Has.Count.EqualTo(1));
            Assert.That(manager.TryGetInteractableForCollider(collider, out _), Is.True);

            // Simulate UIDocument destroying its collider on disable
            interactable.UnregisterCollider(collider);
            Object.Destroy(collider);

            yield return null;

            Assert.That(interactable.colliders, Has.Count.EqualTo(0));
            Assert.That(manager.TryGetInteractableForCollider(collider, out _), Is.False);

            // Simulate UIDocument creating a new collider on re-enable
            var newCollider = go.AddComponent<BoxCollider>();
            interactable.RegisterCollider(newCollider);

            Assert.That(interactable.colliders, Has.Count.EqualTo(1));
            Assert.That(interactable.colliders, Contains.Item(newCollider));
            Assert.That(manager.TryGetInteractableForCollider(newCollider, out var associatedInteractable), Is.True);
            Assert.That(associatedInteractable, Is.SameAs(interactable));
        }

        [UnityTest]
        public IEnumerator InteractableRefreshCollidersRemovesDestroyedColliderReferences()
        {
            // Verifies that RefreshColliders cleans up destroyed collider references
            // from the colliders list, matching the UIDocument disable/re-enable scenario.
            var manager = TestUtilities.CreateInteractionManager();
            var interactable = TestUtilities.CreateSimpleInteractable();
            var collider = interactable.colliders.First();

            Assert.That(manager.TryGetInteractableForCollider(collider, out _), Is.True);

            // Destroy the collider — simulates UIDocument.RemoveWorldSpaceCollider
            Object.Destroy(collider);

            yield return null;

            // RefreshColliders should remove the destroyed reference and update the map
            interactable.RefreshColliders();

            Assert.That(interactable.colliders, Has.Count.EqualTo(0));
            Assert.That(manager.TryGetInteractableForCollider(collider, out _), Is.False);
        }

        [UnityTest]
        public IEnumerator PokeFilterUpdatesColliderReferenceWhenColliderReplaced()
        {
            var manager = TestUtilities.CreateInteractionManager();

            // Create interactable with a collider and poke filter.
            var go = new GameObject("Poke Interactable");
            go.AddComponent<Rigidbody>().isKinematic = true;
            var interactable = go.AddComponent<XRSimpleInteractable>();
            var originalCollider = go.AddComponent<BoxCollider>();

            var filter = go.AddComponent<XRPokeFilter>();

            yield return null; // Let Start() run

            Assert.That(filter.enabled, Is.True);
            Assert.That(filter.pokeCollider, Is.EqualTo(originalCollider));

            // Destroy the original collider and register a new one.
            interactable.UnregisterCollider(originalCollider);
            Object.Destroy(originalCollider);

            yield return null;

            var newCollider = go.AddComponent<BoxCollider>();
            interactable.RegisterCollider(newCollider);

            // Poke filter should update its collider reference via collidersChanged.
            Assert.That(filter.enabled, Is.True);
            Assert.That(filter.pokeCollider, Is.EqualTo(newCollider));
        }

    }
}
