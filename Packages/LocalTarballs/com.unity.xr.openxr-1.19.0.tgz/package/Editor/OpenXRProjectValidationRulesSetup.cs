using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;
using UnityEditor;
using UnityEditor.Build;
using UnityEditor.Build.Reporting;
using UnityEditor.Callbacks;
using UnityEditor.PackageManager;
using UnityEngine.XR.OpenXR;
#if XR_COMPOSITION_LAYERS
using UnityEngine.XR.OpenXR.Features.CompositionLayers;
#endif
using UnityEngine.XR.OpenXR.Features;
using Unity.XR.CoreUtils.Editor;
using UnityEditor.XR.Management;
using UnityEngine.XR.Management;
using UnityEngine;
#if LIFECYCLE_APIS_AVAILABLE
using Unity.Scripting.LifecycleManagement;
#endif


[assembly: InternalsVisibleTo("UnityEditor.XR.OpenXR.Tests")]
namespace UnityEditor.XR.OpenXR
{
    internal class OpenXRProjectValidationRulesSetup
    {
        const string k_FeaturesRefreshedSessionKey = "com.unity.xr.openxr.featuresRefreshed";

#if LIFECYCLE_APIS_AVAILABLE
        // Static lookup table populated once at declaration and never mutated.
        [NoAutoStaticsCleanup]
#endif
        static BuildTargetGroup[] s_BuildTargetGroups =
            ((BuildTargetGroup[])Enum.GetValues(typeof(BuildTargetGroup))).Distinct().ToArray();

#if LIFECYCLE_APIS_AVAILABLE
        // Editor UI selection state, unrelated to Play mode sessions.
        [NoAutoStaticsCleanup]
#endif
        static BuildTargetGroup s_SelectedBuildTargetGroup = BuildTargetGroup.Unknown;

        internal const string OpenXRProjectValidationSettingsPath = "Project/XR Plug-in Management/Project Validation";

        [InitializeOnLoadMethod]
        static void OpenXRProjectValidationCheck()
        {
            if (UnityEditor.MPE.ProcessService.level != UnityEditor.MPE.ProcessLevel.Main || AssetDatabase.IsAssetImportWorkerProcess())
                return;

            if (UnityEngine.Application.isBatchMode)
            {
                UpdateOpenXRProjectValidation();
            }
            else
            {
                EditorApplication.update += UpdateOpenXRProjectValidation;
            }
        }

        static void UpdateOpenXRProjectValidation()
        {
            EditorApplication.update -= UpdateOpenXRProjectValidation;

            UnityEditor.PackageManager.Events.registeredPackages += (packageRegistrationEventArgs) =>
            {
                // In the Player Settings UI we have to delay the call one frame to let OpenXRSettings constructor to get initialized
                EditorApplication.delayCall += () =>
                {
                    if (HasXRPackageVersionChanged(packageRegistrationEventArgs))
                    {
                        ShowWindowIfIssuesExist();
                    }
                };
            };

            if (!UnityEngine.Application.isBatchMode)
            {
                AddOpenXRValidationRules();
            }
        }

        private static bool HasXRPackageVersionChanged(PackageRegistrationEventArgs packageRegistrationEventArgs)
        {
            bool packageChanged = packageRegistrationEventArgs.changedTo.Any(p => p.name.Equals(OpenXRManagementSettings.PackageId));
            OpenXRSettings.Instance.versionChanged = packageChanged;
            return packageRegistrationEventArgs.added.Any(p => p.name.Equals(OpenXRManagementSettings.PackageId)) || packageChanged;
        }

        private static void ShowWindowIfIssuesExist()
        {
            List<OpenXRFeature.ValidationRule> failures = new List<OpenXRFeature.ValidationRule>();
            BuildTargetGroup activeBuildTargetGroup = BuildPipeline.GetBuildTargetGroup(EditorUserBuildSettings.activeBuildTarget);
            OpenXRProjectValidation.GetCurrentValidationIssues(failures, activeBuildTargetGroup);

            if (failures.Count > 0)
                ShowWindow();
        }

        internal static BuildValidationRule ConvertRuleToBuildValidationRule(OpenXRFeature.ValidationRule rule, BuildTargetGroup buildTargetGroup)
        {
            Type featureType = null;
            if (rule.feature != null)
            {
                featureType = rule.feature.GetType();
            }

            return new BuildValidationRule
            {
                // This will hide the rules given a condition so that when you click "Show all" it doesn't show up as passed
                IsRuleEnabled = () =>
                {
                    // If OpenXR isn't enabled, no need to show the rule
                    if (!BuildHelperUtils.HasActiveLoader(buildTargetGroup, typeof(OpenXRLoaderBase)))
                        return false;

                    // If a rule specific feature isn't enabled, don't show this rule
                    if (featureType != null)
                    {
                        OpenXRSettings openXrSettings = OpenXRSettings.GetSettingsForBuildTargetGroup(buildTargetGroup);
                        if (openXrSettings == null)
                            return false;

                        OpenXRFeature feature = openXrSettings.GetFeature(featureType);
                        if (feature == null || !feature.enabled)
                            return false;
                    }

                    return true;
                },
                CheckPredicate = rule.checkPredicate,
                Error = rule.error,
                FixIt = rule.fixIt,
                FixItAutomatic = rule.fixItAutomatic,
                FixItMessage = rule.fixItMessage,
                HelpLink = rule.helpLink,
                HelpText = rule.helpText,
                HighlighterFocus = new BuildValidationRule.HighlighterFocusData
                {
                    WindowTitle = rule.highlighterFocus.windowTitle,
                    SearchText = rule.highlighterFocus.searchText
                },
                Message = rule.message,
                Category = rule.feature != null ? rule.feature.nameUi : "OpenXR",
                SceneOnlyValidation = false
            };
        }

        static void AddOpenXRValidationRules()
        {
            var isRefreshedThisSession = SessionState.GetBool(k_FeaturesRefreshedSessionKey, false);

            foreach (var buildTargetGroup in s_BuildTargetGroups)
            {
                bool isOpenXRSupportedPlatform = buildTargetGroup == BuildTargetGroup.Standalone || buildTargetGroup == BuildTargetGroup.Android;
                if (!isOpenXRSupportedPlatform)
                    continue;

                // Only refresh features the first time the Editor is opened.
                if (!isRefreshedThisSession)
                    Features.FeatureHelpers.RefreshFeatures(buildTargetGroup);

                var coreIssues = new List<BuildValidationRule>();
                if (buildTargetGroup == BuildTargetGroup.Android)
                {
                    coreIssues.Add(VulkanOffscreenSwapchainAndroidValidationRule());
                }
                var issues = new List<OpenXRFeature.ValidationRule>();
                OpenXRProjectValidation.GetAllValidationIssues(issues, buildTargetGroup);

                foreach (var issue in issues)
                {
                    coreIssues.Add(ConvertRuleToBuildValidationRule(issue, buildTargetGroup));
                }

                BuildValidator.AddRules(buildTargetGroup, coreIssues);
            }

            if (!isRefreshedThisSession)
                SessionState.SetBool(k_FeaturesRefreshedSessionKey, true);
        }

        static BuildValidationRule VulkanOffscreenSwapchainAndroidValidationRule()
        {
            // Validation rule to inform user that main display will be disabled on all platforms when the
            // OpenXREditorSettings.VulkanOffscreenSwapchainNoMainDisplay setting is enabled.
            return new BuildValidationRule
            {
                // If OpenXR isn't enabled, no need to show the rule
                IsRuleEnabled = () => BuildHelperUtils.HasActiveLoader(BuildTargetGroup.Android, typeof(OpenXRLoaderBase)),
                Message = "When OpenXR loader is enabled and the OpenXR setting 'Offscreen Rendering Only (Vulkan)' is checked then main display " +
                          "is disabled on all Android platforms.",
                CheckPredicate = () =>
                {
                    if (!OpenXREditorSettings.Instance.VulkanOffscreenSwapchainNoMainDisplay)
                        return true;

                    var generalSettings = XRGeneralSettingsPerBuildTarget.XRGeneralSettingsForBuildTarget(BuildTargetGroup.Android);
                    if (generalSettings == null)
                        return true;

                    if (generalSettings.Manager == null)
                        return true;

                    // Check whether any other Android loader is enabled besides OpenXR
                    return generalSettings.Manager.activeLoaders.Count == 1;
                },
                FixItMessage = $"Disables the Offscreen Rendering Only (Vulkan) setting in Project Settings > XR Plug-in Management > OpenXR.",
                FixIt = () =>
                {
                    OpenXREditorSettings.Instance.VulkanOffscreenSwapchainNoMainDisplay = false;
                },
                Category = "OpenXR",
                Error = false,
            };
        }

        [MenuItem("Window/XR/OpenXR/Project Validation")]
        private static void MenuItem()
        {
            ShowWindow();
        }

        internal static void SetSelectedBuildTargetGroup(BuildTargetGroup buildTargetGroup)
        {
            if (s_SelectedBuildTargetGroup == buildTargetGroup)
                return;

            s_SelectedBuildTargetGroup = buildTargetGroup;
        }

        internal static void ShowWindow(BuildTargetGroup buildTargetGroup = BuildTargetGroup.Unknown)
        {
            // Delay opening the window since sometimes other settings in the player settings provider redirect to the
            // project validation window causing serialized objects to be nullified
            EditorApplication.delayCall += () =>
            {
                SetSelectedBuildTargetGroup(buildTargetGroup);
                SettingsService.OpenProjectSettings(OpenXRProjectValidationSettingsPath);
            };
        }

        internal static void CloseWindow() { }
    }

    internal class OpenXRProjectValidationBuildStep : IPreprocessBuildWithReport
    {
        [OnOpenAsset(0)]
#if UNITY_6000_4_OR_NEWER
        static bool ConsoleErrorDoubleClicked(EntityId id, int line)
#else
        static bool ConsoleErrorDoubleClicked(int id, int line)
#endif
        {
#if UNITY_6000_3_OR_NEWER
            var objName = EditorUtility.EntityIdToObject(id).name;
#else
            var objName = EditorUtility.InstanceIDToObject(id).name;
#endif
            if (objName == "OpenXRProjectValidation")
            {
                OpenXRProjectValidationRulesSetup.ShowWindow();
                return true;
            }

            return false;
        }

        public int callbackOrder { get; }

        public void OnPreprocessBuild(BuildReport report)
        {
            if (!BuildHelperUtils.HasActiveLoader(report.summary.platformGroup, typeof(OpenXRLoaderBase)))
                return;

            if (OpenXRProjectValidation.LogBuildValidationIssues(report.summary.platformGroup))
                throw new BuildFailedException("OpenXR Build Failed.");
        }
    }
}
