using System;
using System.Linq;
using UnityEngine;
using UnityEngine.XR.OpenXR;
using UnityEditor.XR.OpenXR.Features;
using UnityEngine.Rendering;
#if LIFECYCLE_APIS_AVAILABLE
using Unity.Scripting.LifecycleManagement;
#endif

namespace UnityEditor.XR.OpenXR
{
    [CustomEditor(typeof(OpenXRPackageSettings))]
    internal class PackageSettingsEditor : UnityEditor.Editor
    {
        OpenXRFeatureEditor m_FeatureEditor = null;
        Vector2 scrollPos = Vector2.zero;
#if XR_MGMT_3_2_0_OR_NEWER
        OpenXRManagementSettings managementSettings = new();
#endif

#if XR_MGMT_4_1_0_OR_OLDER
#if LIFECYCLE_APIS_AVAILABLE
        // Manually unregistered/reassigned in Awake() as a workaround for a fixed XRManagement bug;
        // opt out to keep behavior identical to older Unity versions.
        [NoAutoStaticsCleanup]
#endif
        static PackageSettingsEditor s_LastPackageSettingsEditor = null;
#endif

        static class Content
        {
            public const float k_Space = 15.0f;

#if LIFECYCLE_APIS_AVAILABLE
            // Static UI label caches; content never changes at runtime.
            [NoAutoStaticsCleanup]
#endif
            public static readonly GUIContent k_renderModeLabel = new GUIContent("Render Mode", "Choose the rendering strategy.");
#if LIFECYCLE_APIS_AVAILABLE
            [NoAutoStaticsCleanup]
#endif
            public static readonly GUIContent k_vulkanAdditionalGraphicsQueue = new GUIContent("Additional Graphics Queue (Vulkan)", "Request an additional Vulkan graphics queue for its own rendering at startup.");
#if LIFECYCLE_APIS_AVAILABLE
            [NoAutoStaticsCleanup]
#endif
            public static readonly GUIContent k_vulkanOffscreenSwapchainNoMainDisplay = new GUIContent("Offscreen Rendering Only (Vulkan)", "Enabled offscreen swapchains and stops allocations for the main display buffer. This setting should be disabled for handheld platforms.");

#if LIFECYCLE_APIS_AVAILABLE
            [NoAutoStaticsCleanup]
#endif
            public static readonly GUIContent[] k_renderModeOptions = new GUIContent[2]
            {
                new GUIContent("Multi-pass"),
                new GUIContent("Single Pass Instanced"),
            };

#if LIFECYCLE_APIS_AVAILABLE
            [NoAutoStaticsCleanup]
#endif
            public static readonly GUIContent[] k_androidRenderModeOptions = new GUIContent[2]
            {
                new GUIContent("Multi-pass"),
                new GUIContent("Single Pass Instanced \\ Multi-view"),
            };

#if LIFECYCLE_APIS_AVAILABLE
            [NoAutoStaticsCleanup]
#endif
            public static readonly GUIContent k_latencyOptimization = new GUIContent("Latency Optimization", "Choose how the OpenXR plug-in minimizes latency for input polling or rendering.");
        }

        private void Awake()
        {
            m_FeatureEditor = OpenXRFeatureEditor.CreateFeatureEditor();

#if XR_MGMT_4_1_0_OR_OLDER
            // Due to a bug in XRManagement that was fixed in builds newer than 4.1.0 the OnDestroy method
            // is not called when the old package settings editor is abandoned.  This causes the OnUpdateFeatureSetState
            // event handlers to pile up unecessarily.  To fix this we maintain a static reference to the last editor
            // that Awake was called on and unregister the event handler.
            if (s_LastPackageSettingsEditor != null)
            {
                OpenXRFeatureSetManager.onFeatureSetStateChanged -=
                    s_LastPackageSettingsEditor.OnFeatureSetStateChanged;
            }

            s_LastPackageSettingsEditor = this;
#endif

            OpenXRFeatureSetManager.onFeatureSetStateChanged += OnFeatureSetStateChanged;
        }

        private void OnDestroy()
        {
            OpenXRFeatureSetManager.onFeatureSetStateChanged -= OnFeatureSetStateChanged;
        }

        public void OnEnable()
        {
            OpenXRRuntimeSelector.RefreshRuntimeDetectorList();
        }

        public override void OnInspectorGUI()
        {
            var buildTargetGroup = EditorGUILayout.BeginBuildTargetSelectionGrouping();
            OpenXRProjectValidationRulesSetup.SetSelectedBuildTargetGroup(buildTargetGroup);

#if XR_MGMT_3_2_0_OR_NEWER
            if (
                !managementSettings.metadata.loaderMetadata[0].supportedBuildTargets.Contains(
                    buildTargetGroup
                )
            )
            {
                EditorGUILayout.EndBuildTargetSelectionGrouping();
                return;
            }
#endif

            OpenXRPackageSettings settings = serializedObject.targetObject as OpenXRPackageSettings;

            scrollPos = EditorGUILayout.BeginScrollView(scrollPos);

            EditorGUI.BeginDisabledGroup(EditorApplication.isPlaying);

            EditorGUILayout.BeginVertical();

            var openXrSettings = settings.GetSettingsForBuildTargetGroup(buildTargetGroup);
            var serializedOpenXrSettings = new SerializedObject(openXrSettings);

            var openXrEditorSettings = OpenXREditorSettings.Instance;
            var serializedOpenXrEditorSettings = new SerializedObject(openXrEditorSettings);

            EditorGUIUtility.labelWidth = 210;

            int newRenderMode;
            GUILayout.BeginHorizontal();
            if (buildTargetGroup == BuildTargetGroup.Android)
            {
                newRenderMode = EditorGUILayout.Popup(
                    Content.k_renderModeLabel,
                    (int)openXrSettings.renderMode,
                    Content.k_androidRenderModeOptions
                );
            }
            else
            {
                newRenderMode = EditorGUILayout.Popup(
                    Content.k_renderModeLabel,
                    (int)openXrSettings.renderMode,
                    Content.k_renderModeOptions
                );
            }

            if (newRenderMode != (int)openXrSettings.renderMode)
            {
                openXrSettings.renderMode = (OpenXRSettings.RenderMode)newRenderMode;
            }

            GUILayout.EndHorizontal();
            GUILayout.BeginHorizontal();

            var newAutoColorSubmissionMode = EditorGUILayout.Toggle(
                new GUIContent("Auto Color Submission Mode", "Automatically select the default color submission mode."),
                openXrSettings.autoColorSubmissionMode
            );
            if (newAutoColorSubmissionMode != openXrSettings.autoColorSubmissionMode)
            {
                openXrSettings.autoColorSubmissionMode = newAutoColorSubmissionMode;
            }

            GUILayout.EndHorizontal();
            GUILayout.BeginHorizontal();

            if (!openXrSettings.autoColorSubmissionMode)
            {
                EditorGUI.PropertyField(
                    new(new(0, 0), new(0, 0)),
                    serializedOpenXrSettings.FindProperty("m_colorSubmissionModes")
                );
            }

            GUILayout.EndHorizontal();

            GUILayout.BeginHorizontal();

            EditorGUILayout.PropertyField(
                serializedOpenXrSettings.FindProperty("m_latencyOptimization"),
                Content.k_latencyOptimization
            );

            GUILayout.EndHorizontal();

            DrawPropertiesExcluding(
                serializedOpenXrSettings,
                "m_Script",
                "m_foveatedRenderingApi",
                "m_renderMode",
                "m_autoColorSubmissionMode",
                "m_latencyOptimization",
                "m_colorSubmissionModes",
                "m_symmetricProjection",
                "m_optimizeBufferDiscards",
                "m_vulkanAdditionalGraphicsQueue",
                "m_vulkanOffscreenSwapchainNoMainDisplay",
                "m_multiviewRenderRegionsOptimizationMode",
                "m_spacewarpMotionVectorTextureFormat",
                "m_ApiLayers"
            );
            if (
                buildTargetGroup == BuildTargetGroup.Android
                || buildTargetGroup == BuildTargetGroup.Standalone
            )
            {
                serializedOpenXrEditorSettings
                    .FindProperty("m_vulkanAdditionalGraphicsQueue")
                    .boolValue = EditorGUILayout.Toggle(
                    Content.k_vulkanAdditionalGraphicsQueue,
                    openXrEditorSettings.VulkanAdditionalGraphicsQueue
                );
            }

            if (buildTargetGroup == BuildTargetGroup.Android)
            {
                serializedOpenXrEditorSettings
                    .FindProperty("m_vulkanOffscreenSwapchainNoMainDisplay")
                    .boolValue = EditorGUILayout.Toggle(
                    Content.k_vulkanOffscreenSwapchainNoMainDisplay,
                    openXrEditorSettings.VulkanOffscreenSwapchainNoMainDisplay
                );
            }

            EditorGUIUtility.labelWidth = 0;

            if (serializedOpenXrSettings.hasModifiedProperties)
                serializedOpenXrSettings.ApplyModifiedProperties();
            if (serializedOpenXrEditorSettings.hasModifiedProperties)
                serializedOpenXrEditorSettings.ApplyModifiedProperties();

            if (buildTargetGroup == BuildTargetGroup.Standalone)
            {
                EditorGUILayout.Space();
                OpenXRRuntimeSelector.DrawSelector();
            }

            EditorGUILayout.EndVertical();

            if (m_FeatureEditor != null)
            {
                EditorGUILayout.Space();
                m_FeatureEditor.OnGUI(buildTargetGroup);
            }
            EditorGUI.EndDisabledGroup();

            EditorGUILayout.EndBuildTargetSelectionGrouping();

            EditorGUILayout.EndScrollView();
        }

        /// <summary>
        /// Helper method to force the project settings window to repaint.
        /// </summary>
        private static void RepaintProjectSettingsWindow()
        {
            var type = Type.GetType("UnityEditor.ProjectSettingsWindow,UnityEditor");
            if (null == type)
                return;

            var window = Resources.FindObjectsOfTypeAll(type).FirstOrDefault() as EditorWindow;
            if (window != null)
                window.Repaint();
        }

        private void OnFeatureSetStateChanged(BuildTargetGroup buildTargetGroup)
        {
            if (null == m_FeatureEditor)
                return;

            m_FeatureEditor.OnFeatureSetStateChanged(buildTargetGroup);

            RepaintProjectSettingsWindow();
        }
    }
}
