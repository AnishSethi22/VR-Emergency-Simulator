using System;
using System.Collections.Generic;
using System.Linq;
using UnityEditor.MPE;
using UnityEngine;
using UnityEngine.XR.OpenXR;
using UnityEngine.XR.OpenXR.Features;
#if LIFECYCLE_APIS_AVAILABLE
using Unity.Scripting.LifecycleManagement;
#endif

namespace UnityEditor.XR.OpenXR.Features
{
    /// <summary>
    /// API for finding and managing feature sets for OpenXR.
    /// </summary>
    public static class OpenXRFeatureSetManager
    {
        [InitializeOnLoadMethod]
        static void InitializeOnLoad()
        {
            OpenXRFeature.canSetFeatureDisabled = CanFeatureBeDisabled;
            EditorApplication.update += OnFirstUpdate;
            return;

            void OnFirstUpdate()
            {
                EditorApplication.update -= OnFirstUpdate;
                // Early out if this is invoked inside a secondary process (e.g. Standalone Profiler)
                if ((uint)ProcessService.level == (uint)ProcessLevel.Secondary || AssetDatabase.IsAssetImportWorkerProcess())
                    return;
                InitializeFeatureSets();
            }
        }

        /// <summary>
        /// Description of a known (either built-in or found) feature set.
        /// </summary>
        public class FeatureSet
        {
            /// <summary>
            /// Toggles the enabled state for this feature. Impacts the effect of <see cref="OpenXRFeatureSetManager.SetFeaturesFromEnabledFeatureSets"/>.
            /// If you change this value, you must call <see cref="OpenXRFeatureSetManager.SetFeaturesFromEnabledFeatureSets"/> to reflect that change on the actual feature sets.
            /// </summary>
            public bool isEnabled;

            /// <summary>
            /// The name that displays in the UI.
            /// </summary>
            public string name;

            /// <summary>
            /// Description of this feature set.
            /// </summary>
            public string description;

            /// <summary>
            /// The feature set id as defined in <see cref="OpenXRFeatureSetAttribute.FeatureSetId"/>.
            /// </summary>
            public string featureSetId;

            /// <summary>
            /// The text to be shown with the <see cref="downloadLink" />.
            /// </summary>
            public string downloadText;

            /// <summary>
            /// The URI string used to link to external documentation.
            /// </summary>
            public string downloadLink;

            /// <summary>
            /// The set of features that this feature set menages.
            /// </summary>
            public string[] featureIds;

            /// <summary>
            /// State that tracks whether this feature set is built in or was detected after the user installed it.
            /// </summary>
            public bool isInstalled;

            /// <summary>
            /// The set of required features that this feature set manages.
            /// </summary>
            public string[] requiredFeatureIds;

            /// <summary>
            /// The set of default features that this feature set manages.
            /// </summary>
            public string[] defaultFeatureIds;
        }

        internal class FeatureSetInfo : FeatureSet
        {
            public GUIContent uiName;
            public GUIContent uiLongName;
            public GUIContent uiDescription;
            public GUIContent helpIcon;

            /// <summary>
            /// Stores the previous known value of isEnabled as of the last call to `SetFeaturesFromEnabledFeatureSets`
            /// </summary>
            public bool wasEnabled;
        }

#if LIFECYCLE_APIS_AVAILABLE
        // Populated once via [InitializeOnLoadMethod], which doesn't re-run on Play mode transitions, so
        // opt out to keep behavior identical to older Unity versions.
        [NoAutoStaticsCleanup]
#endif
        static Dictionary<BuildTargetGroup, List<FeatureSetInfo>> s_AllFeatureSets;

        struct FeatureSetState
        {
            public HashSet<string> featureSetFeatureIds;
            public HashSet<string> requiredToEnabledFeatureIds;
            public HashSet<string> requiredToDisabledFeatureIds;
            public HashSet<string> defaultToEnabledFeatureIds;
        }

#if LIFECYCLE_APIS_AVAILABLE
        // Reflects the project's feature-set configuration; unrelated to Play mode sessions.
        [NoAutoStaticsCleanup]
#endif
        static Dictionary<BuildTargetGroup, FeatureSetState> s_FeatureSetState = new();

        /// <summary>
        /// Event called when the feature set state has been changed.
        /// </summary>
#if LIFECYCLE_APIS_AVAILABLE
        [NoAutoStaticsCleanup]
#endif
        internal static event Action<BuildTargetGroup> onFeatureSetStateChanged;

        /// <summary>
        /// The current active build target. Used to handle callbacks from <see cref="OpenXRFeature.enabled" /> into
        /// <see cref="CanFeatureBeDisabled" /> to determine if a feature can currently be disabled.
        /// </summary>
#if LIFECYCLE_APIS_AVAILABLE
        // Editor UI/build-target selection state, unrelated to Play mode sessions.
        [NoAutoStaticsCleanup]
#endif
        public static BuildTargetGroup activeBuildTarget = BuildTargetGroup.Unknown;

        static void FillKnownFeatureSets(bool addTestFeatureSet = false)
        {
            BuildTargetGroup[] buildTargetGroups =
                { BuildTargetGroup.Standalone, BuildTargetGroup.Android };

            if (addTestFeatureSet)
            {
                foreach (var buildTargetGroup in buildTargetGroups)
                {
                    var knownFeatureSets = new List<FeatureSetInfo>();
                    if (addTestFeatureSet)
                    {
                        knownFeatureSets.Add(new FeatureSetInfo
                        {
                            isEnabled = false,
                            name = "Known Test",
                            featureSetId = "com.unity.xr.test.featureset",
                            description = "Known Test feature group.",
                            downloadText = "Click here to go to the Unity main website.",
                            downloadLink = Constants.k_DocumentationURL,
                            uiName = new GUIContent("Known Test"),
                            uiDescription = new GUIContent("Known Test feature group."),
                            helpIcon = new GUIContent("", CommonContent.k_HelpIcon.image, "Click here to go to the Unity main website."),
                        });
                    }
                    s_AllFeatureSets.Add(buildTargetGroup, knownFeatureSets);
                }
            }

            foreach (var kvp in KnownFeatureSets.k_KnownFeatureSets)
            {
                if (!s_AllFeatureSets.TryGetValue(kvp.Key, out var knownFeatureSets))
                {
                    knownFeatureSets = new List<FeatureSetInfo>();
                    foreach (var featureSet in kvp.Value)
                    {
                        knownFeatureSets.Add(new FeatureSetInfo
                        {
                            isEnabled = false,
                            name = featureSet.name,
                            featureSetId = featureSet.featureSetId,
                            description = featureSet.description,
                            downloadText = featureSet.downloadText,
                            downloadLink = featureSet.downloadLink,
                            uiName = new GUIContent(featureSet.name),
                            uiLongName = new GUIContent($"{featureSet.name} feature group"),
                            uiDescription = new GUIContent(featureSet.description),
                            helpIcon = new GUIContent("", CommonContent.k_HelpIcon.image, featureSet.downloadText),
                        });
                    }
                    s_AllFeatureSets.Add(kvp.Key, knownFeatureSets);
                }
            }
        }

        /// <summary>
        /// Initializes all currently known feature sets. This will do two initialization passes:
        ///
        /// 1) Starts with all built in/known feature sets.
        /// 2) Queries the system for anything with an <see cref="OpenXRFeatureSetAttribute"/>
        /// defined on it and uses that to add/update the store of known feature sets.
        /// </summary>
        public static void InitializeFeatureSets()
        {
            InitializeFeatureSets(false);
        }

        internal static void InitializeFeatureSets(bool addTestFeatureSet)
        {
            s_AllFeatureSets ??= new Dictionary<BuildTargetGroup, List<FeatureSetInfo>>();
            s_AllFeatureSets.Clear();

            FillKnownFeatureSets(addTestFeatureSet);

            var types = TypeCache.GetTypesWithAttribute<OpenXRFeatureSetAttribute>();
            foreach (var t in types)
            {
                var attrs = Attribute.GetCustomAttributes(t);
                foreach (var attr in attrs)
                {
                    if (attr is not OpenXRFeatureSetAttribute featureSetAttr)
                        continue;

                    if (!addTestFeatureSet && featureSetAttr.FeatureSetId.Contains("com.unity.xr.test.featureset"))
                        continue;

                    foreach (var buildTargetGroup in featureSetAttr.SupportedBuildTargets)
                    {
                        if (!s_AllFeatureSets.ContainsKey(buildTargetGroup))
                            s_AllFeatureSets.Add(buildTargetGroup, new List<FeatureSetInfo>());

                        var isEnabled = OpenXREditorSettings.Instance.IsFeatureSetSelected(
                            buildTargetGroup, featureSetAttr.FeatureSetId);

                        var newFeatureSet = new FeatureSetInfo
                        {
                            isEnabled = isEnabled,
                            wasEnabled = isEnabled,
                            name = featureSetAttr.UiName,
                            description = featureSetAttr.Description,
                            featureSetId = featureSetAttr.FeatureSetId,
                            downloadText = "",
                            downloadLink = "",
                            featureIds = featureSetAttr.FeatureIds,
                            requiredFeatureIds = featureSetAttr.RequiredFeatureIds,
                            defaultFeatureIds = featureSetAttr.DefaultFeatureIds,
                            isInstalled = true,
                            uiName = new GUIContent(featureSetAttr.UiName),
                            uiLongName = new GUIContent($"{featureSetAttr.UiName} feature group"),
                            uiDescription = new GUIContent(featureSetAttr.Description),
                            helpIcon = string.IsNullOrEmpty(featureSetAttr.Description)
                                ? null
                                : new GUIContent("", CommonContent.k_HelpIcon.image, featureSetAttr.Description),
                        };

                        bool foundFeatureSet = false;
                        var featureSets = s_AllFeatureSets[buildTargetGroup];
                        for (int i = 0; i < featureSets.Count; i++)
                        {
                            if (string.Compare(featureSets[i].featureSetId, newFeatureSet.featureSetId, true) == 0)
                            {
                                foundFeatureSet = true;
                                featureSets[i] = newFeatureSet;
                                break;
                            }
                        }

                        if (!foundFeatureSet)
                            featureSets.Add(newFeatureSet);
                    }
                }
            }

            var buildTargetGroups = Enum.GetValues(typeof(BuildTargetGroup));
            foreach (BuildTargetGroup buildTargetGroup in buildTargetGroups)
            {
                if (!s_FeatureSetState.TryGetValue(buildTargetGroup, out var fsi))
                {
                    fsi = new FeatureSetState
                    {
                        featureSetFeatureIds = new HashSet<string>(),
                        requiredToEnabledFeatureIds = new HashSet<string>(),
                        requiredToDisabledFeatureIds = new HashSet<string>(),
                        defaultToEnabledFeatureIds = new HashSet<string>()
                    };

                    s_FeatureSetState.Add(buildTargetGroup, fsi);
                }

                FeatureHelpers.RefreshFeatures(buildTargetGroup);
                SetFeaturesFromEnabledFeatureSets(buildTargetGroup);
            }
        }

        /// <summary>
        /// Returns the list of all <see cref="FeatureSet"/> for the given build target group.
        /// </summary>
        /// <param name="buildTargetGroup">The build target group to find the feature sets for.</param>
        /// <returns>List of <see cref="FeatureSet"/> or null if there is nothing that matches the given input.</returns>
        public static List<FeatureSet> FeatureSetsForBuildTarget(BuildTargetGroup buildTargetGroup)
        {
            return FeatureSetInfosForBuildTarget(buildTargetGroup).Select(fi => fi as FeatureSet).ToList();
        }

        internal static List<FeatureSetInfo> FeatureSetInfosForBuildTarget(BuildTargetGroup buildTargetGroup)
        {
            var ret = new List<FeatureSetInfo>();
            var featureSetsForBuildTargetGroup = new HashSet<FeatureSetInfo>();

            if (s_AllFeatureSets == null)
                InitializeFeatureSets();

            if (s_AllFeatureSets == null)
                return ret;

            foreach (var key in s_AllFeatureSets.Keys)
            {
                if (key == buildTargetGroup)
                {
                    featureSetsForBuildTargetGroup.UnionWith(s_AllFeatureSets[key]);
                }
            }

            ret.AddRange(featureSetsForBuildTargetGroup);
            return ret;
        }

        /// <summary>
        /// Returns a specific <see cref="FeatureSet"/> instance that matches the input.
        /// </summary>
        /// <param name="buildTargetGroup">The build target group this feature set supports.</param>
        /// <param name="featureSetId">The feature set id for the specific feature set being requested.</param>
        /// <returns>The matching <see cref="FeatureSet"/> or null.</returns>
        public static FeatureSet GetFeatureSetWithId(BuildTargetGroup buildTargetGroup, string featureSetId)
        {
            return GetFeatureSetInfoWithId(buildTargetGroup, featureSetId);
        }

        internal static FeatureSetInfo GetFeatureSetInfoWithId(BuildTargetGroup buildTargetGroup, string featureSetId)
        {
            var featureSets = FeatureSetInfosForBuildTarget(buildTargetGroup);
            if (featureSets != null)
            {
                foreach (var featureSet in featureSets)
                {
                    if (string.Compare(featureSet.featureSetId, featureSetId, true) == 0)
                        return featureSet;
                }
            }
            return null;
        }

        /// <summary>
        /// Given the current enabled state of the feature sets that match for a build target group, enable and disable the features associated with
        /// each feature set. Features that overlap sets of varying enabled states will maintain their enabled setting.
        /// </summary>
        /// <param name="buildTargetGroup">The build target group to process features sets for.</param>
        public static void SetFeaturesFromEnabledFeatureSets(BuildTargetGroup buildTargetGroup)
        {
            var extInfo = FeatureHelpersInternal.GetAllFeatureInfo(buildTargetGroup);
            SetFeaturesFromEnabledFeatureSets(buildTargetGroup, extInfo);
        }

        internal static void SetFeaturesFromEnabledFeatureSets(
            BuildTargetGroup buildTargetGroup, FeatureHelpersInternal.AllFeatureInfo extInfo)
        {
            var featureSets = FeatureSetInfosForBuildTarget(buildTargetGroup);

            var fsi = s_FeatureSetState[buildTargetGroup];

            fsi.featureSetFeatureIds.Clear();
            foreach (var featureSet in featureSets)
            {
                if (featureSet.featureIds != null)
                    fsi.featureSetFeatureIds.UnionWith(featureSet.featureIds);
            }

            fsi.featureSetFeatureIds.Clear();
            fsi.requiredToEnabledFeatureIds.Clear();
            fsi.requiredToDisabledFeatureIds.Clear();
            fsi.defaultToEnabledFeatureIds.Clear();

            // Update the selected feature set states first
            foreach (var featureSet in featureSets)
            {
                if (featureSet.featureIds == null)
                    continue;

                OpenXREditorSettings.Instance.SetFeatureSetSelected(
                    buildTargetGroup, featureSet.featureSetId, featureSet.isEnabled);
            }

            foreach (var featureSet in featureSets)
            {
                if (featureSet.featureIds == null)
                    continue;

                if (featureSet.isEnabled && featureSet.requiredFeatureIds != null)
                {
                    fsi.requiredToEnabledFeatureIds.UnionWith(featureSet.requiredFeatureIds);
                }

                if (featureSet.isEnabled != featureSet.wasEnabled)
                {
                    if (featureSet.isEnabled && featureSet.defaultFeatureIds != null)
                    {
                        fsi.defaultToEnabledFeatureIds.UnionWith(featureSet.defaultFeatureIds);
                    }
                    else if (!featureSet.isEnabled && featureSet.requiredFeatureIds != null)
                    {
                        fsi.requiredToDisabledFeatureIds.UnionWith(featureSet.requiredFeatureIds);
                    }

                    featureSet.wasEnabled = featureSet.isEnabled;
                }
            }

            foreach (var ext in extInfo.Features)
            {
                if (ext.Feature.enabled && fsi.requiredToDisabledFeatureIds.Contains(ext.Attribute.FeatureId))
                    ext.Feature.enabled = false;

                if (!ext.Feature.enabled && fsi.requiredToEnabledFeatureIds.Contains(ext.Attribute.FeatureId))
                    ext.Feature.enabled = true;

                if (!ext.Feature.enabled && fsi.defaultToEnabledFeatureIds.Contains(ext.Attribute.FeatureId))
                    ext.Feature.enabled = true;
            }

            s_FeatureSetState[buildTargetGroup] = fsi;

            onFeatureSetStateChanged?.Invoke(buildTargetGroup);
        }

        /// <summary>
        /// Tell the user if the feature with passed in feature id can be disabled.
        ///
        /// Uses the currently set <see cref="activeBuildTarget" /> to determine
        /// the BuildTargetGroup to use for checking against. If this value is not set, or
        /// set for a different build target than expected then return value may be incorrect.
        /// </summary>
        /// <param name="featureId">The feature id of the feature to check.</param>
        /// <returns>True if currently required by some feature set, false otherwise.</returns>
        internal static bool CanFeatureBeDisabled(string featureId)
        {
            return CanFeatureBeDisabled(featureId, activeBuildTarget);
        }

        /// <summary>
        /// Tell the user if the feature with passed in feature id can be disabled based on the build target group.
        /// </summary>
        /// <param name="featureId">The feature id of the feature to check.</param>
        /// <param name="buildTargetGroup">The build target group whose feature sets you are checking against.</param>
        /// <returns>True if currently required by some feature set, false otherwise.</returns>
        public static bool CanFeatureBeDisabled(string featureId, BuildTargetGroup buildTargetGroup)
        {
            if (!s_FeatureSetState.TryGetValue(buildTargetGroup, out var fsi))
                return true;

            return !fsi.requiredToEnabledFeatureIds.Contains(featureId);
        }

        internal static bool IsKnownFeatureSet(BuildTargetGroup buildTargetGroup, string featureSetId)
        {
            if (!KnownFeatureSets.k_KnownFeatureSets.TryGetValue(buildTargetGroup, out var set))
                return false;

            var featureSets = set.Where(fs => fs.featureSetId == featureSetId);
            return featureSets.Any();
        }
    }
}
