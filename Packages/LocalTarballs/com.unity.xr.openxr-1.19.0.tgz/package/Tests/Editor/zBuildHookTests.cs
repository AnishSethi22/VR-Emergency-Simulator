using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using NUnit.Framework;
using UnityEditor.XR.OpenXR.Features;
using UnityEngine.XR.OpenXR.Features.Mock;
using UnityEditor.Build.Reporting;
using UnityEngine;
using UnityEngine.XR.Management;
using UnityEngine.XR.OpenXR.Tests;
using Assert = UnityEngine.Assertions.Assert;
#if LIFECYCLE_APIS_AVAILABLE
using Unity.Scripting.LifecycleManagement;
#endif

namespace UnityEditor.XR.OpenXR.Tests
{
    // If you change this file, be sure to run the "no players" tests on yamato.
    // APV jobs don't include "players" such as standalone, so `BuildMockPlayer()`
    // will fail during APV.  The "no players" job on yamato will catch this.
    // Level carried as a Property, not a Category: every test here is [Explicit], and a
    // Level.Build category sweep would count as an explicit match and run them.
    [NUnit.Framework.Property("PyramidLevel", "Build")]
    [NUnit.Framework.Property("Covers", "BuildPipeline")]
    class zBuildHookTests : OpenXRLoaderSetup
    {
        internal static BuildReport BuildMockPlayer()
        {
            BuildPlayerOptions opts = new BuildPlayerOptions();
#if UNITY_EDITOR_WIN
            opts.target = BuildTarget.StandaloneWindows64;
#elif UNITY_EDITOR_OSX
            opts.target = BuildTarget.StandaloneOSX;
#endif
            if (File.Exists("Assets/main.unity"))
                opts.scenes = new string[] { "Assets/main.unity" };
            opts.targetGroup = BuildTargetGroup.Standalone;
            opts.locationPathName = "mocktest/mocktest.exe";

            // Note: LogAssert requires an active test log scope, so this must be called from
            // within a test body (not from EditorApplication.delayCall or similar deferred callbacks).
            UnityEngine.TestTools.LogAssert.ignoreFailingMessages = true;
            try
            {
                EditorUserBuildSettings.SwitchActiveBuildTarget(BuildTargetGroup.Standalone, opts.target);
                return BuildPipeline.BuildPlayer(opts);
            }
            finally
            {
                UnityEngine.TestTools.LogAssert.ignoreFailingMessages = false;
            }
        }

        [Test]
        [Category("BuildUnitTest"), Explicit]
        [Description("Building a mock player invokes OnPreprocessBuildExt and OnPostprocessBuildExt on the " +
                     "feature's build hooks; the build result itself is asserted only on the OpenXR Yamato " +
                     "lanes.")]
        public void PrePostCallbacksAreReceived()
        {
            bool preprocessCalled = false;
            bool postprocessCalled = false;

            BuildCallbacks.TestCallback = (methodName, _) =>
            {
                switch (methodName)
                {
                    case "OnPreprocessBuildExt":
                        preprocessCalled = true;
                        break;
                    case "OnPostprocessBuildExt":
                        postprocessCalled = true;
                        break;
                }

                return true;
            };

            var result = BuildMockPlayer();

            if (Environment.GetEnvironmentVariable("UNITY_OPENXR_YAMATO") == "1")
                Assert.IsTrue(result.summary.result == BuildResult.Succeeded);
            else if (result.summary.result != BuildResult.Succeeded)
                return;

            Assert.IsTrue(preprocessCalled);
            Assert.IsTrue(postprocessCalled);
        }

        [Test]
        [Timeout(800000)]
        [Category("BuildUnitTest"), Explicit]
        [Description("With the Mock Runtime feature disabled, a player build invokes none of its build " +
                     "hooks.")]
        public void NoBuildCallbacksFeatureDisabled()
        {
            bool preprocessCalled = false;
            bool postprocessCalled = false;

            BuildCallbacks.TestCallback = (methodName, _) =>
            {
                switch (methodName)
                {
                    case "OnPreprocessBuildExt":
                        preprocessCalled = true;
                        break;
                    case "OnPostprocessBuildExt":
                        postprocessCalled = true;
                        break;
                }

                return true;
            };

            // Disable mock runtime, no callbacks should occur during build
            EnableFeature<MockRuntime>(false);
            BuildMockPlayer();
            Assert.IsFalse(preprocessCalled);
            Assert.IsFalse(postprocessCalled);
        }

        [Test]
        [Category("BuildUnitTest"), Explicit]
        [Description("With the OpenXR loader removed from XR Management, a player build invokes no OpenXR " +
                     "feature build hooks.")]
        public void NoBuildCallbacksOpenXRDisabled()
        {
            bool preprocessCalled = false;
            bool postprocessCalled = false;

            BuildCallbacks.TestCallback = (methodName, _) =>
            {
                switch (methodName)
                {
                    case "OnPreprocessBuildExt":
                        preprocessCalled = true;
                        break;
                    case "OnPostprocessBuildExt":
                        postprocessCalled = true;
                        break;
                }

                return true;
            };

            // Remove OpenXR Loader, no callbacks should occur during build
            var loaders = XRGeneralSettings.Instance.Manager.activeLoaders;
            XRGeneralSettings.Instance.Manager.TrySetLoaders(new List<XRLoader>());
            BuildMockPlayer();
            XRGeneralSettings.Instance.Manager.TrySetLoaders(new List<XRLoader>(loaders));
            Assert.IsFalse(preprocessCalled);
            Assert.IsFalse(postprocessCalled);
        }

        [Test]
        [Category("BuildUnitTest"), Explicit]
        [Description("Boot-config values set in OnProcessBootConfigExt are readable in OnPostprocessBuildExt " +
                     "and are cleaned out of the user build settings once the build finishes.")]
        public void VerifyBootConfigWrite()
        {
            bool preprocessCalled = false;
            bool postprocessCalled = false;

            BootConfigTests.TestCallback = (methodName, _) =>
            {
                switch (methodName)
                {
                    case "OnPreprocessBuildExt":
                        preprocessCalled = true;
                        break;
                    case "OnPostprocessBuildExt":
                        postprocessCalled = true;
                        break;
                }

                return true;
            };

            var result = BuildMockPlayer();
            BuildMockPlayer();
            Assert.IsFalse(preprocessCalled);
            Assert.IsFalse(postprocessCalled);

            BootConfigTests.EnsureCleanupFromLastRun();
        }

        static bool HasOpenXRLibraries(BuildReport report)
        {
            var path = Path.GetDirectoryName(report.summary.outputPath);
            var dir = new DirectoryInfo(path);

            var ext = "dll";
            if (Application.platform == RuntimePlatform.OSXEditor)
                ext = "dylib";

            var dlls = dir.EnumerateFiles($"*.{ext}", SearchOption.AllDirectories).Select(s => s.Name).ToList();
            return dlls.Contains($"openxr_loader.{ext}") || dlls.Contains($"UnityOpenXR.{ext}");
        }

        [Test]
        [Category("BuildUnitTest"), Explicit]
        [Description("A player built with the OpenXR loader active ships the openxr_loader/UnityOpenXR " +
                     "native library, and one built with the loader removed does not.")]
        public void VerifyBuildOutputLibraries()
        {
            var resultWithOpenXR = BuildMockPlayer();

            // Disable this test if we're not running our openxr yamato infrastructure
            if (resultWithOpenXR.summary.result != BuildResult.Succeeded && Environment.GetEnvironmentVariable("UNITY_OPENXR_YAMATO") != "1")
                return;

            Assert.IsTrue(HasOpenXRLibraries(resultWithOpenXR));

            // Remove OpenXR Loader
            XRGeneralSettings.Instance.Manager.TrySetLoaders(new List<XRLoader>());
            var resultWithoutOpenXR = BuildMockPlayer();
            Assert.IsFalse(HasOpenXRLibraries(resultWithoutOpenXR));
        }

        [Test]
        [Category("BuildUnitTest"), Explicit]
        [Description("A player build still succeeds after com.unity.analytics is removed from the project; " +
                     "asserted only on the OpenXR Yamato lanes.")]
        public void VerifyBuildWithoutAnalytics()
        {
            var packageName = "com.unity.analytics";
            PackageManager.Client.Remove(packageName);

            var result = BuildMockPlayer();

            if (Environment.GetEnvironmentVariable("UNITY_OPENXR_YAMATO") == "1")
                Assert.IsTrue(result.summary.result == BuildResult.Succeeded);
        }

        internal class BuildCallbacks : OpenXRFeatureBuildHooks
        {
#if LIFECYCLE_APIS_AVAILABLE
            [NoAutoStaticsCleanup]
#endif
            [NonSerialized] internal static Func<string, object, bool> TestCallback = (methodName, param) => true;

            public override int callbackOrder => 1;
            public override Type featureType => typeof(MockRuntime);

            protected override void OnPreprocessBuildExt(BuildReport report)
            {
                TestCallback(MethodBase.GetCurrentMethod().Name, report);
            }

            protected override void OnPostGenerateGradleAndroidProjectExt(string path)
            {
                TestCallback(MethodBase.GetCurrentMethod().Name, path);
            }

            protected override void OnPostprocessBuildExt(BuildReport report)
            {
                TestCallback(MethodBase.GetCurrentMethod().Name, report);
            }

            protected override void OnProcessBootConfigExt(BuildReport report, BootConfigBuilder builder)
            {
                TestCallback(MethodBase.GetCurrentMethod().Name, report);
            }
        }

        internal class BootConfigTests : OpenXRFeatureBuildHooks
        {
#if LIFECYCLE_APIS_AVAILABLE
            [NoAutoStaticsCleanup]
#endif
            [NonSerialized] internal static Func<string, object, bool> TestCallback = (methodName, param) => true;

            public override int callbackOrder => 1;
            public override Type featureType => typeof(MockRuntime);

            // For this test, we want to ensure that the last run actually cleans up any settings that we've
            // stored into the boot settings of the EditorUserBuildSettings. We need the last run BuildReport
            // in order to check the EditorUserBuildSettings.
#if LIFECYCLE_APIS_AVAILABLE
            [NoAutoStaticsCleanup]
#endif
            private static BuildReport s_lastRunBuildReport;

            protected override void OnPreprocessBuildExt(BuildReport report)
            {
            }

            protected override void OnPostGenerateGradleAndroidProjectExt(string path)
            {
            }

            protected override void OnPostprocessBuildExt(BuildReport report)
            {
                // check to see if we've got the boot config written into the UserSettings
                var bootConfig = new BootConfig(report);
                bootConfig.ReadBootConfig();
                Assert.IsTrue(bootConfig.TryGetValue("key-01", out var key01Value));
                Assert.AreEqual(key01Value, "primary test value");
                Assert.IsTrue(bootConfig.TryGetValue("key-02", out var key02Value));
                Assert.AreEqual(key02Value, "secondary test value");
                Assert.IsTrue(bootConfig.TryGetValue("key-03", out var key03Value));
                Assert.AreEqual(key03Value, "1");
                Assert.IsTrue(bootConfig.TryGetValue("key-04", out var key04Value));
                Assert.AreEqual(key04Value, "0");

                s_lastRunBuildReport = report;
            }

            protected override void OnProcessBootConfigExt(BuildReport report, BootConfigBuilder builder)
            {
                // Now we set some boot config values and check to make sure they're there.
                builder.SetBootConfigValue("key-01", "primary test value");
                builder.SetBootConfigValue("key-02", "secondary test value");
                builder.SetBootConfigBoolean("key-03", true);
                builder.SetBootConfigBoolean("key-04", false);
                Assert.IsTrue(builder.TryGetBootConfigValue("key-01", out var result01));
                Assert.AreEqual(result01, "primary test value");
                Assert.IsTrue(builder.TryGetBootConfigValue("key-02", out var result02));
                Assert.AreEqual(result02, "secondary test value");
                Assert.IsTrue(builder.TryGetBootConfigBoolean("key-03", out var result03));
                Assert.IsTrue(result03);
                Assert.IsTrue(builder.TryGetBootConfigBoolean("key-04", out var result04));
                Assert.IsFalse(result04);
                builder.SetBootConfigValue("key-05", "remove-me");
                Assert.IsTrue(builder.TryRemoveBootConfigEntry("key-05"));
                Assert.IsFalse(builder.TryGetBootConfigValue("key-05", out var result05)); // unused in the test?
                Assert.IsFalse(builder.TryGetBootConfigBoolean("key-999", out var result06));
                Assert.IsFalse(result06);
            }

            public static void EnsureCleanupFromLastRun()
            {
                // make sure that the UserSettings doesn't hold any additional configs we've previously written
                if (s_lastRunBuildReport == null)
                    return;

                var bootConfig = new BootConfig(s_lastRunBuildReport);
                bootConfig.ReadBootConfig();
                Assert.IsFalse(bootConfig.TryGetValue("key-01", out _));
                Assert.IsFalse(bootConfig.TryGetValue("key-02", out _));
                Assert.IsFalse(bootConfig.TryGetValue("key-03", out _));
                Assert.IsFalse(bootConfig.TryGetValue("key-04", out _));
                Assert.IsFalse(bootConfig.TryGetValue("key-05", out _));

                s_lastRunBuildReport = null;
            }
        }
    }
}
