using System;
using System.Collections;
using System.Linq;
using System.Collections.Generic;
using NUnit.Framework;
using UnityEditor.Build.Reporting;
using UnityEditor.XR.OpenXR.Features;
using UnityEngine;
using UnityEngine.TestTools;
using UnityEngine.XR.OpenXR.Features;
using UnityEngine.XR.OpenXR.Features.Interactions;
using UnityEngine.XR.OpenXR.Features.Mock;
using Assert = UnityEngine.Assertions.Assert;
using UnityEngine.XR.OpenXR.Tests;
using static UnityEditor.XR.OpenXR.Tests.OpenXREditorTestHelpers;

namespace UnityEditor.XR.OpenXR.Tests
{
    [Category("Level.Integration")]
    [NUnit.Framework.Property("Covers", "Features")]
    class FeatureTests : OpenXRLoaderSetup
    {
        public override void AfterTest()
        {
            base.AfterTest();
            ClearFeatureInfos();
        }

        [Test]
        [Description("Toggling the Mock Runtime feature's enabled flag through its FeatureInfo is reflected " +
                     "on the live MockRuntime instance.")]
        public void EnableFeatures()
        {
            var featureInfos = GetFeatureInfos(BuildTargetGroup.Standalone);
            featureInfos.SingleOrDefault(ext => ext.Attribute.UiName == "Mock Runtime").Feature.enabled = true;
            Assert.IsTrue(MockRuntime.Instance.enabled);

            featureInfos.SingleOrDefault(ext => ext.Attribute.UiName == "Mock Runtime").Feature.enabled = false;
            Assert.IsFalse(MockRuntime.Instance.enabled);
        }

        [Test]
        [Description("A feature's UI name, version and extension strings match the values declared on its " +
                     "OpenXRFeature attribute.")]
        public void CheckDefaultValues()
        {
            var featureInfos = GetFeatureInfos(BuildTargetGroup.Standalone);
            var mockExtInfo = featureInfos.SingleOrDefault(ext => ext.Attribute.UiName == "Mock Runtime");

            Assert.AreEqual(mockExtInfo.Attribute.UiName, mockExtInfo.Feature.nameUi);
            Assert.AreEqual(mockExtInfo.Attribute.Version, mockExtInfo.Feature.version);
            Assert.AreEqual(mockExtInfo.Attribute.OpenxrExtensionStrings, mockExtInfo.Feature.openxrExtensionStrings);
        }

        class TestFeature : OpenXRFeature
        {

        }

        [UnityTest]
        [Description("A feature's failing validation rule fails a player build, and invoking fixIt clears " +
                     "the issue.")]
        public IEnumerator ValidationError()
        {
            bool errorFixed = false;
            var feature = ScriptableObject.CreateInstance<TestFeature>();

            // Wait one frame to safely enable the TestFeature scriptable object.
            // This must be a yield inside the test (not EditorApplication.delayCall) so the body
            // runs within the test's log scope and its assertions count toward the result.
            yield return null;

            try
            {
                // Set up a validation check ...
                MockRuntime.Instance.TestCallback = (s, o) =>
                {
                    if (s == "GetValidationChecks")
                    {
                        feature.enabled = true;
                        var validationChecks = o as List<OpenXRFeature.ValidationRule>;
                        validationChecks?.Add(new OpenXRFeature.ValidationRule
                        {
                            feature = feature,
                            message = "Mock Validation Fail",
                            checkPredicate = () => errorFixed,
                            fixIt = () => errorFixed = true,
                            error = true
                        });
                    }

                    return true;
                };

                // Try to build the player ...
                var report = zBuildHookTests.BuildMockPlayer();

                // It will fail because of the above validation issue ...
                Assert.AreEqual(BuildResult.Failed, report.summary.result);

                // There's one validation issue ...
                var validationIssues = new List<OpenXRFeature.ValidationRule>();
                OpenXRProjectValidation.GetCurrentValidationIssues(validationIssues, BuildTargetGroup.Standalone);
                Assert.AreEqual(1, validationIssues.Count);

                // Fix it ...
                Assert.IsFalse(errorFixed);
                validationIssues[0].fixIt.Invoke();
                Assert.IsTrue(errorFixed);

                // Now there's zero validation issues ...
                OpenXRProjectValidation.GetCurrentValidationIssues(validationIssues, BuildTargetGroup.Standalone);
                Assert.AreEqual(0, validationIssues.Count);
            }
            finally
            {
                // Close the validation window ...
                OpenXRProjectValidationRulesSetup.CloseWindow();
                UnityEngine.Object.DestroyImmediate(feature);
            }
        }

        [Test]
        [Description("GetFeatureWithIdForActiveBuildTarget resolves a known feature id to its feature " +
                     "instance.")]
        public void GetFeatureByFeatureId()
        {
            var feature = FeatureHelpers.GetFeatureWithIdForActiveBuildTarget(MockRuntime.featureId);
            Assert.IsNotNull(feature);
        }

        [Test]
        [Description("GetFeatureWithIdForActiveBuildTarget returns null for an unknown, empty or null " +
                     "feature id.")]
        public void GetFeatureByUnknownFeatureIdReturnsNull()
        {
            var feature = FeatureHelpers.GetFeatureWithIdForActiveBuildTarget("some.unknown.feature.id");
            Assert.IsNull(feature);

            feature = FeatureHelpers.GetFeatureWithIdForActiveBuildTarget("");
            Assert.IsNull(feature);

            feature = FeatureHelpers.GetFeatureWithIdForActiveBuildTarget(null);
            Assert.IsNull(feature);
        }

        [Test]
        [Description("GetFeaturesWithIdsForActiveBuildTarget returns exactly the features matching the " +
                     "requested ids, each of the expected type.")]
        public void GetFeaturesWithIdsReturnsFeatures()
        {
            var featureIds = new[] { MockRuntime.featureId, EyeGazeInteraction.featureId };
            var features = FeatureHelpers.GetFeaturesWithIdsForActiveBuildTarget(featureIds);
            Assert.IsNotNull(features);
            Assert.IsTrue(features.Length == 2);

            var expectedTypes = new[] { typeof(MockRuntime), typeof(EyeGazeInteraction) };
            foreach (var feature in features)
            {
                Assert.IsTrue(Array.IndexOf(expectedTypes, feature.GetType()) > -1);
            }
        }
    }
}
