using System.Collections;
using System.Collections.Generic;
using NUnit.Framework;
using UnityEngine.XR.OpenXR.Features;
using UnityEngine.XR.OpenXR.Features.Mock;
using UnityEngine.TestTools;
using UnityEngine.TestTools.Utils;
using UnityEngine.XR.OpenXR.NativeTypes;
#if LIFECYCLE_APIS_AVAILABLE
using Unity.Scripting.LifecycleManagement;
#endif

namespace UnityEngine.XR.OpenXR.Tests
{
    /// <summary>
    /// Defines tests that validate the MockRuntime itself.
    /// </summary>
    [Category("Level.Integration")]
    [NUnit.Framework.Property("Covers", "MockRuntime")]
    class MockRuntimeTests : OpenXRLoaderSetup
    {
        [UnityTest]
        [Description("TransitionToState moves the mock session from Focused to Visible when the transition " +
                     "is valid.")]
        public IEnumerator TransitionToState()
        {
            InitializeAndStart();
            yield return new WaitForXrFrame();

            Assert.AreEqual(MockRuntime.sessionState, XrSessionState.Focused, "MockRuntime must be in focused state for this test to work correctly");
            Assert.IsTrue(MockRuntime.TransitionToState(XrSessionState.Visible, false), "Failed to transition to visible state");

            Assert.AreEqual(MockRuntime.sessionState, XrSessionState.Visible);
        }

        [UnityTest]
        [Description("An invalid transition (Focused to Synchronized) is refused unless forced, and forcing " +
                     "it lands the session in Synchronized.")]
        public IEnumerator TransitionToStateForced()
        {
            InitializeAndStart();
            yield return new WaitForXrFrame();

            Assert.IsFalse(MockRuntime.TransitionToState(XrSessionState.Synchronized, false), "Synchronized state must be an invalid transition for this test to be valid");
            Assert.IsTrue(MockRuntime.TransitionToState(XrSessionState.Synchronized, true), "Force state transition should not return false");

            yield return new WaitForXrFrame();

            Assert.IsTrue(MockRuntime.sessionState == XrSessionState.Synchronized);
        }

        [UnityTest]
        [Description("When xrCreateSession fails, no feature receives OnSessionCreate.")]
        public IEnumerator CreateSessionFailure()
        {
            bool sawCreateSession = false;
            MockRuntime.Instance.TestCallback = (methodName, _) =>
            {
                if (methodName == nameof(OpenXRFeature.OnSessionCreate))
                {
                    sawCreateSession = true;
                }

                return true;
            };

            MockRuntime.SetFunctionCallback("xrCreateSession", _ => XrResult.RuntimeFailure);

            InitializeAndStart();

            yield return null;

            Assert.IsFalse(sawCreateSession);
        }

#if LIFECYCLE_APIS_AVAILABLE
        [NoAutoStaticsCleanup]
#endif
        static XrResult[] beginSessionSuccessResults =
        {
            XrResult.Success,
            XrResult.LossPending
        };

        [UnityTest]
        [Description("xrBeginSession returning Success walks the session through to Focused; returning " +
                     "LossPending stops at Ready. The display subsystem runs either way.")]
        public IEnumerator BeginSessionSuccessWithValues([ValueSource(nameof(beginSessionSuccessResults))]
            XrResult successResult)
        {
            var states = new List<XrSessionState>();
            MockRuntime.Instance.TestCallback = (methodName, param) =>
            {
                if (methodName == nameof(OpenXRFeature.OnSessionStateChange))
                {
                    var newState = (XrSessionState)((MockRuntime.XrSessionStateChangedParams)param).NewState;
                    states.Add(newState);
                }

                return true;
            };

            MockRuntime.SetFunctionCallback("xrBeginSession", (_) => successResult);

            InitializeAndStart();

            yield return null;

            Assert.IsTrue(base.IsRunning<XRDisplaySubsystem>());

            switch (successResult)
            {
                case XrResult.Success:
                    Assert.IsTrue(states.Contains(XrSessionState.Ready));
                    Assert.IsTrue(states.Contains(XrSessionState.Synchronized));
                    Assert.IsTrue(states.Contains(XrSessionState.Visible));
                    Assert.IsTrue(states.Contains(XrSessionState.Focused));
                    break;

                case XrResult.LossPending:
                    Assert.IsTrue(states.Contains(XrSessionState.Ready));
                    Assert.IsFalse(states.Contains(XrSessionState.Synchronized));
                    Assert.IsFalse(states.Contains(XrSessionState.Visible));
                    Assert.IsFalse(states.Contains(XrSessionState.Focused));
                    break;
            }
        }

        [UnityTest]
        [Description("When xrBeginSession fails, the session reaches Ready but never Synchronized, Visible " +
                     "or Focused, while the display subsystem still runs.")]
        public IEnumerator BeginSessionFailure()
        {
            var states = new List<XrSessionState>();
            MockRuntime.Instance.TestCallback = (methodName, param) =>
            {
                if (methodName == nameof(OpenXRFeature.OnSessionStateChange))
                {
                    var newState = (XrSessionState)((MockRuntime.XrSessionStateChangedParams)param).NewState;
                    states.Add(newState);
                }

                return true;
            };

            MockRuntime.SetFunctionCallback("xrBeginSession", _ => XrResult.RuntimeFailure);

            InitializeAndStart();

            yield return null;

            Assert.IsTrue(IsRunning<XRDisplaySubsystem>());

            Assert.IsTrue(states.Contains(XrSessionState.Ready));
            Assert.IsFalse(states.Contains(XrSessionState.Synchronized));
            Assert.IsFalse(states.Contains(XrSessionState.Visible));
            Assert.IsFalse(states.Contains(XrSessionState.Focused));
        }

#if false
        // TEST WAS UNSTABLE, DISABLING FOR RELEASE ONLY
        [UnityTest]
        [Description("Requesting session exit through the mock driver delivers OnSessionDestroy and shuts " +
                     "the loader down.")]
        public IEnumerator TestRequestExitShutsdownSubsystems()
        {
            bool sawSessionDestroy = false;
            MockRuntime.Instance.TestCallback = (methodName, param) =>
            {
                if (methodName == nameof(OpenXRFeature.OnSessionDestroy))
                {
                    sawSessionDestroy = true;
                }

                return true;
            };

            AddExtension(MockRuntime.XR_UNITY_mock_test);

            base.InitializeAndStart();

            yield return null;

            Assert.IsTrue(base.IsRunning<XRDisplaySubsystem>());

            var wait = new WaitForLoaderShutdown(Loader);
            MockDriver.RequestExitSession(MockRuntime.Instance.XrSession);

            yield return wait;

            Assert.IsTrue(sawSessionDestroy);
        }

#endif

        [UnityTest]
        [Description("MockRuntime.RequestExitSession shuts the loader down once OpenXR is running.")]
        public IEnumerator RequestExitSession()
        {
            InitializeAndStart();

            // Wait for a single XrFrame to make sure OpenXR is up and running
            yield return new WaitForXrFrame();

            // Request the session exit which should shutdown OpenXR
            MockRuntime.RequestExitSession();

            // Wait for OpenXR to shutdown
            yield return new WaitForLoaderShutdown();
        }

        [UnityTest]
        [Description("MockRuntime.CauseInstanceLoss delivers OnInstanceLossPending to features and shuts the " +
                     "loader down.")]
        public IEnumerator CauseInstanceLoss()
        {
            bool instanceLost = false;
            MockRuntime.Instance.TestCallback = (methodName, _) =>
            {
                if (methodName == nameof(OpenXRFeature.OnInstanceLossPending))
                {
                    instanceLost = true;
                }

                return true;
            };

            InitializeAndStart();

            yield return null;

            MockRuntime.CauseInstanceLoss();

            yield return new WaitForLoaderShutdown();

            Assert.IsTrue(instanceLost);
        }

        [UnityTest]
        [Description("Choosing the Additive environment blend mode during OnInstanceCreate makes the display " +
                     "subsystem report a non-opaque display.")]
        public IEnumerator DisplayTransparent()
        {
            AddExtension(MockRuntime.XR_UNITY_mock_test);

            MockRuntime.Instance.TestCallback = (methodName, _) =>
            {
                if (methodName == nameof(OpenXRFeature.OnInstanceCreate))
                {
                    MockRuntime.ChooseEnvironmentBlendMode(XrEnvironmentBlendMode.Additive);
                }

                return true;
            };

            base.InitializeAndStart();

            yield return null;
            var displays = new List<XRDisplaySubsystem>();
            SubsystemManager.GetSubsystems(displays);
            Assert.AreEqual(false, displays[0].displayOpaque);
        }

        [UnityTest]
        [Description("With the default blend mode, the display subsystem reports an opaque display.")]
        public IEnumerator DisplayOpaque()
        {
            InitializeAndStart();

            yield return null;
            var displays = new List<XRDisplaySubsystem>();
            SubsystemManager.GetSubsystems(displays);
            Assert.AreEqual(true, displays[0].displayOpaque);
        }

        [UnityTest]
        [Description("The blend mode defaults to Opaque, can be switched to the supported Additive mode, and " +
                     "rejects the unsupported AlphaBlend mode.")]
        public IEnumerator MultipleEnvironmentBlendModes()
        {
            //Mock available environmentBlendModes are Opaque and Additive in mock_runtime.cpp EnumerateEnvironmentBlendModes.
            AddExtension(MockRuntime.XR_UNITY_mock_test);
            InitializeAndStart();
            yield return null;

            //check default mode is Opaque.
            Assert.AreEqual(XrEnvironmentBlendMode.Opaque, MockRuntime.GetXrEnvironmentBlendMode());

            //Switch to another supported mode - Additive.
            MockRuntime.ChooseEnvironmentBlendMode(XrEnvironmentBlendMode.Additive);
            yield return new WaitForXrFrame(2);
            Assert.AreEqual(XrEnvironmentBlendMode.Additive, MockRuntime.GetXrEnvironmentBlendMode());

            //Set to unsupported mode - Alpha_blend
            MockRuntime.ChooseEnvironmentBlendMode(XrEnvironmentBlendMode.AlphaBlend);
            yield return new WaitForXrFrame(2);
            Assert.AreNotEqual(XrEnvironmentBlendMode.AlphaBlend, MockRuntime.GetXrEnvironmentBlendMode());
        }

        [UnityTest]
        [Description("Stage reference-space bounds set on the mock runtime surface as four floor-origin " +
                     "boundary points at the expected corners.")]
        public IEnumerator BoundaryPoints()
        {
            AddExtension(MockRuntime.XR_UNITY_mock_test);

            InitializeAndStart();

            yield return null;

            Assert.IsTrue(IsRunning<XRInputSubsystem>(), "Input subsystem failed to properly start!");

            MockRuntime.SetReferenceSpaceBounds(XrReferenceSpaceType.Stage, new Vector2 { x = 1.0f, y = 3.0f });

            yield return null;

            var input = Loader.GetLoadedSubsystem<XRInputSubsystem>();
            Assert.That(() => input, Is.Not.Null);

            input.TrySetTrackingOriginMode(TrackingOriginModeFlags.Floor);

            yield return null;

            var points = new List<Vector3>();
            Assert.IsTrue(input.TryGetBoundaryPoints(points), "Failed to get boundary points!");
            Assert.That(() => points.Count, Is.EqualTo(4), "Incorrect number of boundary points received!");

            var comparer = new Vector3EqualityComparer(10e-6f);

            Assert.That(points[0], Is.EqualTo(new Vector3 { x = -0.5f, y = 0.0f, z = -1.5f }).Using(comparer));
            Assert.That(points[1], Is.EqualTo(new Vector3 { x = -0.5f, y = 0.0f, z = 1.5f }).Using(comparer));
            Assert.That(points[2], Is.EqualTo(new Vector3 { x = 0.5f, y = 0.0f, z = 1.5f }).Using(comparer));
            Assert.That(points[3], Is.EqualTo(new Vector3 { x = 0.5f, y = 0.0f, z = -1.5f }).Using(comparer));
        }

        [UnityTest]
        [Description("With no reference-space bounds set, the input subsystem reports zero boundary points.")]
        public IEnumerator NoBoundaryPoints()
        {
            AddExtension(MockRuntime.XR_UNITY_mock_test);

            InitializeAndStart();

            yield return null;

            Assert.IsTrue(IsRunning<XRInputSubsystem>(), "Input subsystem failed to properly start!");

            var input = Loader.GetLoadedSubsystem<XRInputSubsystem>();
            Assert.That(() => input, Is.Not.Null);

            input.TrySetTrackingOriginMode(TrackingOriginModeFlags.Floor);

            yield return null;

            var points = new List<Vector3>();
            input.TryGetBoundaryPoints(points);
            Assert.That(() => points.Count, Is.EqualTo(0), "Incorrect number of boundary points received!");
        }

        [UnityTest]
        [Description("Boundary points are reported in Floor tracking-origin mode and disappear after " +
                     "switching to Device mode.")]
        public IEnumerator BoundryPointsForTrackingOrigin()
        {
            AddExtension(MockRuntime.XR_UNITY_mock_test);

            InitializeAndStart();

            yield return null;

            Assert.IsTrue(IsRunning<XRInputSubsystem>(), "Input subsystem failed to properly start!");

            MockRuntime.SetReferenceSpaceBounds(XrReferenceSpaceType.Stage, new Vector2 { x = 1.0f, y = 3.0f });

            yield return null;

            var input = Loader.GetLoadedSubsystem<XRInputSubsystem>();
            Assert.That(() => input, Is.Not.Null);

            input.TrySetTrackingOriginMode(TrackingOriginModeFlags.Floor);

            yield return null;

            var points = new List<Vector3>();
            Assert.IsTrue(input.TryGetBoundaryPoints(points), "Failed to get boundary points!");
            Assert.That(() => points.Count, Is.EqualTo(4), "Incorrect number of boundary points received!");

            input.TrySetTrackingOriginMode(TrackingOriginModeFlags.Device);

            yield return null;

            points.Clear();
            input.TryGetBoundaryPoints(points);
            Assert.That(() => points.Count, Is.EqualTo(0), "Incorrect number of boundary points received!");
        }

        [UnityTest]
        [Description("A before-call callback registered for xrCreateInstance is invoked when the loader " +
                     "starts.")]
        public IEnumerator BeforeFunctionCallbackSuccess()
        {
            var createInstanceCalled = false;

            MockRuntime.SetFunctionCallback("xrCreateInstance", _ =>
            {
                createInstanceCalled = true;
                return XrResult.Success;
            });

            InitializeAndStart();

            yield return new WaitForXrFrame(1);

            Assert.IsTrue(createInstanceCalled, "xrCreateInstance callback was not called");
        }

        [Test]
        [Description("A before-call callback that fails xrCreateInstance prevents the loader from " +
                     "initializing.")]
        public void BeforeFunctionCallbackError()
        {
            var createInstanceCalled = false;

            MockRuntime.SetFunctionCallback("xrCreateInstance", _ =>
            {
                createInstanceCalled = true;
                return XrResult.RuntimeFailure;
            });

            LogAssert.ignoreFailingMessages = true;
            InitializeAndStart();
            LogAssert.ignoreFailingMessages = false;

            Assert.IsTrue(OpenXRLoaderBase.Instance == null, "OpenXR instance should have failed to initialize");

            Assert.IsTrue(createInstanceCalled, "xrCreateInstance callback was not called");
        }

        [UnityTest]
        [Description("An after-call callback registered for xrCreateInstance is invoked with the call's " +
                     "Success result.")]
        public IEnumerator AfterFunctionCallback()
        {
            var createInstanceCalled = false;
            var createInstanceSuccess = false;

            MockRuntime.SetFunctionCallback("xrCreateInstance", (_, result) =>
            {
                createInstanceCalled = true;
                createInstanceSuccess = result == XrResult.Success;
            });

            InitializeAndStart();

            yield return new WaitForXrFrame(1);

            Assert.IsTrue(createInstanceCalled, "xrCreateInstance callback was not called");
            Assert.IsTrue(createInstanceSuccess, "xrCreateInstance result was not XR_SUCCESS");
        }

        [UnityTest]
        [Description("Function callbacks registered on the mock runtime are cleared when the loader shuts " +
                     "down.")]
        public IEnumerator CallbacksClearedOnLoaderShutdown()
        {
            MockRuntime.SetFunctionCallback("xrBeginSession", _ => XrResult.Success);

            InitializeAndStart();

            yield return new WaitForXrFrame(1);

            StopAndShutdown();

            Assert.IsTrue(OpenXRLoaderBase.Instance == null, "OpenXR should not be running");
            Assert.IsNull(MockRuntime.GetBeforeFunctionCallback("xrBeginSession"), "Callback should have been cleared when loader shut down");
        }
    }
}
