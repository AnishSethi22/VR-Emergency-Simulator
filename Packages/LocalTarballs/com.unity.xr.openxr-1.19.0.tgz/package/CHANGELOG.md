# Changelog
All notable changes to this package will be documented in this file.

The format is based on [Keep a Changelog](http://keepachangelog.com/en/1.0.0/)
and this project adheres to [Semantic Versioning](http://semver.org/spec/v2.0.0.html).

<!--
> **Notes**
> When updating the Changelog, please ensure we follow the standards for ordering headers as outlined here: [US-0039](https://standards.ds.unity3d.com/Standards/US-0039/). Specifically: Under ## headers, ### \<type\> headers are listed in this order: Added, Changed, Deprecated, Removed, Fixed, Security
-->

## [1.19.0] - 2026-10-16

### Added

### Changed

* Changed static image layers that use a single texture for both eyes to stop acquiring a new swapchain image every frame once their images are written, removing per-frame swapchain work for layers whose content doesn't change.

### Deprecated

### Removed

* Removed incorrect validation rules that used upscaling.

### Fixed

* Fixed a build asset version error that would sometimes appear for the openxrpackagesettings.asset when upgrading the OpenXR package.
* Fixed issue in the Sample Starter Assets where the right hand would not be visible.
* Fixed Symmetric Projection being silently disabled on runtimes that do not support the `XR_FB_foveation` and `XR_FB_foveation_configuration` extensions. This dependency was removed in 1.13.0 but was reintroduced when Symmetric Projection was moved into an extension. `XR_FB_foveation`, `XR_FB_foveation_configuration` and `XR_FB_swapchain_update_state` are no longer enabled by default, and are only enabled when a feature such as Foveated Rendering requests them.
* Fixed a desync that could happen between depth imageRect size and color imageRect size.
* Fixed static composition layers flickering between old frames when their texture content was updated with the Source Textures **Dynamic Texture** option turned off at runtime.
* Fixed `CopyFromSource` mipmapped composition layers appearing upside down and mirrored on graphics APIs whose texture coordinates start at the top (such as Direct3D and Vulkan).
* Fixed issue in the Sample Starter Assets to properly navigate scenes using the scene navigator.
* Fixed an issue where OpenXR Plug-in would save changes to all assets in your project on domain reloads, when it should have only saved changes to its OpenXR Settings asset.
* Fixed incorrect left and right eye poses reported by the HMD while the head was moving. Eye positions did not follow the head's rotation, and eye rotations were wrong on devices whose views are rotated relative to the head.

### Security

## [1.19.0-pre.2] - 2026-10-02

### Added

* Added mipmap support for composition layers with the `CopyFromSource` and `AutoGenerate` mip modes on Local Texture layers. Applies to Quad, Cylinder, Cube, and Equirect layers, and requires Unity 6000.7.0a4 or newer.
* Added the Meta Temporal Pixel Synthesis feature, which uses the `XR_META_temporal_pixel_synthesis` extension to let the runtime apply temporal anti-aliasing and upscaling to your rendered frames. Moving this work to the runtime can improve performance compared with performing it in your application. Refer to [Temporal Pixel Synthesis](xref:openxr-temporal-pixel-synthesis).
* Added [`FoveatedRenderingFeature.skipFDMForFinalPassesSRP`](xref:UnityEngine.XR.OpenXR.Features.FoveatedRenderingFeature.skipFDMForFinalPassesSRP), which stops Unity from attaching a fragment density map to the `FinalBlit` and `UberPost` passes of the Universal Render Pipeline (URP). Unity enables it by default on Meta Quest, which can reduce GPU frame time. Requires Unity 6.7 or newer. Refer to [Use the SRP foveation API](xref:openxr-foveated-rendering-srp-api).
* Added native types for the hand tracking extension `XR_META_hand_tracking_unextrapolated_poses`.

### Fixed

* Fixed error log that appeared after reimporting Meshing Subsystem Feature.
* Fixed composition layer static fields, events, and caches being reported as errors by the Unity 6.7 statics-cleanup analyzer.
* Fixed composition layer textures appearing vertically flipped on graphics APIs whose texture coordinates start at the top (such as Metal, Direct3D and Vulkan) when the copy-texture transfer path was used. These transfers now fall back to `Graphics.Blit`, which preserves the upright orientation.
* Fixed Equirect composition layers so that partial-sphere configurations render correctly and match the Editor emulation preview. Requires XR Composition Layers 2.6.0 or newer.
* Fixed compile error in temporal pixel synthesis feature code.
* Fixed a `NullReferenceException` thrown when loading OpenXR settings or building a player while the OpenXR Package Settings asset contains a feature whose script is missing, which can happen after removing a package that provided an OpenXR feature.
* Fixed OpenXR features that do not define `BuildTargetGroups` in their `OpenXRFeatureAttribute` disappearing from the OpenXR Project Settings window. Omitting `BuildTargetGroups` once again means that the feature supports every build target group.
* Fixed how temporal pixel synthesis works with quad views.
* Fixed a possible compiler error in Unity 6.6 when this package is used in combination with XR Plug-in Management 4.7.0 or newer.
* Fixed Hand Interaction Poses input devices not having poke pose and pinch pose usages set. They now match Hand Interaction Profile input devices. This allows poke and pinch poses to be queried through the `InputDevice.TryGetFeatureValue` API.
* Fixed Hand Interaction Profile `devicePose` control to use the correct localized name that matches other input devices.
* Fixed a crash on the CoreCLR scripting backend caused by managed callback delegates being garbage collected while native code still held their function pointers. Delegates passed to the OpenXR native plugin are now rooted in static fields for the lifetime of the process.
* Fixed a `KeyNotFoundException` thrown when a composition layer was removed while its swapchain creation request was still in flight. The swapchain callbacks now verify that the layer is still present before processing the result.
* Fixed the Play Mode OpenXR Runtime selector throwing `PlatformNotSupportedException` and `NullReferenceException` on macOS when the Editor runs on CoreCLR, which doesn't support the Windows Registry on non-Windows platforms.

## [1.19.0-pre.1] - 2026-08-12

### Added

* Added support for the Composition Layers Dynamic Texture option, rewriting a dynamic layer's swapchain image every frame so textures updated externally on the GPU no longer appear static. Requires XR Composition Layers 2.6.0 or newer.
* Added `XrHandTrackingDataSourceEXT.UnobstructedWideMotion` to support the `XR_META_hand_tracking_wide_motion_mode2` extension.
* Added support for the following OpenXR extensions to the [OpenXR Native API](xref:openxr-native-api):
  * [XR_ANDROID_spatial_component_subsumed_by](https://registry.khronos.org/OpenXR/specs/1.1/html/xrspec.html#XR_ANDROID_spatial_component_subsumed_by)
  * [XR_ANDROID_spatial_discovery_raycast](https://registry.khronos.org/OpenXR/specs/1.1/html/xrspec.html#XR_ANDROID_spatial_discovery_raycast)
  * [XR_ANDROID_spatial_entity_bound_anchor](https://registry.khronos.org/OpenXR/specs/1.1/html/xrspec.html#XR_ANDROID_spatial_entity_bound_anchor)
  * `XR_EXT_spatial_image_tracking` (not yet part of the public spec)
* Added a dynamic foveation toggle to `FoveatedRenderingFeature`, which allows the OpenXR runtime to vary the amount of foveation it applies, up to the foveation level your application sets, on devices that support it. You can find this setting in the `FoveatedRenderingFeature` project settings view as **Dynamic Foveation (Vulkan)**. Refer to [Use dynamic foveation](xref:openxr-foveated-rendering-dynamic).
* Added `FoveatedRenderingFeature.DynamicFoveationEnabled` to turn dynamic foveation on or off through script.
* Added the `XR_FB_foveation_configuration` native types `XrFoveationLevelFB`, `XrFoveationDynamicFB`, and `XrFoveationLevelProfileCreateInfoFB`.

### Changed

* Composition layer texture transfer now uses `Graphics.CopyTexture` instead `Graphics.Blit` if copy preconditions are met. `Graphics.Blit` remains as the fallback path.
* Updated OpenXR specification libraries and headers to version 1.1.62.

### Fixed

* Fixed `OpenXRCustomLayerHandler` continuing to render video and RenderTexture composition layers every frame after they became inactive without being removed.
* Fixed the D-Pad Binding, Palm Pose, and Hand Interaction Poses features not reporting a Project Validation error when none of the enabled interaction profiles can be augmented by them.

## [1.18.0] - 2026-08-04

### Added

* Added `gripOrientation` and `pointerOrientation` as aliases for `deviceRotation` and `pointerRotation` in `HandInteractionProfile`.
* Added `palmOrientation` as an alias for `palmRotation` in `PalmPoseInteraction`.

### Changed

* Changed [`AndroidMouseInteractionProfile.AndroidMouseInteraction`](xref:UnityEngine.XR.OpenXR.Features.Interactions.AndroidMouseInteractionProfile.AndroidMouseInteraction) to have its `aim` control type declared as either `UnityEngine.InputSystem.XR.PoseControl` or `UnityEngine.XR.OpenXR.Input.PoseControl` based on `USE_INPUT_SYSTEM_POSE_CONTROL` in Scripting Define Symbols under Player settings, matching the other interaction input devices. This is potentially a breaking change if you did not opt-in to the Project Validation rule "Switch to use InputSystem.XR.PoseControl instead of OpenXR.Input.PoseControl, which will be deprecated in a future release." If you were referencing the `aim` property directly through scripting, or reading the value of an input action with a binding to that control, you may need to adjust the type of struct you read.

### Removed

* Removed redundant `palmPosition` and `palmRotation` aliases from `devicePosition` and `deviceRotation` in `PalmPoseInteraction`.

### Fixed

* Fixed `XrSpaceLocationFlags` and `XrViewStateFlags` underlying type to `ulong` (`XrFlags64`) so their sizes match the OpenXR spec.
* Fixed `XrSpatialPersistenceDataEXT` to use 4-byte alignment instead of 8-byte alignment, correctly aligning its size with the OpenXR C ABI.
* Fixed [`PalmPoseInteraction.PalmPose`](xref:UnityEngine.XR.OpenXR.Features.Interactions.PalmPoseInteraction.PalmPose) input device not finishing setup of all input control properties where the input control properties other than `palmPose` were `null`.
* Fixed `OpenXRHmd` input device not finishing setup of the `userPresence` input control property.
* Fixed crash when using the XR_KHR_vulkan_enable2 extension, Vulkan, and OpenXR on an in-Editor app.
* Fixed some input devices not setting up the `StickControl`/`Vector2Control` input control properties correctly when `USE_STICK_CONTROL_THUMBSTICKS` scripting define symbol was not defined in the project.
* Fixed `OpenXRCustomLayerHandler` continuing to render video and RenderTexture composition layers every frame after they became inactive without being removed.
* Fixed several regressions from package version 1.17.0 caused by "Fixed compilation errors when OpenXR was present in Unity projects targeting non-XR supported platforms.":
  * Fixed the Android Mouse Interaction (OpenXR) [`AndroidMouseInteractionProfile.AndroidMouseInteraction`](xref:UnityEngine.XR.OpenXR.Features.Interactions.AndroidMouseInteractionProfile.AndroidMouseInteraction) input device not having the `aim` property.
  * Fixed the [`OpenXRDevice`](xref:UnityEngine.XR.OpenXR.Input.OpenXRDevice) not setting `{LeftHand}`/`{RightHand}` input device usages. This affects some derived input devices such as Hand Interaction Poses (OpenXR) ([`HandCommonPosesInteraction.HandInteractionPoses`](xref:UnityEngine.XR.OpenXR.Features.Interactions.HandCommonPosesInteraction.HandInteractionPoses)).
  * Fixed the `OpenXRDevice` not being registered with the Input System as a base layout.
  * Fixed some conditions for enabling Project Validation rules related to D-Pad Binding and Palm Pose features when only the Eye Gaze Interaction Profile is enabled.
* Fixed an issue where package setting assets would be refreshed on Unity Editor startup, causing import errors. This was implemented by separating refreshing OpenXR Features from querying OpenXR Features.
* Fixed compilation errors caused by lack of StaticCleanup attributes in Unity 6.7.

### Security

## [1.18.0-pre.2] - 2026-06-16

### Fixed

* Fixed issue where "Use OpenXR Time" setting was not applied before subsystem started up.
* Fixed a problem so that we are now setting "GPUAppLastFrameTime" and "GPUCompositorLastFrameTime" as seconds instead of milliseconds into XRStats.
* Fixed compilation in Unity 6.0 due to missing `GetEntityId` method when the XR Composition Layers package is also installed.

## [1.18.0-pre.1] - 2026-06-02

### Added

* Added a Starter Assets sample used to unify future OpenXR samples.
* Reworked the OpenXR Controller sample and added new Graphics and Tracking Origin Mode samples.
* Added Manual Documentation for the Runtime Debugger feature.
* Added MetaOpenXRHandMeshData feature for accessing hand mesh geometry via `XR_FB_hand_tracking_mesh`. Supports Meta Quest and Android XR devices.
* Added `ToString` overrides for the following types:
  * `XrSpatialCapabilityConfigurationAnchorEXT`
  * `XrSpatialCapabilityConfigurationAprilTagEXT`
  * `XrSpatialCapabilityConfigurationArucoMarkerEXT`
  * `XrSpatialCapabilityConfigurationMicroQrCodeEXT`
  * `XrSpatialCapabilityConfigurationQrCodeEXT`
  * `XrSpatialCapabilityConfigurationPlaneTrackingEXT`
* Added native types for hand tracking extensions XR_EXT_hand_tracking, XR_EXT_hand_joints_motion_range, XR_EXT_hand_tracking_data_source.
* Added convenience overloads to the OpenXR native API that allow you to get spatial buffer data without constructing an `XrSpatialBufferGetInfoEXT` struct yourself.
* Added `OpenXRResultStatus.StatusCode.NotFound` and `OpenXRResultStatus.StatusCode.NotTracking` as additional error codes that can be returned by calls to the OpenXR Native API.
* Added support for `XR_ANDROID_enumerate_system_extension_properties` to query whether the current
  system configuration supports a particular extension via `OpenXRRuntime.IsSystemExtensionEnabled`.
* Added Individual, Left and Right Target Eye option to Composition Layers, allowing per-eye textures for standard Quad, Cylinder, Equirect, and Cube layers.
* Added built-in support for `XR_FB_eye_tracking_social`, exposing per-eye social gaze data as a Unity XR input device.
* Added internal native API support for dynamically disabling Fragment Density Map (FDM) attachments at foveation level 0 (SRP Foveation).

### Changed
* Certain interaction profiles now test if hardware support is available on the system if the `XR_ANDROID_enumerate_system_properties` extension is available. Affected interaction profiles: hand, palm pose, hand common poses, D-pad, mouse.

* Updated minimum supported editor version to 6000.0.
* Changed behavior of Meta Quest build profile to automatically enable suggested controllers and Meta Quest Support.
* Updated Hand Mesh Data documentation to clarify the exact feature label in OpenXR Project Settings, supported build targets (Android and Standalone), and automatic Android manifest configuration details.
* Use OpenXR Delta Time opts to not use the deltaTime value provided by the runtime when the setting is false.
* Changed behavior of Quad Views to allow developers to selectively use eye tracking.

### Fixed

* Fixed a SIGSEGV crash so native textures are now safely cleaned up during graphics subsystem shutdown.
* Fixed the Composition Layers Support project validation rule so dual-platform projects can disable the feature on platforms that do not use composition layers.
* Fixed `XRDisplaySubsystem.contentProtectionEnabled` getter always returning false on OpenXR, and fixed the property having no effect on Meta Quest screen casting.
* Fixed the "Meta Quest supports Thin Link Time Optimization" Project Validation to be an automatic Fix type instead of an Edit type.
* Fixed the default foveated-rendering eye center being placed at the wrong location for each eyes, on PC Vulkan/DX12.
* Fixed crash caused by attempting to access assetdatabase during an InitializeOnLoad attribute method.
* Fixed API Layers window rendering issue such that it renders without throwing `NullReferenceException`. ([UUM-141166](https://issuetracker.unity3d.com/issues/openxr-api-layers-window-is-not-rendered-and-nullreferenceexception-errors-are-thrown-when-the-api-layers-window-is-opened))

## [1.17.0] - 2026-04-09

### Added

* Added the Enable System Keyboard setting to the Meta Quest Feature configuration under Manifest Settings. ([UUM-135656](https://issuetracker.unity3d.com/product/unity/issues/guid/UUM-135656))
* Added `XrStructureType.EventDataGlobalDimmingLevelChangedAndroid` to support the `XR_ANDROID_global_passthrough_dimming` extension.
* Added analytics to track active build target when reported in Editor.
* Added documentation for the [Debug Utils](xref:openxr-debug-utils) feature.

### Changed
* Set `Use OpenXR Predicted Time` to `true` by default.
* Changed the default `Foveated Rendering Method` to the SRP API.

### Fixed

* Fixed an issue in Enabled Interaction Profile where "+" is active even if there are no available build profiles left.
* Fixed issue with an empty visible mesh. ([UUM-135831](https://issuetracker.unity3d.com/product/unity/issues/guid/UUM-135831))
* Fixed Help Box in OpenXR settings to comply with U6.5 designs
* Fixed Mono-API deprecation warning for AppDomain calls by using [OnCodeUnloading] for domain exception handling on Unity 6000.5+
* Fixed compilation errors when OpenXR was present in Unity projects targeting non-XR supported platforms.
* Fixed a problem with feature settings window so that it is no longer cleared after a domain reload.
* Fixed a problem with feature validation so that all features are refreshed when we first gather validation rules.
* Fixed a problem with OpenXR API Layers so that we now set the correct path when running on Windows Standalone build.
* Fixed modification of the OpenXR Package Settings asset every time a project was re-opened in the Unity Editor. ([UUM-138181](https://issuetracker.unity3d.com/product/unity/issues/guid/UUM-138181))

## [1.17.0-pre.2] - 2026-03-03

### Added

* Added the following members to the [OpenXR native API](xref:openxr-native-api):
  * `OpenXRNativeApi.xrUnpersistSpatialEntityAsyncEXT(XrSpatialPersistenceContextEXT, XrUuid, out XrFutureEXT)`
* Added support for the `XR_ANDROID_mouse_interaction` extension, enabling mouse and trackpad devices to provide 3D pointer ray interactions in Android XR applications.
* Added support for `OpenXR API Layers`, providing a new `ApiLayersFeature`, a public api, and editor ui for users to leverage.
* Added tooltips and documentation links to some OpenXR settings and features.
* Added Quad Views option for Foveated Rendering.
* Added `OpenXRLayerUtility.RemoveActiveLayer` so ILayerHandler implementations can remove composition layers from the native list of active layers that were cached this frame.
* Added analytics to track usage of additive APIs.
* Added support for `XR_ANDROID_enumerate_system_extension_properties` to query whether the current
  system configuration supports a particular extension via `OpenXRRuntime.IsSystemExtensionEnabled`.
* Added validation rule to check that when the **Quad Views** option for **Foveated Rendering** is enabled, the OpenXR **Render Mode** is set to **Single Pass Instanced \ Multi-view**.
* Added a scroll view to the OpenXR Feature Settings editor window so that content remains accessible when it exceeds the visible area.

### Changed

* Changed OpenXR loader version to 1.1.54.
* Changed the device layout for the D-Pad Interaction feature from `DPad` to `XRDPad` to align with XR naming conventions. This fixes instances where control layouts would overwrite each other due to naming conflicts. Existing Input Action bindings to `<DPad>` need to update to use the new `<XRDPad>` path.
* Changed the access level of `OpenXRInteractionFeature.OpenXRLoaderEnabledForSelectedBuildTarget` so that custom OpenXRInteractionFeature implementations can check whether a specific OpenXR loader is enabled.
* Single Pass Instanced rendering uses two render passes with two render views each when Quad Views is enabled.
* Moved the Foveated Rendering Api choice into the Foveated Rendering Feature Group.
* Changed `XrVector3f` to add the `readonly` keyword to all instance methods, indicating that they don't mutate the struct.
* Changed the documented `Preferred Graphics API` for runtimes that support DirectX to prefer DX12 instead of DX11.
* Changed Composition Layer API documentation to reflect that a layer's ID is no longer generated by `GetInstanceID` in all Unity versions. Layer IDs are now generated by `CompositionLayerManager.TryGetLayerId`.

### Removed

* Removed OpenXR support for Universal Windows Platform.
* Removed OpenXR support for Android x64 and Magic Leap 2.

### Fixed

* Fixed tracking origin to match the expected head position when an HMD recovers tracking or wakes up after the XR app starts. ([OXRB-520](https://issuetracker.unity3d.com/issues/valve-index-tracking-origin-is-incorrect-if-headset-isnt-tracking-on-startup-openxr-loader-plus-steamvr))
* Fixed an issue that caused "Could not create a device error" when connecting a game pad device and XR is set up in the project.
* Fixed interaction profile errors when adding OpenXR package after Meta Build Profile is switched to.
* Fixed issues in samples where controllers would remain visible when tracking was lost.
* Fixed a lifecycle bug for OpenXR Composition Layers. OpenXRLayerProvider now disposes itself and all registered ILayerHandler when the application is paused and when the OpenXR session ends.
* Fixed an issue to use the correct versions of icons in light mode.
* Fixed an issue where the Foveated Rendering Api choice gets overwritten by the MetaQuestFeature window.
* Fixed unnecessary allocations in `OpenXRProjectionLayer`. ([UUM-135657](https://issuetracker.unity3d.com/product/unity/issues/guid/UUM-135657))
* Fixed an issue for Oculus Foveation so it now checks if the `VK_EXT_fragment_density_map` extension is enumerable on the vulkan device before using the `XR_SWAPCHAIN_CREATE_FOVEATION_FRAGMENT_DENSITY_MAP_BIT_FB` extension.
* Fixed an issue when importing OpenXR package so that it now checks for existing features on the "OpenXR Package Settings" asset on disk and in memory.
* Fixed an issue for the native function `ext_composition_layers_GetLayerAndroidSurfaceObject` so that it's entry point is still available when running outside of Android.

## [1.17.0-pre.1] - 2025-12-16

### Added

* Expose `IsAdditive` and `AddAdditiveActions` APIs to allow external additive features to augment existing interaction profiles.
* Added [new package sample](xref:mock-runtime-tests-sample) that demonstrates usage of the `MockOpenXREnvironment` testing APIs.
* Added the following members to the [OpenXR native API](xref:openxr-native-api):
  * `OpenXRNativeApi.xrCreateSpatialEntityFromIdEXT(XrSpatialContextEXT, XrSpatialEntityIdEXT, out XrSpatialEntityEXT)`
  * `OpenXRNativeApi.xrCreateSpatialPersistenceContextAsyncEXT(XrSpatialPersistenceScopeEXT out XrFutureEXT)`
* Added members to the `XrStructureType` enum. `XrStructureType` now contains all OpenXR values as of OpenXR version 1.1.53.
* Added URP Compatibility to OpenXR Samples.
* Added the `OpenXRFeatureBuildHooks.bootConfigEntryRequired` to always write a boot config entry, even when the feature is disabled.
* Added support for the `XR_META_tile_properties_hint` extension. This extension is enabled automatically and optimizes performance for dynamic resolution and foveated rendering.

### Changed

* Changed the visibility mask to not create an occlusion mesh when using a 2022.3 editor to reduce memory footprint.
* Changed wording of validation rule that checks for symmetric projection when using the Multiview Render Regions Optimizations Mode.
* Changed OpenXR loader version to 1.1.53.

### Removed

* Removed an unit test `PluginVersion` which was used internally to validate package version.
* Removed verbose and redundant log message custom loader versions when browsing the OpenXR Settings view.

### Fixed

* Fixed an issue where CI builds for samples would include code that can only run with the Unity Test Runner.
* Fixed the OpenXR test "DuplicateSettingAssetTest" to communicate with asset database when swapping asset files.
* Fixed an issue where certain composition layers would lag behind the camera's pose by a frame in instances where the composition layers are direct children of the camera's transform in the scene hierarchy.
* Fixed a crash when using eye tracked foveated rendering and sleeping/waking device by making sure primary swapchain reference was reset before applying foveation profile.
* Fixed an issue in OpenXR Runtime Debugger window to show correctly sized buttons. ([OXRB-682](https://issuetracker.unity3d.com/issues/folder-button-in-openxr-runtime-debugger-window-is-oversized))
* Fixed Bluetooth permissions being removed when building apps using the Meta Quest Feature. The permissions are now kept when required by Unity APIs or a plugin's manifest. For more information on Android permissions in Unity, refer to [Android App Manifest](https://docs.unity3d.com/6000.2/Documentation/Manual/android-manifest.html).
* Fixed unreliable writing of `xr-meta-enabled` to boot.config by ensuring it is always set based on the actual feature state.
* Fixed a dependency issue by including AndroidJNI as a dependency. ([OXRB-696](https://jira.unity3d.com/browse/OXRB-696))
* Fixed the null exception in the Meshing and Intercept feature samples.
* Fixed issue where project settings window would fail to render if an OpenXR Feature was removed while the editor was running. ([OXRB-715](https://jira.unity3d.com/browse/OXRB-715))
* Fixed an error in Project Validation related to EntityId's in Unity 6000.4+.
* Fixed the OpenXR Native API to prevent the possibility of unexpected quits when you call APIs that require a valid OpenXR session but none exists.
* Fixed the XRInput Controller Sample to allow the right controller to display even if the left isn't connected.
* Fixed an issue where a validation rule only meant for Android was seen on Standalone platform.
* Fixed Android build exception when Meta Quest Pro interaction profile enabled and an OpenXR feature created without OpenXRExtensionStrings attribute.
* Fixed an edge case where the OpenXR Plugin would throw an error when choosing a custom OpenXR loader based on its feature's OpenXR specification version.
* Fixed Mono-API deprecation warning for AppDomain.UnhandledException calls  by disabling their warnings until replacement API is public.
* Fixed an issue that caused validation rules to not be checked for newly enabled features until the editor was restarted.

## [1.16.0] - 2025-10-15

### Added

 * Added public debug symbols for the UnityOpenXR library for Android platform that are available when building an APK with the Debug Symbols dropdown set to Public or Debugging. For more information, refer to [Android Symbols](https://docs.unity3d.com/6000.3/Documentation/Manual/android-symbols.html).
 * Added validation rule for Multi View Per View Viewport and Render Graph.

### Changed

* Changed the return values of the following pre-release APIs from `XrResult` to `OpenXRResultStatus`:
  * `OpenXRNativeAPI.xrEnumerateSpatialPersistenceScopesEXT(uint, out uint, XrSpatialPersistenceScopeEXT*)`
  * `OpenXRNativeAPI.xrEnumerateSpatialPersistenceScopesEXT(Allocator, out NativeArray<XrSpatialPersistenceScopeEXT>`
* Changed the OpenXR test "DuplicateSettingAssetTest" to be ignored.

### Fixed

* Fixed a crash with `OpenXRProjectionLayer` when a texture with a size larger than the view was used.
* Fixed a crash when the calls are sent to OpenXR library display subsystem before the OpenXR library is initialized manually.
* Fixed an issue where the user's OpenXR settings could be erased after creating a build.
* Fixed missing diagnostic logs for the available and requested OpenXR extensions under the OpenXR Runtime Info section.
* Fixed one frame flash of black screen when recentering view in floor space.
* Fixed OpenXR Project Settings so that changes to enabled interaction profiles are correctly saved when you close and re-open the Editor. ([OXRB-662](https://issuetracker.unity3d.com/product/unity/issues/guid/OXRB-662))

## [1.16.0-pre.2] - 2025-09-26

### Added

* Added the following members to the [OpenXR native API](xref:openxr-native-api):
  * `ISpatialConfiguration`
  * `XrBaseInStructure`
  * `OpenXRResultStatus.ToString`
  * `XrFovf` (removing the previous `COMPOSITION_LAYERS` preprocessor directive)
  * Added constructor overloads to structs that take `NativeArray<T>.ReadOnly` as input parameters.
  * `XrSpatialDiscoverySnapshotCreateInfoEXT.defaultValue`
  * `OpenXRNativeApi.xrPollFutureEXT(XrFutureEXT)`
  * `OpenXRNativeApi.xrCancelFutureEXT(XrFutureEXT)`
  * `OpenXRResultStatus.StatusCode.Unsupported`
  * static factory methods to construct `XrPosef`, `XrVector3f`, and `XrQuaternionf` from session-space data
  * `XrVector3f.ToSessionSpaceVector3`
  * `XrQuaternionf.ToSessionSpaceQuaternion`
  * `XrPosef.ToSessionSpacePose`
  * `XrPosef(UnityEngine.Pose)` constructor
  * `XrSpatialComponentDataQueryResultEXT(void*)` constructor
  * `XrSpatialComponentDataQueryResult.SetEntityIds` and `XrSpatialComponentDataQueryResult.SetEntityStates`
* Added a new validation rule for Meta Quest feature to ensure Application entry point being set to GameActivity for Unity 6.0+.

### Deprecated

* Deprecated Hololens Microsoft Hand Interaction Profile.

### Removed

* Removed a pre-release overload for `OpenXRNativeAPI.xrQuerySpatialComponentDataEXT` that didn't allow you to receive component data chained to the next pointer of the query condition.

### Fixed

* Fixed the Render Mode setting dropdown in OpenXR Settings to align consistently with the UI of other settings.
* Fixed `MockOpenXREnvironmentSettings` so that changes made to mock runtime settings don't affect the serialized settings assets in your project.
* Fixed `MockOpenXREnvironmentSettings` so that it doesn't save any unwanted changes to your EditorBuildSettings.
* Fixed swapchain diagnostic reports not being removed from cache after swapchains are destroyed.
* Fixed a compile error when using this package in Unity 6000.3.0b1 or newer, which was caused by the deprecation of the VR module in that Editor version.
* Fixed a crash when the OpenXR library was loaded with a path containing emojis on OSX.

## [1.16.0-pre.1] - 2025-08-14

### Added

* Added support for OpenXR features to define the OpenXR API version required to fully function.
* Added members to the `XrStructureType` enum. `XrStructureType` now contains all OpenXR values as of OpenXR version 1.1.49.
* Added support for multiple OpenXR features to define a custom loader and define the OpenXR API version that is supported by the feature's loader.
* Added the [OpenXR native API](xref:openxr-native-api) with initial support for the following extensions:
  * `XR_EXT_future`
  * `XR_EXT_spatial_anchor`
  * `XR_EXT_spatial_entity`
  * `XR_EXT_spatial_marker_tracking`
  * `XR_EXT_spatial_persistence`
  * `XR_EXT_spatial_persistence_operations`
  * `XR_EXT_spatial_plane_tracking`
* Added `RenderTexture` support for Composition Layers.
* Added class `MockOpenXREnvironment` and `MockOpenXREnvironmentSettings` for testing low-level runtime functionality using the Mock Runtime feature.
* Added [PollEventRouter](xref:UnityEngine.XR.OpenXR.NativeTypes.PollEventRouter), a new type that allows you to subscribe to `xrPollEvent` events.
* Added feature to enable Automatic Viewport Dynamic Resolution for compatible devices. Refer to [Automatic Viewport Dynamic Resolution](xref:openxr-automatic-dynamic-resolution) for information.
* Added MSAA support for Windows+Vulkan builds.
* Added support for enabling Subsampled Layout on Vulkan devices.
  * Added `Subsampled Layout (Vulkan)` setting to the Foveated Rendering Feature as an additional setting.
  * Added `FoveatedRenderingFeature.TrySetSubsampledLayoutEnabled` and `FoveatedRenderingFeature.isSubsampledLayoutEnabled` for runtime control.
* Added `OpenXRFeatureAttribute.CustomRuntimeLoaderName` for customizing the name used by a custom OpenXR loader provided by an OpenXR feature.

### Changed
* Changed OpenXR loader version to 1.1.49.
* Changed sample count of SwapchainCreateInfo to 1 as default instead of recommendedSwapchainSampleCount returning from the runtime.
* Updated minimum supported version from 2021.3 to 2022.3.
* Changed the OpenXR Validation for the minimum Android API level to only apply to Unity 6.2 and older versions.

### Removed
* Removed the validation warning to enable the OpenXR package if an OpenXR feature is enabled. Instead, OpenXR validation will only run when the OpenXR loader is selected as active loader.
* Remove HoloLens documentation as Unity has deprecated its support. Refer to [the public announcement](https://discussions.unity.com/t/hololens-2-deprecation/1661529) for more information.

## [1.15.1] - 2025-07-23

### Fixed

* Fixed compile errors due to `AssetDatabase.CanOpenAssetInEditor(int)` and `AssetDatabase.OpenAsset(int)` were deprecated in Unity 6.3 and newer.
* Fixed an issue in which the wrong normalized device coordinates (NDC) convention was used for SpaceWarp motion vectors. Application developers must now specify whether the current device uses right- or left-handed NDC for motion vectors when SpaceWarp is enabled.

## [1.15.0] - 2025-06-12

### Added

* Added settings and a component to enable URP Application Spacewarp for compatible devices. Refer to [URP Application Spacewarp](xref: openxr-spacewarp) for information.
* Added a validation rule for warning of Magic Leap 2 limit to existing projects from Unity 6.3.

### Changed

* Check whether the requested eye tracking permission has been granted before requesting permission.
* Changed the Composition Layers native implementation to create global references of Android surface objects.

### Fixed

* Fixed compile errors due to `TreeView`, `TreeViewState` and `TreeViewItem` were deprecated in Unity 6.2 and newer.
* Fixed an issue to only apply OpenXR related bootconfig when OpenXR Loader is enabled.
* Enabled `XR_FB_swapchain_update_state` extension by default if available to fix `XR_ERROR_EXTENSION_DEPENDENCY_NOT_ENABLED` runtime error when `XR_FB_foveation` extension was enabled by default.
* Fixed incorrect display of the `Use OpenXR Predicted Time` toggle in Unity versions below 6.2.
* Fixed a crash that could occur when changing scenes containing an `OpenXRDefaultLayer` with extensions.
* Fixed compile errors due to `EditorUtility.InstanceIDToObject` being deprecated in Unity 6.3 and newer.
* Fixed foveation data corruption leading to visual anomalies when the OpenXR swapchain was frequently resized.
* Fixed an increase in memory that was seen in older editors that are not checking for the OffScreen Rendering Only bootconfig value.

## [1.15.0-pre.2] - 2025-05-15

### Added

* Added `OpenXRLayerUtility.RequestRenderTextureId` and `OpenXRLayerUtility.RequestStereoRenderTextureIds`. These functions have callback parameters because they execute on the graphics thread.
* Added support for a new Multiview Render Regions Optimization mode - All Passes, which gets applied to as many passes as possible instead of only the final pass of the render in XR.

### Changed

* Changed the Symmetric Projection validation rule that checks for Vulkan api to a warning instead of an error.
* Deprecated  `OpenXRLayerUtility.FindRenderTexture`, `OpenXRLayerUtility.FindAndWriteToRenderTexture`, `OpenXRLayerUtility.FindAndWriteToStereoRenderTextures`, and `OpenXRLayerUtility.FindAndWriteToStereoRenderTextures`.
* Swapchain images are acquired on the graphics thread with `OpenXRLayerUtility.RequestRenderTextureId` and `OpenXRLayerUtility.RequestStereoRenderTextureIds` and automatically released by the OpenXR plugin on the graphics thread.
* Enable `XR_FB_foveation` and `XR_FB_foveation_configuration` extensions by default if available for runtime.
* Changed Multiview Render Regions (Vulkan) setting for Meta Quest Support from a check box to dropdown menu with three options: None, FinalPass and AllPasses.

### Fixed

* Fixed errors when opening Profiler (Standalone Process) with OpenXR Plugin is present in the project.
* Fixed Mock Runtime occlusion mesh rendering.
* Fixed an issue that OpenXR Project Settings window appears blank and Editor freezes when upgrading package version to 1.14.1 or higher.

## [1.15.0-pre.1] - 2025-04-24

### Added

* Added `OpenXREditorSettings.VulkanOffscreenSwapchainNoMainDisplay` property to request at startup to use offscreen rendering for devices that require it. The setting can be enabled through the Project settings UI and build code. This setting should be disabled for handheld platforms.
* Added Meta Quest input profile features when switching to Meta Quest Build Profile.
* Added `Use OpenXR Predicted Time` UI setting to enable OpenXR time prediction which allows the hardware and runtime to set the display time prediction for the next frame instead of Unity.
* Added a new OpenXrSetting, [LatencyOptimization](xref:openxr-project-config#latency-optimization) to allow developers to choose to prioritize rendering latency or input polling latency.
* Added optional project validation check for Link Time Optimization with Meta Quest.
* Added `UnityXRDisplay::DestroyTexture` API so providers can access them to destroy textures created by `UnityXRDisplay::CreateTexture` API.
* Added a validation rule for setting Latency Optimization to Prioritize Input Polling with Meta Quest Support enabled.

### Changed

* Recompiled the native Android plug-in with support for [16 KB page sizes](https://developer.android.com/guide/practices/page-sizes) on Android 15 or newer.

### Fixed

* Fixed offscreen rendering flags to be added only when the "Offscreen Rendering Only (Vulkan)" Android OpenXR UI setting is enabled. [IN-78279](https://unity3d.atlassian.net/servicedesk/customer/portal/2/IN-78279).
* Fixed Meshing and Intercept features not being enabled by default when the sample was imported.
* Fixed OpenXRCustomLayerHandler class so it now explicitiy calls acquire and release on swapchains for every layer on the main thread and caches swapchain image render textures for efficiency.
* Fixed an issue where `OpenXRInput.TryGetInputSourceName` failed to retrieve the input source name.

## [1.14.3] - 2025-04-18

### Fixed

* Fixed Multiview Render Regions feature regression.

## [1.14.2] - 2025-03-20

### Added

* Added a validation rule about the minimum Android API level is 24.
* Added support for visible triangle mesh to be available for use in post processing.

### Changed

* Modified the Meta Quest Support feature to use the updated Khronos OpenXR loader library.
* Changed OpenXR loader version to 1.1.45.

### Fixed

* Fixed an issue that enabled interaction profiles setting not being saved after reopening the project.
* Fixed a bug that depth submission mode corrupting the spacewarp depth texture.
* Fixed a bug that wrong view configuration type being selected as primary view and causing rendering issues.
* Fixed an issue on Android platforms where `xrCreateSwapchainAndroidSurfaceKHR` was attempted to be used even when the XR Composition Layers package wasn't installed.
* Fixed an issue that Meta XR simulator can't launch properly on Mac.

## [1.14.1] - 2025-02-14

### Added

* Added a validation rule to the Meta Quest Support feature to ensure that your app's default interface orientation uses a supported value.

### Changed

* Modified the Meta Quest Support feature to use the updated Khronos OpenXR loader library.

### Fixed

* Fixed the OpenXRFeatureBuildHooks class so it now grabs the OpenXRSettings object from the given build target during build processing.
* Fixed duplicate OpenXR feature assets being added to the OpenXRSettings asset when upgrading to a newer OpenXR package version.
* Fixed rendering problems with Mixed Reality Capture.
* Fixed a debug log spamming issue regarding ignored event types. This message could be logged multiple times per frame and was not helpful.
* Fixed Meta-specific eye-tracking manifest permissions to be added only to apps targeting Meta Quest Pro devices.
* Fixed an issue where spacewarp may assign motion vector textures to wrong render passes when using secondary views.
* Fixed a bug when allocating array swapchain failed, the index was incremented incorrectly.
* Fixed an issue when OpenXR feature didn't have all the attribute entries setup.

## [1.14.0] - 2024-12-13

### Added

* Added support for the RG16f texture format and a selection mode for the texture format of the Space Warp motion vector texture for the Meta Quest feature. You can select the format for the Space Warp motion vector texture in Editor > Project Settings > XR Plug-in Management > OpenXR > Android tab > Meta Quest Support feature settings.
* Added the following extension methods for `XrResult`: `IsSuccess()`, `IsUnqualifiedSuccess()`, and `IsError()`, which you can use to more conveniently reason about `XrResult` values.
* Added new values to the `XrResult` enum to match the values present in the native `XrResult` type in OpenXR 1.1.36.
* Added support for locating the OpenXR loader for the Meta XR Simulator on OSX.
* Added new Optimize Multiview Render Regions settings option for Meta Quest devices. In the context of XR rendering, Multiview Render Regions enables the drivers to skip shader invocations (and rendering work) for screen areas outside of the user's view (such as the nasal regions that the user can't see within the headset). You can toggle on support for Multiview Render Regions in Editor > Project Settings > XR Plug-in Management > OpenXR > Android tab > Meta Quest Support feature settings. Note that Multiview Render Regions requires Symmetric Projection settings toggle turned on, and Render Mode set to Single Pass Instanced \ Multi-view. Multiview Render Regions is only supported in the Vulkan Graphics API, and it is activated at application start up.
* Added project validation warning to prevent user from using URP upscaling with XR.

### Deprecated

* Deprecated `XrResult.TimeoutExpored` and `XrResult.AndroidThreadSettingsdFailureKHR` and replaced them with correctly spelled enum values.

### Fixed

* Occlusion Mask vertices projected based on FOV.

## [1.13.2] - 2024-11-15

### Added

* Added UWP platform as one of the supported build targets for OpenXR Composition Layer feature.

### Fixed

* Fixed compiler errors when using experimental versions of the XR Composition Layers package (versions older than 1.0.0). You are required to use XR Composition Layers 1.0.0 or newer for OpenXR support.

## [1.13.1] - 2024-10-31

### Fixed

* Conformance Automation Feature:  Removed assert for optional entry point xrSetInputDeviceVelocityUNITY.
* Fixed an issue where `OpenXRInput.TryGetInputSourceName` failed to retrieve the input source name.

## [1.13.0] - 2024-09-16

### Added

* Added Meta XR Simulator as runtime option for OpenXR. One can search for the `com.meta.xr.simulator` package to add the Open XR runtime to the dropdown list of available runtimes during Play Mode.
* Added a `Quest 3S` option to `Target Devices` in the Meta Quest Support settings. This specifies the application's support for Quest 3S devices within the Android manifest.
* Added `IUnityXRDisplay::CreateTexture` API to C# script so providers can access them for functionality.
* Added APIs to provide an alternative to the Input System: `OpenXRFeature.GetAction`, `OpenXRInput.GetActionHandle`, `OpenXRInput.SendHapticImpulse`, `OpenXRInput.StopHapticImpulse`, `OpenXRInput.TrySetControllerLateLatchAction`, and `OpenXRInput.GetActionIsActive`.
* Added a "Controller XRInput" sample to demonstrate how to access input data without the Input System.
* Added experimental support for XR Composition Layers support. Install the Unity [Composition Layer (com.unity.xr.compositionlayers)](https://docs.unity3d.com/Packages/com.unity.xr.compositionlayers@latest?subfolder=/changelog/CHANGELOG.html) package to use composition layers in an OpenXR project.
* Added support for the `XR_KHR_maintenance1` extension. This low-level extension provides support for new capabilities promoted in the OpenXR 1.1 standard, which may be needed for backwards compatibility for using new extensions in OpenXR loaders using the version 1.0 of the standard. You need to request this extension if your project will make use of OpenXR 1.1 extenstions that need this extension and are backwards compatible with loaders based on the 1.0 version of the OpenXR standard. If your project targets only the OpenXR 1.1 version, you don't need to request this extension. To use the `XR_KHR_maintenance1` extension, you must request it as part of your own [OpenXR feature definition](xref:openxr-features). Refer to [XR_KHR_maintenance1](https://registry.khronos.org/OpenXR/specs/1.1/html/xrspec.html#XR_KHR_maintenance1) for more information on the extension.
* Added OpenXR 1.1 Runtime support.

### Changed

* Added [Known Issue](xref:openxr-manual#known-issues) to documentation covering how OpenXR doesn't provide Acceleration or Angular Acceleration values for input devices, and these will always return 0.
* Added a validation rule requiring Multi-view to be enabled in order to enable Symmetric Projection.
* Implements the construction and maintenance of native composition layers in C# via our LayerProvider classes inheriting from OpenXRCustomLayerHandler.
* Changed OpenXR loader version to 1.1.36.

### Fixed

* Symmetric Projection was being gated behind foveation extensions being enabled. This wasn't necessary and that dependency has been removed.
* Fixed a bug that causes a user to need a validation rule to make OpenXR loader active.
* Fixed `m_BlendMode` from being overwritten whenever the `DisplaySubsystem` restarts.
* Fixed Metal API initialization.
* Fixed Custom Composition Layer Feature not showing up in the OpenXR feature setting UI after importing into project.
* Fixed a crash with composition layers in scene due to race condition.

## [1.12.1] - 2024-09-05

* Fixed rendering bug when rendering viewport scale < 1.
* Fixed issue where the Editor would hang when renaming and then viewing OpenXR Settings.

## [1.12.0] - 2024-08-01

### Added

* Add class `MetaQuestTouchPlusControllerProfile.QuestTouchPlusController` interaction profile to support Meta Quest Touch Plus Controllers.
* Added a validation rule to warn you that soft shadows can negatively affect performance for Microsoft HoloLens.
* Added a validation rule to infrom you to make the OpenXR Loader an active loader in XR Plugin Management if there are active OpenXR features in the OpenXR settings.
* Added `OpenXRSettings.autoColorSubmissionMode` boolean property to specify OpenXR to use a platform-supported color format in the display swapchain, or for you to manually set which format should OpenXR to use.
* Added `OpenXRSettings.colorSubmissionModes` array property to control the color format used by the OpenXR display swapchain. The available options can be chosen from the `OpenXRSettings.ColorSubmissionModeGroup` enum. OpenXR will use supported color formats by the platform, starting from the first option in the list. In case none of the color formats supplied is supported by the platform, an error will be thrown. If no color formats are assigned, the format used will be RGBA32.
* Added `Automatic Color Submission Mode` toggle and `Color Submission Modes` list to the OpenXR project settings tab, allowing you to manually specify the preferred color format to be used by the display swapchain. OpenXR will use supported color formats by the platform, starting from the first option in the list. In case none of the color formats supplied is supported by the platform, an error will be thrown. If no color formats are assigned, the format used will be RGBA32.

### Fixed

* Fixed sort order of OpenXR features listed based first on priority, then by name, preventing spurious changes in Settings files.

## [1.11.0] - 2024-05-01

### Added
* Added the `XrPerformanceSettings.SetPerformanceLevelHint` static method, which lets you send performance level suggestions to the runtime. These hints help an OpenXR runtime to optimize the use of hardware resources according to the application needs. Refer to [XR performance settings](xref:openxr-performance-settings#performance-settings-level-hints) for more information. This requires the [XR_EXT_performance_settings](https://registry.khronos.org/OpenXR/specs/1.0/html/xrspec.html#XR_EXT_performance_settings) extension is enabled in the OpenXR runtime.
* Added the `XrPerformanceSettings.OnXrPerformanceChangeNotification` event, which provides notifications from the OpenXR runtime when a device's thermal, rendering, or compositor performance state changes. The performance states include: `Normal`, `Warning`, and `Impaired`. Refer to [XR performance settings](xref:openxr-performance-settings#performance-settings-notifications) for more information. This requires the [XR_EXT_performance_settings](https://registry.khronos.org/OpenXR/specs/1.0/html/xrspec.html#XR_EXT_performance_settings) extension is enabled in the OpenXR runtime.
* Added a`Quest 3` option to the `Target Devices` set in the Meta Quest Support settings. This specifies the application's support for Quest 3 devices within the Android manifest.
* Added missing ButtonControl actions `pinch_ext`, `aim_activate_ext` and `grasp_ext` for Hand Interaction Profile.
* Added API `OpenXRUtility.ComputePoseToWorldSpace` to recalculate object position and rotation from tracking-space to world-space. Applicable for use cases such as teleporting.
* Added support for using Local Floor Reference Space in the OpenXR runtime. Useful in applications that require the user to be seated or in a standing fixed position.
* Added PreInit flags to allow users to disable the main frame buffer and use offscreen swapchain when using Vulkan on Android in the OpenXR settings.
* Added functional DX12 mock runtime support to the OpenXR package.
* Added `RegisterStatsDescriptor` method to the `OpenXRFeature` abstract class, which lets your OpenXR feature to register a new statistic that can be feed into and queried at runtime. This method is not thread safe.
* Added `SetStatAsFloat` method to the `OpenXRFeature` abstract class, which lets your OpenXR feature to feed a float value into a specific statistic that was previously registered using the `RegisterStatsDescriptor`. This method is thread safe.
* Added `SetStatAsUInt` method to the `OpenXRFeature` abstract class, which lets your OpenXR feature to feed an unsigned integer value into a specific statistic that was previously registered using the `RegisterStatsDescriptor`. This method is thread safe.
* Added the `OpenXRSettings.RefreshRecenterSpace` static method, which lets you regenerate the internal XR space used for recentering, without the need to wait until a recenter event is received by the OpenXR SDK. Note that this method does not perform a recenter event in any way, as this can only be done by the device runtime.
* Added Pre-pass Foveated Rendering for both d3d12 and Vulkan. This feature utilizes Fragment Density Mapping on Quest Devices and Fragment Shading Rate on PC to optimize rendering performance. Refer to [Foveated Rendering](xref:openxr-foveated-rendering) for more information.
* Added `OpenXRUtility.IsSessionFocused` to return if the current session is in the focused state.
* Added `OpenXRUtility.IsUserPresent` to return the change of user presence, such as when the user has taken off or put on an XR headset. If the system does not support user presence sensing, runtime assumes that the user is always present and IsUserPresent always returns True. If the system supports the sensing of user presence, returns true when detected the presence of a user and returns false when detected the absence of a user.

### Changed
* Changed tracking origin to use Local Floor in place of Floor by default.
* Changed delta time calculation to utilize OpenXR for frame estimation. Previously internal Unity mechanisms were used. This feature is currently disabled but will be available in the future.
* When retrieving input feature from [CommonUsages.userPresence](https://docs.unity3d.com/ScriptReference/XR.CommonUsages-userPresence.html), if XR_EXT_user_presence is supported by the current system, retrieved value will be the same as `OpenXRUtility.IsUserPresent`. If `XR_EXT_user_presence` is not supported, retrieved value will be based on `OpenXRUtility.IsSessionFocused`, which is the default return value before 1.11.0.

### Fixed
* Fixed Marshal to correctly read the number of bytes for booleans in C++.
* Fixed crash that occurs while cleaning up destroyed swapchains in OpenXR.
* Fixed Depth Texture flag disparity between the OpenXR and Oculus providers.

## [1.10.0] - 2024-01-26

### Added
* Added `OpenXRSettings.VulkanAdditionalGraphicsQueue` property to request at startup an additional Vulkan graphics queue in devices that require it. The setting can be enabled through the Project settings UI and build code.
* Added `Optimize Buffer Discards (Vulkan)` feature setting option within MetaQuestFeature.
* Added a new optional validation rule to switch to use InputSystem.Controls.StickControl instead of Vector2Control for thumbsticks. StickControl allows more input options for thumbstick-based control, such as acting as both a combined 2D vector, two independent axes or a four-way Dpad with 4 independent buttons.

### Changed
* Updated project validation rule for Meta Quest Feature - "Select Oculus Touch Interaction Profile or Meta Quest Pro Touch Interaction Profile to pair with." from error to warning to allow other interaction profiles to be enabled as well, like eye gaze or palm pose.

### Fixed
* Fixed Meta XR `Space Warp` feature crashing issue when trying to access the depth swapchain.
* Fixed Meta XR `Space Warp` depth subimage imageArrayIndex setup wrong issue for multiview render mode.
* Fixed a bug where Palm Pose won't work if the Eye Gaze Interaction Profile is added to the project.
* Fixed "The type 'AnalyticsResult' is defined in an assembly that is not referenced" error thrown.
* Fixed UnitySwapchain destructor to completely destroy swapchains to avoid memory leak.
* Fixed OpenXR Settings UI to not render settings on platforms that aren't supported.
* Fixed Android manifest entries were added when the feature was not enabled.

## [1.9.1] - 2023-10-19

### Added
* Implemented `InputSystem.customBindingPathValidators` interface to show UI warnings in the `InputAsset` Editor when added bindings to a disabled interaction profile and when none of the controller type interaction profiles are enabled, but added bindings using generic XRController.
* Added APIs `GetInteractionProfileType` and `GetDeviceLayoutName` to support binding path validator feature.
* Added API `TrySetControllerLateLatchAction` to support controller late latching. Also added MarkLateLatchNode.cs in Controller Sample for usages example.
* Added support for Meta XR feature `Symmetric Projection`, `Space Warp`, and `Eye Tracked Foveation`.
* Added the option to enable `Subsampled Layout` when creating a Vulkan swapchain.
* Added support for recentering Floor tracking origin using new API, `OpenXRSettings.SetAllowRecentering`. This static method allows the app to recenter the tracking origin space when requested by the runtime. Note that calling the method won't trigger a recenter event.
* Added support for Meta XR feature `System Splash Screen`.
* Added public API for MetaQuestFeature.forceRemoveInternetPermission.

### Changed
* Updated Input System package dependency to 1.6.3.
* Updated XR management dependency to 4.4.0.
* Updated OpenXR loader to 1.0.29.
* Changed MockRuntime and its FeatureSet to public.

### Fixed
* Fixed incorrect XR Validation rules after regenerating the OpenXR package settings asset.
* Fixed analytics code being called when disabled.
* Fixed latency issue with controller poses.
* Fixed an XR_ERROR_SESSION_NOT_RUNNING error if xrRequestExitSession is called when the session is not running.

## [1.8.2] - 2023-07-18

### Added
* Added a new optional validation rule to recommend disabling Screen Space Ambient Occlusion render feature in UniversalRenderer assets to avoid significant performance overhead.

### Changed
* Removed `Windows Mixed Reality feature group` from Windows build target.

### Fixed
* Fixed issue that UWP player tries to initialize XR when "Initialize XR on Startup" is unchecked.
* Fixed `SetOutput Failed.` and `SetInput Failed.` log spamming issue when audio sources is not available.
* Fixed performance drop after headset becomes inactive.
* Fixed Hand Common Poses Interaction Profile and Palm Pose feature documentation links broken.
* Fixed Mock Runtime option toggles on accidentally after entering Play Mode.
* Fixed hand tracking position and rotation not being tracked with XR Hand device.

## [1.8.1] - 2023-06-09

### Added
* Added functionality in `OpenXRFeatureBuildHooks` exposing the BootConfig for reading/writing.
* Added `Force Remove Internet Permission` setting to the Meta Quest Feature settings, allowing to remove Internet permissions added automatically to the application manifest.
* Added class HPReverbG2ControllerProfile.ReverbG2Controller and a new interaction profile to support the HP Reverb G2 controllers.
* Added Hand Interaction Profile and added PalmPose and dpad EXT implementations.

### Changed
* Modified `ModifyAndroidManifestMeta` class to provide required Android manifest entries using a new internal XR system, instead of manually modifying the manifest file.
* Updated the IsTracked and TrackingState Input Features names with a Usage prefix to prevent name collisions.
* Updated OpenXR loader to 1.0.27.

### Fixed
* Fixed type `XrCompositionLayerPassthroughFB` not appearing in the runtime debugger.
* Fixed crash when deploying to Android on Unity 2023 due to using type `Activity` over `GameActivity`.
* Fixed issue on Android where screen captures only capture the view on one eye.

## [1.7.0] - 2023-02-21

### Added
* Added API `OpenXRRuntime.retryInitializationOnFormFactorErrors` to retry xrGetSystem during initialization if xrGetSystem returns a form factor error.
* Enable XR_META_performance_metrics. This enables performance stats for Meta Quest devices on OpenXR.
* Add class MetaQuestTouchProControllerProfile.QuestProTouchController new interaction profile to support Meta Quest pro controllers.
* Added ability for OpenXRFeature derived classes to add Awake() functions.
* Added API `OpenXRInput.GetActionIsActive` to check whether an InputAction has any bindings which are currently active.
* Added API `OpenXRInput.GetActionHandle` to get the action handle of an InputAction and returns 0 if not found.

### Changed
* Updated documentation for the Meta Quest feature.

### Fixed
* Fixed - Meta builds now don't include Bluetooth permissions in Android manifest by default when using Microphone class in script code.
* Fixed crash in OpenXR runtime debugger when cache size is set to 0.
* Fixed OpenXR project validation to check for correct versions of OpenGLES in Unity 2023 and up.
* Fixed crash when runtime reports an invalid view configuration from xrWaitFrame.
* Fixed - OpenXR plugin will only look up functions from supported and enabled extensions.
* Fixed GPU selection in multi-GPU scenarios.

## [1.6.0] - 2022-11-29
### Added
* Added `Meta Quest Feature` support for Android and deprecated previous `Oculus Quest Feature`. Also added a new validation rule to support new Meta Quest Feature migration.
* Added API `MetaQuestFeature.AddTargetDevice` to add additional target devices to the devices list in the MetaQuestFeatureEditor.
* Added Thumbrest Touch support in Oculus Touch Controller Interaction Profile.
* Added a new optional validation rule to switch to use InputSystem.XR.PoseControl instead of OpenXR.Input.PoseControl, which fixed PoseControl conflicts in InputSystem.XR and OpenXR.Input. Note: If opt in to use InputSystem.XR.PoseControl, `USE_INPUT_SYSTEM_POSE_CONTROL` will be added in Scripting Define Symbols under Player settings.

### Changed
* Updated Input System dependency to 1.4.4.

### Fixed
* Fixed issue where game window would show as black in URP.
* Fixed `InputDevice.TryGetHapticCapabilities` always returning True with OpenXR.
* Fixed repeated "Failed to restart OpenXR" warnings when no HMD is attached.
* Fixed invalid pose values getting populated when tracked flags are invalid.
* Fixed XR_SPACE_BOUNDS_UNAVAILABLE return code marked as Error in the log.

## [1.5.2] - 2022-09-08
### Added
* Added support for Android cross-vendor loader.

### Changed
* Updated Input System dependency to 1.4.2.

### Fixed
* Fixed `XRInputSubsystem.TryGetBoundaryPoints` returning inaccurate values. If you have guardian/boundary setup in the headset, `TryGetBoundaryPoints` will return a List<Vector3> of size 4 representing the four vertices of the Play Area rectangle, which is centered at the origin and edges corresponding to the X and Z axes of the provided space. Not all systems or spaces may support boundaries.
* Fixed an issue that controllers position not getting updated and stuck to the floor level when Oculus Integration Asset installed in the project.
* Fixed an issue that OpenXR libraries were included in build when OpenXR SDK is not enabled.
* Improved domain reload performance by removing unnecessary checks when entering Playmode.

## [1.5.1] - 2022-08-11
### Added
* Added generic Project Validation status in the **Project Settings** window under **XR Plug-in Management** if you have [XR Core Utilities](https://docs.unity3d.com/Packages/com.unity.xr.core-utils@latest) 2.1.0 or later installed. These results include the checks for all XR plug-ins that provide validation rules.
* Added API `OpenXRFeature.SetEnvironmentBlendMode` to set the current XR Environment Blend Mode if it is supported by the active runtime. If not supported, fall back  to the runtime preference.
* Added API `OpenXRFeature.GetEnvironmentBlendMode` to return the current XR Environment Blend Mode.
* Added support for `XR_MSFT_holographic_windown_attachment` extension on UWP so that installing Microsoft Mixed Reality OpenXR Plug-in is no longer required if targeting HoloLens V2 devices. And removed corresponding project validator.
* Added support for `XR_FB_foveation`, `XR_FB_foveation_configuration`, `XR_FB_swapchain_update_state`, `XR_FB_foveation_vulkan` and `XR_FB_space_warp` extensions.
* Added ability to recover the application after Oculus Link was aborted and re-established. Attempt to restart every 5 seconds after Link disconnected.
* Added validation rule for duplicate settings in OpenXRPackageSettings.asset.

### Changed
* Updated Oculus Android manifest with focusAware, supportedDevices and headTracking tags added. Also added a new validation rule to check if Oculus target devices are selected.
* Updated OpenXR Loader to 1.0.23.
* Updated Input System dependency to 1.4.1.

### Fixed
* Fixed compilation errors on Game Core platforms where `ENABLE_VR` is not currently defined. Requires Input System 1.4.0 or newer.
* Fixed an issue that was causing Oculus Android Vulkan builds rendering broken after sleep / awake HMD.
* Fixed Oculus controllers tracking issues when both OpenXR package and Oculus package are installed in the project.
* Fixed an issue in Play Mode OpenXR Runtime selection that `Other` option would be reverted to `System Default` after entering and exiting playmode.
* Fixed a bug in `XR_VARJO_quad_views` support.

## [1.4.2] - 2022-05-12
### Fixed
* Fixed unnecessary destroying session on pause and resume.

## [1.4.1] - 2022-04-13
### Added
* Added runtime failures handling to completely shut down OpenXR when runtime error occurred.
* Added support to dynamically discover runtimes by registry key.
* Added logging for no MainCamera tag detected when depthSubmission mode enabled.
* Added console error logging if entering playmode on unsupported platforms.
* Added support to automatically open OpenXR project validator if any issues detected after package update.
* Added API `OpenXRFeature.GetViewConfigurationTypeForRenderPass`, which returns viewConfigurationType for the given renderPass index.
* Added pre-init support for UWP / WSA platform. Note: OpenXR got unchecked by upgrading to this version (only on UWP), but options chosen under `Features` remained as they were.

### Changed
* Updated OpenXR Loader to 1.0.20.
* Updated Render Mode naming to Single Pass Instanced / Multiview for Android platform.
* Updated Input System dependency to 1.3.0.
* Updated XR mirror view to be based on the occlusion mesh line loop data obtained from `xrGetVisibilityMaskKHR`.

### Fixed
* Fixed an issue that would cause failure to load OpenXR loader when non-ascii characters in project path.
* Fixed an editor crash issue when updating OpenXR package version and then enter Playmode.
* Fixed `EyeGaze` functionality not working in the `Controller` sample.
* Fixed Oculus `MenuButton` not being recognized in script.
* Fixed an issue that some OpenXR Editor settings not being serialized properly.
* Fixed `Failed to suggest bindings for interaction profile` console error spamming when a runtime doesn't support a certain interaction profile.

## [1.3.1] - 2021-11-17
### Changed
* Updated documentation link to 1.3.
* Updated Oculus Android manifest with intent-filter.

### Fixed
* Fixed an issue in `OpenXRRestarter` that would prevent a subsequent restart.
* Fixed an issue in `OpenXRRestarter` that would cause a restart to fail depending on where it was initiated in the stack.
* Fixed an issue in UWP that would prevent the main window from being rendered to when using remoting.
* Fixed incorrect negative values on controller linear velocities.
* Fixed a bug in HMD trackingState that would cause tracking state to flip back and forth between two states every frame.

## [1.3.0] - 2021-10-20
### Added
* Added API `OpenXRInput.SendHapticImpulse`
* Added API `OpenXRInput.StopHaptics`
* Added API `OpenXRInput.TryGetInputSourceName`
* Added event `OpenXRRuntime.wantsToRestart`
* Added event `OpenXRRuntime.wantsToQuit`
* Added support for `XR_OCULUS_audio_device_guid` extension.
* Added `Haptic` control to OpenXR Controller Profile layouts that can be bound to an action and used to trigger haptics using the new `OpenXRInput.SendHapticImpulse` API.

### Changed
* Improved `OpenXRFeatureSetManager.SetFeaturesFromEnabledFeatureSets` so that no internal methods are required after calling this.
* Updated `Controller` sample to improve the visuals and use the new APIs.

### Fixed
* Fixed ARM32 crash when OpenXR API layers were present
  * [ISSUE-1355859](https://issuetracker.unity3d.com/issues/xr-uwp-any-openxr-layer-will-crash-unityopenxr-dot-dll-on-hololens2-when-compiling-with-arm32)
* Fixed issue that would cause console errors if `OpenXRFeature.enable` was changed while  the OpenXR Projects Settings windows was open.
* Fixed potential Android crash when shutting down.
* Fixed potential crash with `XR_MSFT_SECONDARY_VIEW_CONFIGURATION_EXTENSION_NAME`
* Fixed issue with alpha channel on Projection layer causing visual artifacts.
  * [ISSUE-1338699](https://issuetracker.unity3d.com/issues/xr-openxr-a-black-background-is-rendered-in-hmd-when-using-solid-color-camera-clear-flags)
  * [ISSUE-1349271](https://issuetracker.unity3d.com/issues/xr-sdk-openxr-post-processing-postexposure-effect-has-visual-artifacts)
  * [ISSUE-1346455](https://issuetracker.unity3d.com/issues/xr-sdk-openxr-right-eye-contains-artifacts-when-taa-anti-aliasing-is-used-with-multi-pass-rendering-mode)
  * [ISSUE-1336968](https://issuetracker.unity3d.com/issues/xr-openxr-oculus-post-processing-view-in-hmd-is-darker-and-sometimes-flickers-when-changing-depth-of-field-focus-distance)
  * [ISSUE-1338696](https://issuetracker.unity3d.com/issues/xr-sdk-openxr-black-edges-are-rendered-on-the-game-objects-when-fxaa-anti-aliasing-is-used)
* Fixed bug that caused Vulkan support on Oculus to stop working.
* Fixed missing usages on `HoloLensHand` layout.
* Fixed vulkan shared depth buffer on versions `2021.2.0b15` and `2022.1.0a8` or higher.

## [1.2.8] - 2021-07-29
### Fixed
* Fixed an issue that was causing Oculus Android OpenGL builds to stop working after v31 of the oculus software was installed.
* Fixed a bug that would cause Asset Bundles to fail building in some circumstances when OpenXR was included in the project.
* Fixed a crash that would occur if XR was shut down from within a Feature callback.
* Fixed a bug that was causing duplicate entries in the OpenXR Package Settings file.
* Fixed a bug causing angular velocities on both the HMD and controllers to have the wrong sign when compared to the other Unity XR plugins.

## [1.2.3] - 2021-06-17
### Added
* Ensured a deterministic order of features within the OpenXR Settings.

### Changed
* Updated OpenXR Loader to 1.0.17.
* Changed `feature set` text to `feature group` in the top level XR-Management list.

### Fixed
* Fixed missing haptic output on HTC Vive controller profile.
* Fixed bug that caused `ThumbstickTouched` binding on the `ValveIndex` controller profile to not work.
* Fixed issue that would cause the app to not exit when closed by the runtime.

## [1.2.2] - 2021-06-01
### Added
* Editor runtime override will no longer change the runtime for standalone builds executed using `Build and Run`.

### Changed
* Renamed `Feature Sets` to `Feature Groups` in the UI.

### Removed
* Removed unnecessary build hook for `EyeGaze` that was causing incorrect capabilities to be set on `HoloLens2`.

### Fixed
* Fixed a bug when using SteamVR runtime that would cause the view to stop rendering and input to stop tracking if the main thread stalled for too long.
* Fixed bug with feature sets that could cause the XR Management check box to be out of sync with the checkbox on the OpenXR Settings page.
* Fixed bug with HTC Vive controller profile that caused the `aim` and `grip` poses to be identical.

## [1.2.0] - 2021-05-06
### Added
* Enabled Android build target for Oculus Quest via the `Oculus Quest Support` feature.
* OpenXR Settings UI reworked to make managing features and interaction profiles easier.
* Added menu item to open Project Validation window (`Window > XR > OpenXR > Project Validation`).
* Project validation window now supports manual fixes for an issue.
* Project validation window now supports optional help links for an issue.
* Added `OpenXRFeature.OnEnableChanged` method to give features a chance to handle their enabled state changing.
* Added `IPackageSettings.GetFeatures` method that returns all features of a given type from all build targets.

### Removed
* Removed `experimental` text from OpenXR plugin help icon.
* Removed `Linear` color space restriction for all build targets and graphics apis except OpenGLES.

### Fixed
* Fixed bug with haptics that caused `XRControllerWithRumble.SendImpulse` to not work with `OpenXR`.
* Fixed bug that could cause some interaction profile device layouts to not be registered on startup.

## [1.1.1] - 2021-04-06
### Added
* Oculus controller profile now exposes both grip and aim poses.
* Added support for `XR_VARJO_QUAD_VIEWS` extension.
* Added `XR_COMPOSITION_LAYER_UNPREMULTIPLIED_ALPHA_BIT` and `XR_COMPOSITION_LAYER_BLEND_TEXTURE_SOURCE_ALPHA_BIT` bits to the composition layer flags.
* Added `XrSecondaryViewConfigurationSwapchainCreateInfoMSFT` to to `XrSwapchainCreateInfo` when using a secondary view.
* MockRuntime First Person Observer View support
* MockRuntime input support
* MockRuntime vulkan_enable2 support
* MockRuntime d3d11_enable support

### Changed
* `OpenXRSettings.renderMode` and `OpenXrSettings.depthSubmissionMode` can now be changed via script outside of play mode.

### Fixed
* Fixed issue where OpenXR layouts were not visible in the InputSystem bindings dialog.
* Fix for managed stripping levels of Medium and High
* Fixed bugs in `XR_KHR_VULKAN_ENABLE2` extension support

## [1.0.2] - 2021-02-04
### Fixed
* Resolve further release verification issues.

## [1.0.1] - 2021-02-03
### Fixed
* Resolve release verification issues.

## [1.0.0] - 2021-01-27
### Added
* Runtime Debugger to allow for the inspection of OpenXR calls that occur while OpenXR is actively running.
* XR Plug-In Management dependency update to 4.0.1
* Input System dependency updated to 1.0.2

## [0.1.2-preview.3] - 2021-01-19
### Added
* Implemented `XR_KHR_loader_init` and `XR_KHR_loader_init_android`.
* Added support for `XR_KHR_vulkan_enable2` alongside `XR_KHR_vulkan_enable`.

### Changed
* Updated dependency of `com.unity.xr.management` from `4.0.0-pre.2` to `4.0.0-pre.3`.

## [0.1.2-preview.2] - 2021-01-05
### Fixed
* Fix publishing pipeline.

## [0.1.2-preview.1] - 2020-12-18
### Changed
* Minor documentation getting started tweaks.
* Minor diagnostic logging tweaks.

### Fixed
* Fixed package errors when Analytics package is absent (case 1300418).
* Fixed tracking origin issue which was causing wrong camera height (case 1300457).
* Fixed issue where large portions of the world were incorrectly culled at certain camera orientations.
* Fixed potential error message when clicking `Fix All` in OpenXR Project Validation window.
* Fixed an issue with sample importing.

## [0.1.1-preview.1] - 2020-12-16

### This is the first release of *OpenXR Plugin \<com.unity.xr.openxr\>*.
