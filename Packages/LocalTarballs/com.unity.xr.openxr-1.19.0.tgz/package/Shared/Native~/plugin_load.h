#pragma once
#include <string>
//
// Platform Headers
//
#ifdef XR_USE_PLATFORM_WIN32
#ifndef WIN32_LEAN_AND_MEAN
#define WIN32_LEAN_AND_MEAN
#endif // !WIN32_LEAN_AND_MEAN

#ifndef NOMINMAX
#define NOMINMAX
#endif // !NOMINMAX

#include <windows.h>
#endif

#if defined(XR_USE_PLATFORM_WIN32)
#include "errhandlingapi.h"
#include "libloaderapi.h"

typedef HMODULE PluginHandle;
typedef FARPROC PluginFunc;

#else // Posix

#include <dlfcn.h>

typedef void* PluginHandle;
typedef void* PluginFunc;

#endif

PluginHandle Plugin_LoadLibrary(const wchar_t* libName);
void Plugin_FreeLibrary(PluginHandle handle);
PluginFunc Plugin_GetSymbol(PluginHandle handle, const char* symbol);
void Convert_utf16_to_utf8_char(char32_t utf16_codepoint, std::string& utf8_output);
std::string Convert_utf16_to_utf8(const wchar_t* libName);
