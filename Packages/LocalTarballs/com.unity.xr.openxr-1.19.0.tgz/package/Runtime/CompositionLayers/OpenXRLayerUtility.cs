#if XR_COMPOSITION_LAYERS
using System;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using Unity.XR.CompositionLayers;
using Unity.XR.CompositionLayers.Extensions;
using Unity.XR.CompositionLayers.Services;
using UnityEngine.XR.OpenXR.NativeTypes;
#if LIFECYCLE_APIS_AVAILABLE
using Unity.Scripting.LifecycleManagement;
#endif

namespace UnityEngine.XR.OpenXR.CompositionLayers
{
    /// <summary>
    /// Provider-local representation of how mip levels should be written into a layer swapchain, mirroring
    /// <c>TexturesExtension.MipMapModeEnum</c>. Kept independent of the Composition Layers API so the mip
    /// write path compiles and runs against Composition Layers versions that predate that enum, where it
    /// simply behaves as <see cref="MipMapWriteMode.None"/>.
    /// </summary>
    internal enum MipMapWriteMode
    {
        None,
        CopyFromSource,
        AutoGenerate,
    }

    /// <summary>
    /// A general-purpose helper class for composition layer support.
    /// </summary>
    public static class OpenXRLayerUtility
    {
        internal unsafe delegate void LayerCallbackDelegate(int layerId, XrCompositionLayerBaseHeader* layer);

#if LIFECYCLE_APIS_AVAILABLE
        [NoAutoStaticsCleanup]
#endif
        static Dictionary<uint, RenderTexture> s_TextureMap = new();
#if LIFECYCLE_APIS_AVAILABLE
        [NoAutoStaticsCleanup]
#endif
        static Dictionary<int, Cubemap> s_CubemapConversionCache = new();
#if LIFECYCLE_APIS_AVAILABLE
        [NoAutoStaticsCleanup]
#endif
#if UNITY_6000_3_OR_NEWER
        static HashSet<EntityId> s_LoggedCopyFromSourceFallback = new();
#else
        static HashSet<int> s_LoggedCopyFromSourceFallback = new();
#endif

        const int k_CubeFaceCount = 6;

        internal static void ClearCubemapConversionCache()
        {
            foreach (var kvp in s_CubemapConversionCache)
            {
                if (kvp.Value != null)
                    Object.Destroy(kvp.Value);
            }
            s_CubemapConversionCache.Clear();
        }

        // s_TextureMap only caches references to swapchain RenderTextures that we do not own, so drop the
        // stale references without destroying the textures.
        internal static void ClearRenderTextureCache()
        {
            s_TextureMap.Clear();
            s_LoggedCopyFromSourceFallback.Clear();
        }

        public delegate void RenderTextureIdCallbackDelegate(int layerId, uint texId);
        public delegate void StereoRenderTextureIdsCallbackDelegate(int layerId, uint leftTexId, uint rightTexId);

        /// <summary>
        /// Calls the methods in its invocation list when a swapchain is created on the graphics thread inside the UnityOpenXR lib.
        /// </summary>
        /// <param name="layerId">The unique id of the composition layer object.</param>
        /// <param name="swapchainHandle">The handle to the native swapchain that was just created.</param>
        public delegate void SwapchainCallbackDelegate(int layerId, ulong swapchainHandle);

        /// <summary>
        /// Calls the methods in its invocation list when a stereo swapchain is created on the graphics thread inside the UnityOpenXR lib.
        /// </summary>
        /// <param name="layerId">The unique id of the composition layer object.</param>
        /// <param name="swapchainHandleLeft">The handle to one of the stereo swapchains that was just created.</param>
        /// <param name="swapchainHandleRight">The handle to one of the stereo swapchains that was just created.</param>
        public delegate void StereoSwapchainCallbackDelegate(int layerId, ulong swapchainHandleLeft, ulong swapchainHandleRight);

        /// <summary>
        /// Helper method used to gather the extension components attached to a CompositionLayer GameObject.
        /// This method chains the native extension struct pointers of those extension components to initialize an OpenXR native object's Next pointer struct chain.
        /// </summary>
        /// <param name="layerInfo"> Container for the unique id and CompositionLayer component of the composition layer.</param>
        /// <param name="extensionTarget"> Represents what part of the composition layer to retrieve extensions for.</param>
        /// <returns>A pointer to the head of an array of native extension objects that will be associated with a composition layer.</returns>
        public static unsafe void* GetExtensionsChain(
            CompositionLayerManager.LayerInfo layerInfo, CompositionLayerExtension.ExtensionTarget extensionTarget)
        {
            void* extensionsChainHead = null;
            void* extensionsChain = null;

            foreach (var extension in layerInfo.Layer.Extensions)
            {
                // Skip extension if not enabled or not the intended target.
                if (!extension.enabled || extension.Target != extensionTarget)
                    continue;

                var extensionNativeStructPtr = extension.GetNativeStructPtr();

                // Skip extension if no native pointer is provided.
                if (extensionNativeStructPtr == null)
                    continue;

                // Initialize pointer chain if head has not been set.
                if (extensionsChainHead == null)
                {
                    extensionsChainHead = extensionNativeStructPtr;
                    extensionsChain = extensionsChainHead;
                }

                // Chain pointer if head has been initialized.
                else
                {
                    ((XrBaseInStructure*)extensionsChain)->next = extensionNativeStructPtr;
                    extensionsChain = extensionNativeStructPtr;
                }
            }

            return extensionsChainHead;
        }

        /// <summary>
        /// Helper method used get the current app space for any native composition layer structs that may require an associated XrSpace.
        /// </summary>
        /// <returns>A handle to the current app space.</returns>
        /// <remarks>Normally used when creating native composition layers.</remarks>
        public static ulong GetCurrentAppSpace() => Features.OpenXRFeature.Internal_GetAppSpace(out ulong appSpaceId) ? appSpaceId : 0;

        /// <summary>
        /// Helper method used get the XR session handle for any native composition layer structs that may require an associated XrSession.
        /// </summary>
        /// <returns>A handle to the current xr session.</returns>
        public static ulong GetXRSession() => Features.OpenXRFeature.Internal_GetXRSession(out ulong xrSessionHandle) ? xrSessionHandle : 0;

        // Computes the number of swapchain mip levels to request for a layer, honoring the layer's mip mode.
        internal static uint GetSwapchainMipCount(TexturesExtension texturesExtension)
        {
            if (texturesExtension == null || texturesExtension.LeftTexture == null)
            {
                Debug.LogWarning("GetSwapchainMipCount: textures extension or its texture is null. Defaulting to a single mip level.");
                return 1u;
            }

#if UNITY_ENGINE_MIPMAPS_SUPPORT
            var mipMapMode = GetMipMapWriteMode(texturesExtension);
            var sourceMipmapCount = texturesExtension.LeftTexture.mipmapCount;
            return mipMapMode != MipMapWriteMode.None && sourceMipmapCount > 1 ? (uint)sourceMipmapCount : 1u;
#else
            return 1u;
#endif
        }

        // Individual swapchain mip levels can only be written on graphics APIs that expose per-mip surfaces as
        // copy/render targets. OpenGL(ES) silently lands every per-mip write in mip 0, so on those APIs authored
        // (CopyFromSource) mips fall back to a generated chain (Blit + GenerateMips) instead.
        static bool SwapchainSupportsPerMipWrites()
        {
            var api = SystemInfo.graphicsDeviceType;
            return api != Rendering.GraphicsDeviceType.OpenGLES3
                && api != Rendering.GraphicsDeviceType.OpenGLCore;
        }

        // Reads a layer's mip mode as a provider-local <see cref="MipMapWriteMode"/>.
        internal static MipMapWriteMode GetMipMapWriteMode(TexturesExtension texturesExtension)
        {
#if XR_COMPOSITION_LAYERS_2_6_OR_GREATER
            return texturesExtension == null
                ? MipMapWriteMode.None
                : GetMipMapWriteMode(texturesExtension.MipMapMode);
#else
            return MipMapWriteMode.None;
#endif
        }

#if XR_COMPOSITION_LAYERS_2_6_OR_GREATER
        static MipMapWriteMode GetMipMapWriteMode(TexturesExtension.MipMapModeEnum mipMapMode)
        {
            switch (mipMapMode)
            {
                case TexturesExtension.MipMapModeEnum.CopyFromSource:
                    return MipMapWriteMode.CopyFromSource;
                case TexturesExtension.MipMapModeEnum.AutoGenerate:
                    return MipMapWriteMode.AutoGenerate;
                default:
                    return MipMapWriteMode.None;
            }
        }
#endif

        // Returns the usage flags to request for a color swapchain with the given mip count.
        internal static ulong GetColorSwapchainUsageFlags(uint mipCount)
        {
            var usageFlags = XrSwapchainUsageFlags.XR_SWAPCHAIN_USAGE_SAMPLED_BIT
                | XrSwapchainUsageFlags.XR_SWAPCHAIN_USAGE_COLOR_ATTACHMENT_BIT;

            if (mipCount > 1)
                usageFlags |= XrSwapchainUsageFlags.XR_SWAPCHAIN_USAGE_TRANSFER_SRC_BIT
                    | XrSwapchainUsageFlags.XR_SWAPCHAIN_USAGE_TRANSFER_DST_BIT;

            return (ulong)usageFlags;
        }

        /// <summary>
        /// Create the <see cref="XrSwapchainCreateInfo"/> struct that is passed to OpenXR SDK to create a swapchain.
        /// </summary>
        /// <param name="layerId">The unique id of the composition layer object.</param>
        /// <param name="createInfo">The struct used to create the swapchain.</param>
        /// <param name="isExternalSurface"> Optional parameter that can be used when an external surface will be used, like when using the Android Surface feature.</param>
        /// <param name="callback"> Optional parameter that can be used if your composition layer needs to know the handle after swapchain creation.</param>
        public static void CreateSwapchain(int layerId, XrSwapchainCreateInfo createInfo, bool isExternalSurface = false, SwapchainCallbackDelegate callback = null)
        {
            ext_composition_layers_CreateSwapchain(layerId, createInfo, isExternalSurface, callback);
        }

        /// <summary>
        /// Create the <see cref="XrSwapchainCreateInfo"/> struct that is passed to OpenXR SDK to create a swapchain for stereo projection, like Projection layer type.
        /// </summary>
        /// <param name="layerId">The unique id of the composition layer object.</param>
        /// <param name="createInfo">The struct used to create the swapchain.</param>
        /// <param name="callback"> Optional parameter that can be used if your composition layer needs to know the handles after swapchain creation.</param>
        public static void CreateStereoSwapchain(int layerId, XrSwapchainCreateInfo createInfo, StereoSwapchainCallbackDelegate callback = null)
        {
            ext_composition_layers_CreateStereoSwapchain(layerId, createInfo, callback);
        }

        /// <summary>
        /// Submits a request to create or get an available render texture associated with the swapchain of the given layer id.
        /// </summary>
        /// <param name="layerId">The unique id of the composition layer object.</param>
        /// <param name="callback">Callback that will be invoked with the current render texture id to use for the layer's swapchain.</param>
        /// <remarks>The callback will be invoked on the graphics thread. Work on the render texture must be done anywhere within the scene rendering phase (such as Application.OnBeforeRender).</remarks>
        public static void RequestRenderTextureId(int layerId, RenderTextureIdCallbackDelegate callback)
        {
            ext_compositor_layers_RequestRenderTextureId(layerId, callback);
        }

        /// <summary>
        /// Submits a request to create or get an available stereo render texture associated with the stereo swapchain of the given layer id.
        /// </summary>
        /// <param name="layerId">The unique id of the composition layer object.</param>
        /// <param name="callback"> Callback that will be invoked with the current stereo render texture ids to use for the layer's swapchain</param>
        /// <remarks>The callback will be invoked on the graphics thread. Work on the render textures must be done anywhere within the scene rendering phase (such as Application.OnBeforeRender).</remarks>
        public static void RequestStereoRenderTextureIds(int layerId, StereoRenderTextureIdsCallbackDelegate callback)
        {
            ext_compositor_layers_RequestStereoRenderTextureIds(layerId, callback);
        }

        /// <summary>
        /// Synchronously creates or gets the stereo render texture IDs for the given layer.
        /// </summary>
        /// <param name="layerId">The instance id of the composition layer object.</param>
        /// <param name="leftId">Output left-eye render texture ID.</param>
        /// <param name="rightId">Output right-eye render texture ID.</param>
        /// <returns>True if the stereo render texture IDs were successfully retrieved.</returns>
        public static bool CreateOrGetStereoRenderTextureIds(int layerId, out uint leftId, out uint rightId)
        {
            return ext_compositor_layers_CreateOrGetStereoRenderTextureIds(layerId, out leftId, out rightId);
        }

        /// <summary>
        /// Release and Destroy the swapchain according to the id provided.
        /// </summary>
        /// <param name="layerId">The unique id of the composition layer object.</param>
        public static void ReleaseSwapchain(int layerId)
        {
            ext_composition_layers_ReleaseAndDestroySwapchain(layerId);
        }

        /// <summary>
        /// Remove an active layer from the native end frame info according to the order provided.
        /// </summary>
        /// <param name="layerOrder">The order of the composition layer.</param>
        public static void RemoveActiveLayer(int layerOrder)
        {
            ext_composition_layers_RemoveActiveLayer(layerOrder);
        }

        /// <summary>
        /// Return swapchain supported color format.
        /// </summary>
        /// <returns>The color format the swapchains will be using.</returns>
        public static Int64 GetDefaultColorFormat()
        {
            return ext_composition_layers_GetUnityDefaultColorFormat();
        }

        /// <summary>
        /// Finds the render texture of the give texture id.
        /// </summary>
        /// <param name="texId">The id of the render texture to find.</param>
        /// <returns>The render texture with the provided id or null if no render texture with that id was found.</returns>
        public static RenderTexture FindRenderTexture(uint texId)
        {
            // texId will be 0 if swapchain has no images.
            if (texId == 0)
                return null;

            if (!s_TextureMap.TryGetValue(texId, out var renderTexture))
            {
                var objs = Resources.FindObjectsOfTypeAll<RenderTexture>();
                var name = $"XR Texture [{texId}]";
                foreach (var rt in objs)
                {
                    if (rt.name == name)
                    {
                        renderTexture = rt;
                        s_TextureMap[texId] = rt;
                        break;
                    }
                }
            }

            return renderTexture;
        }

        /// <summary>
        /// Finds the render texture of the layer id.
        /// </summary>
        /// <param name="layerInfo"> Container for the unique id and CompositionLayer component of the composition layer.</param>
        /// <returns>The render texture with the provided id or null if no render texture with that id was found.</returns>
        [Obsolete("OpenXRLayerUtility.FindRenderTexture is deprecated. If you want to query for a swapchain render texture then use OpenXRLayerUtility.RequestRenderTextureId instead", false)]
        public static RenderTexture FindRenderTexture(CompositionLayerManager.LayerInfo layerInfo)
        {
            var texId = ext_compositor_layers_CreateOrGetRenderTextureId(layerInfo.Id);
            return FindRenderTexture(texId);
        }

        /// <summary>
        /// Releases the swapchain image associated with the layer id.
        /// </summary>
        /// <param name="layerInfo"> Container for the unique id and CompositionLayer component of the composition layer.</param>
        /// <returns>The render texture with the provided id or null if no render texture with that id was found.</returns>
        [Obsolete("OpenXRLayerUtility.ReleaseSwapchain is deprecated. Swapchains are all automatically released by the graphics thread.", false)]
        public static void ReleaseSwapchain(CompositionLayerManager.LayerInfo layerInfo)
        {
            ext_compositor_layers_ReleaseSwapchain(layerInfo.Id);
        }

        /// <summary>
        /// Handles transfering texture data to a render texture, writing only the full-resolution image (mip level 0).
        /// </summary>
        /// <param name="texture">The source texture that will be written into the provided render texture.</param>
        /// <param name="renderTexture">The render texture that will be written to.</param>
        public static void WriteToRenderTexture(Texture texture, RenderTexture renderTexture)
        {
            WriteToRenderTexture(texture, renderTexture, MipMapWriteMode.None);
        }

        // Handles transfering texture data to a render texture, propagating mipmap levels according to the provided <see cref="MipMapWriteMode"/>.
        internal static void WriteToRenderTexture(Texture texture, RenderTexture renderTexture, MipMapWriteMode mipMapMode)
        {
            if (texture == null || renderTexture == null)
                return;

            bool isDestinationMipped = renderTexture.useMipMap && renderTexture.mipmapCount > 1;

            if (renderTexture.dimension == Rendering.TextureDimension.Cube && texture.dimension == Rendering.TextureDimension.Cube)
            {
                Cubemap convertedTexture = null;

                // Check if graphics format or mipmap count is different and convert if necessary.
                if (renderTexture.graphicsFormat != texture.graphicsFormat || renderTexture.mipmapCount != texture.mipmapCount)
                {
#if UNITY_6000_3_OR_NEWER
                    int cacheKey = HashCode.Combine(texture.GetEntityId(), renderTexture.graphicsFormat);
#else
                    int cacheKey = HashCode.Combine(texture.GetInstanceID(), renderTexture.graphicsFormat);
#endif
                    if (!s_CubemapConversionCache.TryGetValue(cacheKey, out convertedTexture)
                        || convertedTexture == null
                        || convertedTexture.width != texture.width)
                    {
                        if (convertedTexture != null)
                            Object.Destroy(convertedTexture);

                        var creationFlags = texture.mipmapCount > 1
                            ? Experimental.Rendering.TextureCreationFlags.MipChain
                            : Experimental.Rendering.TextureCreationFlags.None;
                        convertedTexture = new Cubemap(texture.width, renderTexture.graphicsFormat, creationFlags);
                        s_CubemapConversionCache[cacheKey] = convertedTexture;
                    }

                    if (!Graphics.ConvertTexture(texture, convertedTexture))
                    {
                        Debug.LogError("Failed to convert Cubemap to Render Texture format!");
                        return;
                    }
                }

                Texture cubeSource = convertedTexture == null ? texture : convertedTexture;

                if (isDestinationMipped && mipMapMode == MipMapWriteMode.CopyFromSource && SwapchainSupportsPerMipWrites())
                {
                    if (cubeSource.mipmapCount == renderTexture.mipmapCount)
                    {
                        for (int i = 0; i < k_CubeFaceCount; i++)
                        {
                            Graphics.CopyTexture(cubeSource, i, renderTexture, i);
                        }
                        return;
                    }

                    if (ShouldLogCopyFromSourceFallback(renderTexture))
                        Debug.LogWarning("WriteToRenderTexture: CopyFromSource could not copy the cubemap mips directly " +
                            "(source and swapchain mip counts differ). Falling back to auto-generated mips.");
                }

                if (isDestinationMipped)
                {
                    for (int i = 0; i < k_CubeFaceCount; i++)
                    {
                        Graphics.CopyTexture(cubeSource, i, 0, renderTexture, i, 0);
                    }
                    renderTexture.GenerateMips();
                    return;
                }

                for (int i = 0; i < k_CubeFaceCount; i++)
                {
                    Graphics.CopyTexture(cubeSource, i, 0, renderTexture, i, 0);
                }
                return;
            }

            bool isRawCopyWouldFlip = RawCopyIntoSwapchainWouldFlip(renderTexture);

            if (isDestinationMipped && mipMapMode == MipMapWriteMode.CopyFromSource && SwapchainSupportsPerMipWrites())
            {
                if (TryWriteAuthoredMips(texture, renderTexture))
                    return;

                if (ShouldLogCopyFromSourceFallback(renderTexture))
                    Debug.LogWarning("WriteToRenderTexture: CopyFromSource could not copy the source mips directly " +
                        "(unsupported copy, or a size, format, or mip-count mismatch with the swapchain). " +
                        "Falling back to auto-generated mips.");
            }

            if (isDestinationMipped
                && (mipMapMode == MipMapWriteMode.AutoGenerate
                    || mipMapMode == MipMapWriteMode.CopyFromSource))
            {
                Graphics.Blit(texture, renderTexture);
                renderTexture.GenerateMips();
                return;
            }

            if (!isRawCopyWouldFlip && CanTextureUseGraphicsCopy(texture, renderTexture))
                Graphics.CopyTexture(texture, renderTexture);
            else
                Graphics.Blit(texture, renderTexture);
        }

        // Warns at most once per destination swapchain render texture so the per-frame writes do not spam the console
        static bool ShouldLogCopyFromSourceFallback(RenderTexture renderTexture)
        {
#if UNITY_6000_3_OR_NEWER
            return s_LoggedCopyFromSourceFallback.Add(renderTexture.GetEntityId());
#else
            return s_LoggedCopyFromSourceFallback.Add(renderTexture.GetInstanceID());
#endif
        }

        // Graphics.CopyTexture is a raw image copy and any (non-cube) layer texture created without AllowVerticalFlip on
        // top-left-origin graphics APIs (Metal, D3D, Vulkan) when copied lands upside down regardless of the source type, blit stays upright.
        static bool RawCopyIntoSwapchainWouldFlip(RenderTexture destination) =>
            SystemInfo.graphicsUVStartsAtTop
            && (destination.descriptor.flags & RenderTextureCreationFlags.AllowVerticalFlip) == 0;

        static bool TryWriteAuthoredMips(Texture source, RenderTexture destination)
        {
            if (source.dimension != Rendering.TextureDimension.Tex2D
                || destination.dimension != Rendering.TextureDimension.Tex2D)
                return false;

            if (Experimental.Rendering.GraphicsFormatUtility.IsCompressedFormat(source.graphicsFormat))
                return false;

            var copySupport = SystemInfo.copyTextureSupport;
            if ((copySupport & Rendering.CopyTextureSupport.Basic) == 0)
                return false;

            if (!(source is RenderTexture) && (copySupport & Rendering.CopyTextureSupport.TextureToRT) == 0)
                return false;

            if (source is RenderTexture sourceRenderTexture && sourceRenderTexture.antiAliasing > 1)
                return false;

            if (source.width != destination.width || source.height != destination.height)
                return false;

            int mipCount = destination.mipmapCount;
            if (mipCount <= 1 || source.mipmapCount < mipCount)
                return false;

            var previousActive = RenderTexture.active;
            for (int mip = 0; mip < mipCount; mip++)
            {
                int mipWidth = Mathf.Max(1, destination.width >> mip);
                int mipHeight = Mathf.Max(1, destination.height >> mip);

                var sourceMip = RenderTexture.GetTemporary(
                    new RenderTextureDescriptor(mipWidth, mipHeight, source.graphicsFormat, 0));
                Graphics.CopyTexture(source, 0, mip, sourceMip, 0, 0);

                var converted = RenderTexture.GetTemporary(
                    new RenderTextureDescriptor(mipWidth, mipHeight, destination.graphicsFormat, 0));

                if (RawCopyIntoSwapchainWouldFlip(destination))
                {
                    Graphics.Blit(sourceMip, converted, new Vector2(1f, -1f), new Vector2(0f, 1f));
                }
                else
                {
                    Graphics.Blit(sourceMip, converted);
                }

                Graphics.CopyTexture(converted, 0, 0, destination, 0, mip);

                RenderTexture.ReleaseTemporary(sourceMip);
                RenderTexture.ReleaseTemporary(converted);
            }
            RenderTexture.active = previousActive;

            return true;
        }

        // Determines whether a Texture can be transferred with a direct GPU copy instead of a blit.
        internal static bool CanTextureUseGraphicsCopy(Texture source, RenderTexture destination)
        {
            // The platform / graphics API must support a basic copy.
            var copySupport = SystemInfo.copyTextureSupport;
            if ((copySupport & Rendering.CopyTextureSupport.Basic) == 0)
                return false;

            // A non-RenderTexture source copied into the RenderTexture swapchain is a Texture-to-RenderTexture
            // copy whose support is a separately reported capability by backends.
            if (!(source is RenderTexture) && (copySupport & Rendering.CopyTextureSupport.TextureToRT) == 0)
                return false;

            if (source.width != destination.width || source.height != destination.height)
                return false;

            if (source.graphicsFormat != destination.graphicsFormat)
                return false;

            if (source.mipmapCount != destination.mipmapCount)
                return false;

            if (source.dimension != destination.dimension)
                return false;

            // A whole-texture copy transfers every array slice, so array slice counts must match.
            if (GetSliceCount(source) != GetSliceCount(destination))
                return false;

            // MSAA sample counts
            if (source is RenderTexture sourceRenderTexture)
            {
                if (sourceRenderTexture.antiAliasing != destination.antiAliasing)
                    return false;
            }
            else if (destination.antiAliasing > 1)
            {
                return false;
            }

            return true;
        }

        static int GetSliceCount(Texture texture) => texture switch
        {
            RenderTexture renderTexture => renderTexture.volumeDepth,
            Texture2DArray textureArray => textureArray.depth,
            _ => 1,
        };

        /// <summary>
        /// Query the correct XR Textures for rendering and blit the layer textures.
        /// </summary>
        /// <param name="layerInfo"> Container for the unique id and CompositionLayer component of the composition layer.</param>
        /// <param name="texture">The source texture that will be written into the provided render texture.</param>
        /// <param name="renderTexture">The render texture that will be searched for and written to.
        /// Will be null if no render texture can be found for the provided layerInfo object.</param>
        /// <returns>True if a render texture was found and written to, false if the provided texture is null or if no render texture was found for the provided layerInfo object.</returns>
        [Obsolete("OpenXRLayerUtility.FindAndWriteToRenderTexture is deprecated. If you want to query for a swapchain render texture then use OpenXRLayerUtility.RequestRenderTextureId instead", false)]
        public static bool FindAndWriteToRenderTexture(CompositionLayerManager.LayerInfo layerInfo, Texture texture, out RenderTexture renderTexture)
        {
            if (texture == null)
            {
                renderTexture = null;
                return false;
            }

            renderTexture = FindRenderTexture(layerInfo);
            WriteToRenderTexture(texture, renderTexture);
            return renderTexture != null;
        }

        /// <summary>
        /// Query the correct XR Textures for rendering and blit the layer textures (For Projection Layer type).
        /// </summary>
        /// <param name="layerInfo"> Container for the unique id and CompositionLayer component of the composition layer.</param>
        /// <param name="renderTextureLeft">The left stereo render texture that will be searched for and written to.
        /// Will be null if no render textures can be found for the provided layerInfo object.</param>
        /// <param name="renderTextureRight">The right stereo render texture that will be searched for and written to.
        /// Will be null if no render textures can be found for the provided layerInfo object.</param>
        /// <returns>True if both render textures were found and written to, false if no texture was found on the TexturesExtension component of the layerInfo object or if no render texture was found for the provided layerInfo object.</returns>
        [Obsolete("OpenXRLayerUtility.FindAndWriteToStereoRenderTextures is deprecated. If you want to query for a stereo swapchain render texture then use OpenXRLayerUtility.RequestStereoRenderTextureId instead", false)]
        public static bool FindAndWriteToStereoRenderTextures(CompositionLayerManager.LayerInfo layerInfo, out RenderTexture renderTextureLeft, out RenderTexture renderTextureRight)
        {
            var tex = layerInfo.Layer.GetComponent<TexturesExtension>();
            if (tex == null || tex.LeftTexture == null || tex.RightTexture == null)
            {
                renderTextureLeft = null;
                renderTextureRight = null;
                return false;
            }

            ext_compositor_layers_CreateOrGetStereoRenderTextureIds(layerInfo.Id, out uint leftId, out uint rightId);
            renderTextureLeft = FindRenderTexture(leftId);
            renderTextureRight = FindRenderTexture(rightId);
            WriteToRenderTexture(tex.LeftTexture, renderTextureLeft);
            WriteToRenderTexture(tex.RightTexture, renderTextureRight);
            return renderTextureLeft != null && renderTextureRight != null;
        }

        /// <summary>
        /// Add native layer structs to the <c>endFrameInfo</c> struct inside the UnityOpenXR lib - for custom layer type support
        /// </summary>
        /// <param name="layers">Pointer to the native array of currently active composition layers.</param>
        /// <param name="orders">Pointer to the native array of order values for the currently active composition layers.</param>
        /// <param name="count">Indicates the size of the layers and orders arrays.</param>
        /// <param name="layerByteSize">Indicates the size in bytes of a single element of the given array of composition layers.</param>
        /// <remarks>Layers sent must all be of the same type.Demonstrated in the OpenXRCustomLayerHandler class.</remarks>
        public static unsafe void AddActiveLayersToEndFrame(void* layers, void* orders, int count, int layerByteSize)
        {
            ext_composition_layers_AddActiveLayers(layers, orders, count, layerByteSize);
        }

        /// <summary>
        /// Return the Surface object for Android External Surface support (Android only).
        /// </summary>
        /// <param name="layerId">The unique id of the composition layer object.</param>
        /// <returns>Pointer to the android surface object.</returns>
        public static IntPtr GetLayerAndroidSurfaceObject(int layerId)
        {
            var surfaceObject = IntPtr.Zero;
            if (ext_composition_layers_GetLayerAndroidSurfaceObject(layerId, ref surfaceObject))
            {
                return surfaceObject;
            }
            else
            {
#if UNITY_6000_4 && XR_COMPOSITION_LAYERS_2_4_OR_GREATER
                // Check if we have been given an instanceID of an existing composition layer.
                // If so, update the layer id to be the one used by the native plugin, which is necessary for the native plugin to find the correct surface object in its map.
                foreach (var layer in CompositionLayerManager.Instance.CompositionLayers)
                {
#pragma warning disable CS0618
                    var instanceId = layer.GetInstanceID();
#pragma warning restore CS0618
                    if (instanceId == layerId)
                    {
                        Debug.LogWarning("GetInstanceID is deprecated in Unity 6.4. Use CompositionLayerManager.TryGetLayerId instead.");
                        surfaceObject = IntPtr.Zero;
                        if (CompositionLayerManager.TryGetLayerId(layer, out layerId) && ext_composition_layers_GetLayerAndroidSurfaceObject(layerId, ref surfaceObject))
                        {
                            return surfaceObject;
                        }
                        break;
                    }
                }
#endif
                Debug.LogError($"Failed to get Android Surface Object for layer with id {layerId}. Make sure this layer's TexturesExtenson component is sourcing its texture from Android Surface (not Local Texture) and that the layer id was generated by CompositionLayerManager.TryGetLayerId.");
                return IntPtr.Zero;
            }
        }

        /// <summary>
        /// Sends an array of extensions to be attached to the native default composition layer.
        /// </summary>
        /// <param name="extensions">Pointer to the array of extensions to attach to the default composition layer.</param>
        /// <remarks>Currently only called by the OpenXRDefaultLayer class.</remarks>
        public static unsafe void SetDefaultSceneLayerExtensions(void* extensions)
        {
            ext_composition_layers_SetDefaultSceneLayerExtensions(extensions);
        }

        /// <summary>
        /// Sends what flags are to be added to the native default composition layer.
        /// </summary>
        /// <param name="flags">Flags to be added to the native default composition layer.</param>
        /// <remarks>Currently only called by the OpenXRDefaultLayer class.</remarks>
        public static void SetDefaultLayerFlags(XrCompositionLayerFlags flags)
        {
            ext_composition_layers_SetDefaultSceneLayerFlags(flags);
        }

        /// <summary>
        /// Clear the native default composition layer's layer flag.
        /// </summary>
        /// <remarks>Currently only called by the OpenXRDefaultLayer class.</remarks>
        public static void ClearDefaultLayerFlags()
        {
            ext_composition_layers_ClearDefaultSceneLayerFlags();
        }

        const string LibraryName = "UnityOpenXR";

        [DllImport(LibraryName)]
        internal static extern void ext_compositor_layers_RequestRenderTextureId(
            int id, RenderTextureIdCallbackDelegate callback);

        [DllImport(LibraryName)]
        internal static extern void ext_compositor_layers_RequestStereoRenderTextureIds(
            int id, StereoRenderTextureIdsCallbackDelegate callback);

        [DllImport(LibraryName)]
        internal static extern void ext_compositor_layers_ReleaseSwapchain(int id);

        [DllImport(LibraryName)]
        internal static extern UInt32 ext_compositor_layers_CreateOrGetRenderTextureId(int id);

        [DllImport(LibraryName)]
        [return: MarshalAs(UnmanagedType.U1)]
        internal static extern bool ext_compositor_layers_CreateOrGetStereoRenderTextureIds(
            int id, out uint leftId, out uint rightId);

        [DllImport(LibraryName)]
        internal static extern void ext_composition_layers_CreateSwapchain(
            int id,
            XrSwapchainCreateInfo createInfo,
            [MarshalAs(UnmanagedType.I1)]bool isExternalSurface = false,
            SwapchainCallbackDelegate callback = null);

        [DllImport(LibraryName)]
        internal static extern void ext_composition_layers_CreateStereoSwapchain(
            int id, XrSwapchainCreateInfo createInfo, StereoSwapchainCallbackDelegate callback = null);

        [DllImport(LibraryName)]
        internal static extern Int64 ext_composition_layers_GetUnityDefaultColorFormat();

        [DllImport(LibraryName)]
        internal static extern void ext_composition_layers_ReleaseAndDestroySwapchain(int id);

        [DllImport(LibraryName)]
        internal static extern void ext_composition_layers_RemoveActiveLayer(int order);

        [DllImport(LibraryName)]
        internal static extern unsafe void ext_composition_layers_AddActiveLayers(
            void* layers, void* orders, int count, int size);

        [DllImport(LibraryName)]
        [return: MarshalAs(UnmanagedType.U1)]
        internal static extern bool ext_composition_layers_GetLayerAndroidSurfaceObject(
            int layerId, ref IntPtr surfaceObject);

        [DllImport(LibraryName)]
        internal static extern unsafe void ext_composition_layers_SetDefaultSceneLayerExtensions(void* extensions);

        [DllImport(LibraryName)]
        internal static extern void ext_composition_layers_SetDefaultSceneLayerFlags(XrCompositionLayerFlags flags);

        [DllImport(LibraryName)]
        internal static extern void ext_composition_layers_ClearDefaultSceneLayerFlags();
    }
}

#endif
